####################################################################
# Jeff Goldsmith
# 16 Nov 2015
# 
# This file recreates the analysis in "New insights into activity 
# patterns in children, found using functional data analyses" for a
# simulated dataset.
#
####################################################################

rm(list = ls())

library(refund)
library(refund.shiny)

## load data
load("20151116_SimulatedData.RDA")

## fit the MLR model
mlr.rundle.summer = lm(obs_accel_mean ~ X1+X2+X3+X4+X5+X6+X7, 
                       data = data.warm)
summary(mlr.rundle.summer)

## fit the fosr model
fosr.rundle.summer = bayes_fosr(accel ~ X1+X2+X3+X4+X5+X6+X7, 
                                est.method = "GLS", Kt = 8, data = data.warm, basis = "bs", CI.type = "pointwise")

## explore results
plot_shiny(fosr.rundle.summer)

## compare null to alternative model for one variable of interest
fit.null = bayes_fosr(accel ~  X1+X2+X3+X4+X5+X6, 
                      est.method = "GLS", Kt = 8, data = data.warm, basis = "bs", CI.type = "pointwise", verbose = FALSE)
fit.alt = bayes_fosr(accel ~  X1+X2+X3+X4+X5+X6+X7, 
                     est.method = "GLS", Kt = 8, data = data.warm, basis = "bs", CI.type = "pointwise", verbose = FALSE,
                     sigma = fit.null$sigma)

anova(fit.null$model.gls, fit.alt$model.gls)$P[2]

####################################################################
####################################################################
####################################################################
####################################################################
####################################################################
####################################################################