This web appendix accompanies the paper "Penalized Functional Regression" by Goldsmith, Feder, Crainiceanu, Caffo, and Reich (2010). The files contained are those used to conduct the simulations present in the paper. Further, the file PFR_Example.R illustrates the PFR method on a single data set.

Code was written by Jeff Goldsmith and Jennifer Feder. We also include code from Cardot and collaborators and Reiss and Ogden, whose methods are used for comparison in the univariate case.
