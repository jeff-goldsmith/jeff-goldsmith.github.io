##################################################################
# February 1 2014
# Jeff Goldsmith
#
# Simulations for multilevel generalized function-on-scalar
# regression and principal components analysis.
##################################################################

rm(list = ls())

library(splines)
library(rstan)
library(mvtnorm)
library(boot)

set_cppo("fast")    # for best running speed
# set_cppo("debug") # for easier debugging

doFigure = FALSE    ## draw figure

## set working directory and select parameter scenario
param.scen = 1
Date = gsub("-", "", Sys.Date())

###############################################################
## set path to Stan model code
###############################################################

file.source = "./Model Code/20131031_GenMFPCA.stan"

###############################################################
## set simulation design elements
###############################################################

NREP = 100                        ## number of iterations
D = 100                           ## size of grid for observations
J = 4                             ## number of curves per subject
Kt = 10                           ## dimension of bspline basis
Kp.true = 2                       ## number of true FPC basis functions
grid = seq(0, 1, length = D)

PARAMS = matrix(NA, 4, 2)
count = 1
for(I in c(50, 100)){
  for(Kp in c(2, 5)){
    PARAMS[count, ] = c(I, Kp)
    count = count + 1
  }
}

I = PARAMS[param.scen, 1]         ## number of subjects
Kp = PARAMS[param.scen, 2]        ## number of FPC basis functions
IJ = I * J                        ## total number of observed functions

###############################################################
## define coefficients and PC basis functions
###############################################################

beta.true = matrix(NA, 2, D)
beta.true[1,] = - 1.5 - sin(2*grid*pi) - cos(2*grid*pi)
beta.true[2,] = dnorm(grid, .6, .15) / 20

psi1.true = matrix(NA, 2, D)
psi1.true[1,] = (1.5 - sin(2*grid*pi) - cos(2*grid*pi) ) / sqrt(322)
psi1.true[2,] = sin(4*grid*pi) / sqrt(49.5)

psi2.true = matrix(NA, 2, D)
psi2.true[1,] = (1.5 - sin(2*grid*pi) - cos(2*grid*pi) ) / sqrt(322)
psi2.true[2,] = cos(4*grid*pi) / sqrt(50.5)

lambda1.true = c(3, 1.5)
lambda2.true = c(2, 1)


###############################################################
## Bspline and penalty matrices
###############################################################

BS = bs(1:D, df=Kt, intercept=TRUE, degree=3)

alpha = .1
diff0 = diag(1, D, D)
diff2 = matrix(rep(c(1,-2,1, rep(0, D-2)), D-2)[1:((D-2)*D)], D-2, D, byrow = TRUE)
P0 = t(BS) %*% t(diff0) %*% diff0 %*% BS
P2 = t(BS) %*% t(diff2) %*% diff2 %*% BS
P.mat = alpha * P0 + (1-alpha) * P2

###############################################################
## matrices to keep track of results
###############################################################

COVERAGE.Y = matrix(NA, NREP, 2)
COVERAGE.BETA = matrix(NA, NREP, 2)
TIME = matrix(NA, NREP, 4)
MSE.Y = matrix(NA, NREP, 2)
MSE.BETA = matrix(NA, NREP, 2)

colnames(COVERAGE.Y) = colnames(MSE.Y) = c("Level 1", "Level 2")
colnames(COVERAGE.BETA) = colnames(MSE.BETA) = c("Int", "Slope")

###############################################################
###############################################################
## start simulation code
###############################################################
###############################################################

for(i.iter in 1:NREP){

  TIME[i.iter, 2] = i.iter
  TIME[i.iter, 3] = I
  TIME[i.iter, 4] = Kp

  ## random effect design matrix
  subj = as.factor(rep(1:I, each = J))
  Z.des = model.matrix( ~ 0 + subj + (-1):subj)


  ###############################################################
  ## generate full data for this iteration
  ###############################################################
  
  ## fixed effect design matrix
  X.des = cbind(1, rep(rnorm(I, 0, 5), each = J))  
  p = dim(X.des)[2]

  ## fixed effects
  fixef = X.des %*% beta.true

  ## level 1 pca effects
  c1.true = rmvnorm(I, mean = rep(0, 2), sigma = diag(lambda1.true))
  pca1ef = Z.des %*% (c1.true %*% psi1.true)

  ## level 2 pca effects
  c2.true = rmvnorm(IJ, mean = rep(0, 2), sigma = diag(lambda2.true))
  pca2ef = c2.true %*% psi2.true

  ## true probabilities and observed curves
#  pi.true = inv.logit(fixef)
  pi.true = inv.logit(fixef + pca1ef)[J*(1:I),]
  pij.true = inv.logit(fixef + pca1ef + pca2ef)
  Yij.obs = matrix(NA, IJ, D)
  for(i in 1:IJ){
  	for(j in 1:D){
  	  Yij.obs[i,j] = rbinom(1, 1, pij.true[i,j])
    }
  }

  ###############################################################
  ## STAN
  ###############################################################

  time.start = proc.time()

  dat = list(Y=Yij.obs, X=X.des, BS = BS, 
             I = I, J = J, IJ = IJ, D = D, p = p, Kt = Kt, 
             Kp1 = Kp, Kp2 = Kp,
             PenMat = P.mat)
           
  GenMFPCA.fit = stan(model_name="Binary MFPCA", file = file.source, 
                 data=dat, iter = 5000, warmup = 2000,
                 control = list(adapt_delta = .65),
                 chains = 1, verbose = FALSE)

  time.stop = proc.time()
  TIME[i.iter,1] = (time.stop - time.start)[3]

  ##################################################################
  ## some post processing
  ##################################################################

  beta.post = extract(GenMFPCA.fit, "beta")$beta
  beta_psi1.post = extract(GenMFPCA.fit, "beta_psi1")$beta_psi1
  beta_psi2.post = extract(GenMFPCA.fit, "beta_psi2")$beta_psi2
  c1.post = extract(GenMFPCA.fit, "c1")$c1
  c2.post = extract(GenMFPCA.fit, "c2")$c2
  
  betaHat.post = array(NA, dim = c(p, D, dim(beta.post)[1]))
  for(i in 1:dim(beta.post)[1]) {
    betaHat.post[,,i] = (beta.post[i,,] %*% t(BS))
  }

  yi.post = array(NA, dim = c(I, D, dim(beta.post)[1]))
  for(i in 1:dim(beta.post)[1]) {
    yi.post[,,i] = X.des[J*(1:I),] %*% (beta.post[i,,] %*% t(BS)) + 
                   c1.post[i,,] %*% (beta_psi1.post[i,,] %*% t(BS))
  }

  yij.post = array(NA, dim = c(IJ, D, dim(beta.post)[1]))
  for(i in 1:dim(beta.post)[1]) {
    yij.post[,,i] = X.des %*% (beta.post[i,,] %*% t(BS)) + 
                    Z.des %*% (c1.post[i,,] %*% (beta_psi1.post[i,,] %*% t(BS))) +
                    c2.post[i,,] %*% (beta_psi2.post[i,,] %*% t(BS))
  }
  
  ## coverage for y's
  Yi.hat = apply(yi.post, c(1,2), mean)
  Yij.hat = apply(yij.post, c(1,2), mean)

  yi.LB = apply(yi.post, c(1,2), quantile, c(.025))
  yi.UB = apply(yi.post, c(1,2), quantile, c(.975))
  yij.LB = apply(yij.post, c(1,2), quantile, c(.025))
  yij.UB = apply(yij.post, c(1,2), quantile, c(.975))

  COVERAGE.Y[i.iter, 1] = mean(logit(pi.true) < yi.UB & logit(pi.true) > yi.LB)  
  COVERAGE.Y[i.iter, 2] = mean(logit(pij.true) < yij.UB & logit(pij.true) > yij.LB)  

  MSE.Y[i.iter, 1] = mean((logit(pi.true) - Yi.hat)^2)
  MSE.Y[i.iter, 2] = mean((logit(pij.true) - Yij.hat)^2)
    
  ## coverage for mu
  beta.hat = apply(betaHat.post, c(1,2), mean)

  beta.LB = apply(betaHat.post, c(1,2), quantile, c(.025))
  beta.UB = apply(betaHat.post, c(1,2), quantile, c(.975))

  COVERAGE.BETA[i.iter, ] = sapply(1:2, function(u) mean(beta.true[u,] < beta.UB[u,] & beta.true[u,] > beta.LB[u,]))
  MSE.BETA[i.iter, ] = sapply(1:2, function(u) mean((beta.true[u,] - beta.hat[u,])^2))

  ###############################################################
  ## save data during each iteration
  ###############################################################

  filename = paste0(Date, "_GenMFPCA_Res_S", param.scen, ".RDA")
  save(COVERAGE.Y, COVERAGE.BETA, MSE.Y, MSE.BETA, TIME, 
       file = filename)

  cat("REP: ", i.iter, "\n")

}

###############################################################
###############################################################
## end sim
###############################################################
###############################################################

if(doFigures){

  ##################################################################
  ## fixed effects plots
  ##################################################################

  dev.new(width = 8, height = 3.5)
  par(mfrow = c(1,2), mai = c(.85, .85, .2, .2), cex = 1)

  matplot(matrix(1:D, D, 100), betaHat.post[1,,1:100], lty = 1, col = "#0000002b", type ='l',
    ylab = expression(beta[0](t)), xlab = "Time")
  points(beta.hat[1,], type = 'l', col = "red", lwd = 2)
  points(beta.true[1,], type = 'l', col = "blue", lwd = 2)
  legend("topleft", c("Est", "True"), lwd = c(2,2), col = c("red", "blue"))
  
  matplot(matrix(1:D, D, 100), betaHat.post[2,,1:100], lty = 1, col = "#0000002b", type ='l',
    ylab = expression(beta[1](t)), xlab = "Time")
  points(beta.hat[2,], type = 'l', col = "red", lwd = 2)
  points(beta.true[2,], type = 'l', col = "blue", lwd = 2)
  legend("topleft", c("Est", "True"), lwd = c(2,2), col = c("red", "blue"))
 

  ##################################################################
  ## covariate effects
  ##################################################################

  dev.new(width = 9, height = 3.5)
  par(mfrow = c(1,2), mai = c(.85, .85, .2, .2), cex = 1)

  plotCols = c("#EBC200", "#EB9D00", "#000000", "#EB0000", "#990099", "#2600A2", "#005597")
  plotLWD = c(2,2,4,2,2,2,2)
  
  X.plot = cbind(1, seq(-10,20, by = 5), 0)
  matplot(matrix(1:D, D, 7), t(inv.logit(X.plot %*% betaHat)), lty = 1, col = plotCols, lwd = plotLWD, type ='l',
    ylab = "Fitted Probability", xlab = "Time", xaxt = "n", ylim = range(0,.55))
  axis(1, at = seq(0, 288, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))
  legend("topleft", paste0("AGE = ", 60 + X.plot[,2]), col = plotCols, lwd = plotLWD, cex = .7)

  X.plot = cbind(1, 0, seq(-5,10, by = 2.5))
  matplot(matrix(1:D, D, 7), t(inv.logit(X.plot %*% betaHat)), lty = 1, col = plotCols, lwd = plotLWD, type ='l',
    ylab = "Fitted Probability", xlab = "Time", xaxt = "n", ylim = range(0,.55))
  axis(1, at = seq(0, 288, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))
  legend("topleft", paste0("BMI = ", 25 + X.plot[,3]), col = plotCols, lwd = plotLWD, cex = .7)


  ##################################################################
  ## mean + PC basis functions (probability scale)
  ##################################################################

  psi1Hat = apply(beta_psi1.post, c(2,3), mean) %*% t(BS)
  psi1.orth = svd(t(psi1Hat))$u

  psi2Hat = apply(beta_psi2.post, c(2,3), mean) %*% t(BS)
  psi2.orth = svd(t(psi2Hat))$u

  dev.new(width = 11, height = 3.5)
  par(mfrow = c(1,3), mai = c(.85, .85, .2, .2), cex = 1)

  plot(inv.logit(beta.hat[1,] ), type = 'l', lwd = 2, ylim = range(0,1), xlab = "Time",
    ylab = "Fitted Probability")
  points(inv.logit(beta.hat[1,] + 5 * psi1.orth[,1] ), pch = "-", col = "red")  
  points(inv.logit(beta.hat[1,] - 5 * psi1.orth[,1] ), pch = "+", col = "blue")  

  plot(inv.logit(beta.hat[1,] ), type = 'l', lwd = 2, ylim = range(0,1), xlab = "Time",
    ylab = "Fitted Probability")
  points(inv.logit(beta.hat[1,] + 5 * psi1.orth[,2] ), pch = "-", col = "red")  
  points(inv.logit(beta.hat[1,] - 5 * psi1.orth[,2] ), pch = "+", col = "blue")  

  matplot(matrix(1:D, D, 2), t(psi1.true), type = 'l')
  matpoints(matrix(1:D, D, 2), psi1.orth[,1:2], type = 'l')
  
  
  dev.new(width = 11, height = 3.5)
  par(mfrow = c(1,3), mai = c(.85, .85, .2, .2), cex = 1)

  plot(inv.logit(beta.hat[1,] ), type = 'l', lwd = 2, ylim = range(0,1), xlab = "Time",
    ylab = "Fitted Probability")
  points(inv.logit(beta.hat[1,] + 5 * psi2.orth[,1] ), pch = "-", col = "red")  
  points(inv.logit(beta.hat[1,] - 5 * psi2.orth[,1] ), pch = "+", col = "blue")  

  plot(inv.logit(beta.hat[1,] ), type = 'l', lwd = 2, ylim = range(0,1), xlab = "Time",
    ylab = "Fitted Probability")
  points(inv.logit(beta.hat[1,] + 5 * psi2.orth[,2] ), pch = "-", col = "red")  
  points(inv.logit(beta.hat[1,] - 5 * psi2.orth[,2] ), pch = "+", col = "blue")  

  matplot(matrix(1:D, D, 2), t(psi2.true), type = 'l')
  matpoints(matrix(1:D, D, 2), psi2.orth[,1:2], type = 'l')
  
  
  ##################################################################
  ## Fitted values for one subject
  ##################################################################

  dev.new(width = 14, height = 3.5)
  par(mfrow = c(1,4), mai = c(.85, .85, .2, .2), cex = 1)
  
  subj = 4

  matplot(matrix(1:D, D, 200), inv.logit(yi.post[subj,,1:200]), lty = 1, col = "#0000002b", lwd = 1, type ='l', 
    ylim = range(0,1), xlab = "Time", ylab = "Fitted Prob")
  points(pi.true[subj,], type = 'l', col = "red", lwd = 2)
  for(j in 1:3){
    matplot(matrix(1:D, D, 200), inv.logit(yij.post[subj+j,,1:200]), lty = 1, col = "#0000002b", lwd = 1, type ='l', 
      ylim = range(0,1), xlab = "Time", ylab = "Fitted Prob")
    points(pi.true[subj,], type = 'l', col = "red", lwd = 2)
    points(pij.true[subj+j,], type = 'l', col = "blue", lwd = 2)
  }



  ## plot simulated curves
  # matplot(matrix(1:D, nrow = D, ncol = IJ), t(pij.true), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = IJ), t(fixef), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = IJ), t(pca1ef), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = IJ), t(pca2ef), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = IJ), inv.logit(t(fixef+pca1ef)), type = 'l', lty = 1, col = "#0000004b")



}


###############################################################
###############################################################
###############################################################
###############################################################
###############################################################
###############################################################