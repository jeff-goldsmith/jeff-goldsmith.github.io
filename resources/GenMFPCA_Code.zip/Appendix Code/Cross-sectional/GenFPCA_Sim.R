##################################################################
# February 1 2014
# Jeff Goldsmith
#
# Simulations for cross-sectional generalized function-on-scalar
# regression and principal components analysis.
##################################################################

rm(list = ls())

library(splines)
library(rstan)
library(mvtnorm)
library(boot)

set_cppo("fast")    # for best running speed
# set_cppo("debug") # for easier debugging

doFigure = FALSE    ## draw figure

## set working directory and select parameter scenario
param.scen = 1
Date = gsub("-", "", Sys.Date())

###############################################################
## set path to Stan model code
###############################################################

file.source = "./GenFPCA.stan"

###############################################################
## set simulation design elements
###############################################################

NREP = 100                        ## number of iterations
D = 100                           ## size of grid for observations
Kt = 10                           ## dimension of bspline basis
Kp.true = 2                       ## number of true FPC basis functions
grid = seq(0, 1, length = D)

PARAMS = matrix(NA, 4, 2)
count = 1
for(I in c(50, 100)){
  for(Kp in c(2, 5)){
    PARAMS[count, ] = c(I, Kp)
    count = count + 1
  }
}

I = PARAMS[param.scen, 1]         ## number of subjects
Kp = PARAMS[param.scen, 2]        ## number of FPC basis functions used for estimation

###############################################################
## define coefficients and PC basis functions
###############################################################

beta.true = matrix(NA, 2, D)
beta.true[1,] = - 1.5 - sin(2*grid*pi) - cos(2*grid*pi)
beta.true[2,] = dnorm(grid, .6, .2) / 20

psi.true = matrix(NA, 2, D)
psi.true[1,] = (1.5 - sin(2*grid*pi) - cos(2*grid*pi) ) / sqrt(322)
psi.true[2,] = sin(4*grid*pi) / sqrt(49.5)

lambda.true = c(3, 1.5)

###############################################################
## Bspline and penalty matrices
###############################################################

BS = bs(1:D, df=Kt, intercept=TRUE, degree=3)

alpha = .1
diff0 = diag(1, D, D)
diff2 = matrix(rep(c(1,-2,1, rep(0, D-2)), D-2)[1:((D-2)*D)], D-2, D, byrow = TRUE)
P0 = t(BS) %*% t(diff0) %*% diff0 %*% BS
P2 = t(BS) %*% t(diff2) %*% diff2 %*% BS
P.mat = alpha * P0 + (1-alpha) * P2

###############################################################
## matrices to keep track of results
###############################################################

COVERAGE.Y = matrix(NA, NREP, 1)
COVERAGE.BETA = matrix(NA, NREP, 2)
TIME = matrix(NA, NREP, 4)
MSE.Y = matrix(NA, NREP, 1)
MSE.BETA = matrix(NA, NREP, 2)

colnames(COVERAGE.Y) = colnames(MSE.Y) = c("Level1")
colnames(COVERAGE.BETA) = colnames(MSE.BETA) = c("Int", "Slope")

###############################################################
###############################################################
## start simulation code
###############################################################
###############################################################

for(i.iter in 1:NREP){

  TIME[i.iter, 2] = i.iter
  TIME[i.iter, 3] = I
  TIME[i.iter, 4] = Kp

  ## fixed effect design matrix
  X.des = cbind(1, rnorm(I, 0, 5))
  
  p = dim(X.des)[2]

  ###############################################################
  ## generate full data for this iteration
  ###############################################################
  
  ## fixed effects
  fixef = X.des %*% beta.true

  ## pca effects
  c.true = rmvnorm(I, mean = rep(0, 2), sigma = diag(lambda.true))
  pcaef = c.true %*% psi.true

  pi.true = inv.logit(fixef + pcaef)
  Yi.obs = matrix(NA, I, D)
  for(i in 1:I){
  	for(j in 1:D){
  	  Yi.obs[i,j] = rbinom(1, 1, pi.true[i,j])
    }
  }

  ###############################################################
  ## STAN
  ###############################################################

  time.start = proc.time()

  dat = list(Y = Yi.obs, X = X.des, BS = BS, 
             I = I, D = D, p = p, Kt = Kt, Kp = Kp, 
             PenMat = P.mat)
           
  GenFPCA.fit = stan(model_name="Binary FPCA", file = file.source, 
                 data=dat, iter = 5000, warmup = 2000,
                 control = list(adapt_delta = .65),
                 chains = 1, verbose = FALSE)

  time.stop = proc.time()
  TIME[i.iter,1] = (time.stop - time.start)[3]

  ##################################################################
  ## some post processing
  ##################################################################

  beta.post = extract(GenFPCA.fit, "beta")$beta
  beta_psi.post = extract(GenFPCA.fit, "beta_psi")$beta_psi
  c.post = extract(GenFPCA.fit, "c")$c
  
  betaHat.post = array(NA, dim = c(p, D, dim(c.post)[1]))
  for(i in 1:dim(c.post)[1]) {
    betaHat.post[,,i] = (beta.post[i,,] %*% t(BS))
  }

  y.post = array(NA, dim = c(I, D, dim(c.post)[1]))
  for(i in 1:dim(c.post)[1]) {
    y.post[,,i] = X.des %*% (beta.post[i,,] %*% t(BS)) + c.post[i,,] %*% (beta_psi.post[i,,] %*% t(BS))
  }
  
  ## coverage for y's
  Yhat = apply(y.post, c(1,2), mean)

  y.LB = apply(y.post, c(1,2), quantile, c(.025))
  y.UB = apply(y.post, c(1,2), quantile, c(.975))

  COVERAGE.Y[i.iter, 1] = mean(logit(pi.true) < y.UB & logit(pi.true) > y.LB)  
  MSE.Y[i.iter, 1] = mean((logit(pi.true) - Yhat)^2)
    
  ## coverage for mu
  beta.hat = apply(betaHat.post, c(1,2), mean)

  beta.LB = apply(betaHat.post, c(1,2), quantile, c(.025))
  beta.UB = apply(betaHat.post, c(1,2), quantile, c(.975))

  COVERAGE.BETA[i.iter, ] = sapply(1:2, function(u) mean(beta.true[u,] < beta.UB[u,] & beta.true[u,] > beta.LB[u,]))
  MSE.BETA[i.iter, ] = sapply(1:2, function(u) mean((beta.true[u,] - beta.hat[u,])^2))

  ###############################################################
  ## save data during each iteration
  ###############################################################

  filename = paste0(Date, "_GenFPCA_Res_S", param.scen, ".RDA")
  save(COVERAGE.Y, COVERAGE.BETA, MSE.Y, MSE.BETA, TIME, 
       file = filename)

  cat("REP: ", i.iter, "\n")

}

###############################################################
###############################################################
## end sim
###############################################################
###############################################################

if(doFigure){

  ###############################################################
  ## the following assumes that one iteration of the simulation
  ## has been conducted. the figure in the paper uses param.scen = 4 
  ## and i.iter = 1.
  ###############################################################

  dev.new(width = 11, height = 3.5)
  par(mfrow = c(1,3), mai = c(.85, .85, .2, .2))
  layout(matrix(c(1,2,4,1,3,4), 2, 3, byrow = TRUE), widths = c(1,1,1), heights = c(1,1))
  par(cex = .95)
  ## show simulated data
  matplot(matrix(1:D, nrow = D, ncol = I), t(pi.true), type = 'l', lty = 1, col = "#0000004b",
          ylab = expression(mu[i](t)), xlab = "Time", xaxt = "n")
  axis(1, at = seq(0, D, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))

  ## other simulated data plots
  # matplot(matrix(1:D, nrow = D, ncol = I), t(fixef), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = I), t(pcaef), type = 'l', lty = 1, col = "#0000004b")
  # matplot(matrix(1:D, nrow = D, ncol = I), t(pi.true), type = 'l', lty = 1, col = "#0000004b")

  ## true and estimated beta_0
  matplot(matrix(1:D, nrow = D, ncol = 4), cbind(beta.true[1,], beta.hat[1,], beta.LB[1,], beta.UB[1,]), 
          type = 'l', col = c(1, 2, 2, 2), lty = c(1, 2, 3, 3), lwd = c(2,2,1,1),
          ylab = expression(beta[0](t)), xlab = "Time", xaxt = "n")
  axis(1, at = seq(0, D, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))

  ## true and estimated beta_1
  matplot(matrix(1:D, nrow = D, ncol = 4), cbind(beta.true[2,], beta.hat[2,], beta.LB[2,], beta.UB[2,]), 
          type = 'l', col = c(1, 2, 2, 2), lty = c(1, 2, 3, 3), lwd = c(2,2,1,1),
          ylab = expression(beta[1](t)), xlab = "Time", xaxt = "n")
  axis(1, at = seq(0, D, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))

  ## observed and fitted values
  subj = 4
  
  yi.post = matrix(NA, nrow = 200, ncol = D)
  for(i in 1:200) {
    yi.post[i,] = X.des[subj,] %*% betaHat.post[,,i] + 
                   c.post[i,subj,] %*% (beta_psi.post[i,,] %*% t(BS))
  }

  plot(Yi.obs[subj,], pch = 19, cex = .5, col = "blue", 
        ylab = "P(active)", xlab = "Time", xaxt = "n", ylim = range(0,1))
  matpoints(matrix(1:D, D, 200), inv.logit(t(yi.post)), lty = 1, col = "#0000002b", lwd = 1, type ='l', ylim = range(0,1))
  points(1:D, pi.true[subj,], type = 'l', col = 3, lwd = 2)
  axis(1, at = seq(0, D, length = 5), labels = paste0(c(0,6,12,18,24), ":00"))

  ## MSE for estimated fixed effects and y's
  sapply(1:2, function(u) mean((beta.true[u,] - beta.hat[u,])^2))
  mean((logit(pi.true) - Yhat)[subj,]^2)
}


###############################################################
###############################################################
###############################################################
###############################################################
###############################################################
###############################################################