This folder contains the code used in the simulations for 

"Generalized Multilevel Functional-on-Scalar Regression and Principal Component Analysis"

by Jeff Goldsmith, Vadim Zipunnikov and Jennifer Schrack.

There are two directories, one for cross-sectional simulations and one for multilevel simulations. In each directory, there is a primary .R file. This code
-- generates simulated data sets;
-- estimates the function-on-scalar regression model using the proposed Bayesian method by calling Stan;
-- saves MSEs and coverage probabilities for each iteration.
In addition, each directory contains a .stan file that implements the proposed model.