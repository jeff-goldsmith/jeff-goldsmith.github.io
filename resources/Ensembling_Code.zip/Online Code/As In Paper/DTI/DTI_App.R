###############################################################################
# Feb 17 2013
#
# Fabian Schiepl and Jeff Goldsmith
#
# Real data analysis of the DTI dataset used in the final manuscript. Executing
# the code below will provide results and figures that appear in the paper.
###############################################################################


rm(list=ls())

setwd("~/Dropbox/Work/Current Projects/Super Learner/Applications/DTI")
source("Library.R")

use.methods <- c(
        "wrap.flm",  "wrap.pfr",  "wrap.flirti", "wrap.wnet", # FLMs
        "wrap.pclm", "wrap.fpcr", #PC-based FLMs
        "wrap.spikeslabgam", #PC-based FAM
        "wrap.sisr", "wrap.psr",  #Single-index models
        "wrap.fgam", "wrap.fregrenp", #non-linear/non-parametric
        "wrap.plsreg2", #PLS
        "wrap.lasso", "wrap.gbm", "wrap.rf") #lasso, boosted trees, rf


###############################################################################
## helper functions
###############################################################################

doOneRep <- function(spect, target, train, use.methods, J=10, PCA=FALSE){
    res <- superfunc(y.train=target[train], w.train=spect[train, , drop=FALSE], 
            w.valid=spect[-train, , drop=FALSE], methods=use.methods, J = J, PCA = PCA)
    
    res <- data.frame(t(c(colMeans((target[-train] - do.call(cbind, head(res, -2)))^2),
            colMeans((target[-train] - res$Z.oos)^2))))
    
    return(res)
}


doOneSet <- function(name, spect, target, use.methods, reps=20, seed=NULL,
        ntrain=floor(.7*length(target)), J=10, PCA=FALSE, cores=reps, useParallel=TRUE){
    stopifnot(length(target) == nrow(spect))
    
    if(useParallel) {
        stopifnot(require(parallel))
        options(mc.cores=cores)
        this.lapply <- function(X, FUN){
            mclapply(X=X, FUN=FUN, mc.preschedule = FALSE, mc.allow.recursive = FALSE)
        }
    } else this.lapply <- lapply
    
    if(is.null(seed)){
        seed <- runif(1, 0, 1e9)      
    } 
    
    n <- length(target)

    res <- this.lapply(1:reps, function(i){
                seed.i <- as.integer(seed + i)
                set.seed(seed.i)
                train <- sort(sample(1:n, ntrain))

    time.start = proc.time()
                
                tmp <- doOneRep(spect, target, train=train, use.methods, J=J, PCA=PCA)

    time.stop = proc.time()
                
                res <- cbind(tmp, name=name, rep=i, seed=seed.i, ntrain=ntrain, 
                        benchmark.oos = mean((target[-train] - mean(target[train]))^2),
                        benchmark.is = mean((target[-train] - mean(target[-train]))^2),
                        time = (time.stop - time.start)[3])
                cat("\n", name,": replication ", i, " done.\n")
                return(res)
            })
    res <- do.call(rbind, res)
    
    return(res) 
}

###############################################################################
## data input and plot
###############################################################################

library(refund)
data(DTI)

DTI = DTI[complete.cases(cbind(DTI$pasat, DTI$cca)),]

set = list(spect=DTI$cca,
           target=DTI$pasat,
           name="DTI_App_Results")


###############################################################################
## analysis
##############################################################################

#how many processes to spawn simultaneously:
cores <- 1

            ret <- try(doOneSet(set$name, set$spect, set$target, use.methods, reps=20, seed=151,
                            cores=cores,  ntrain=floor(.7*length(set$target)), J=10, PCA=FALSE,
                            useParallel = FALSE)) 
            filename <- paste0(set$name, ".Rdata")
            try(save(ret, file=filename))

###############################################################################
## post-processing to find rankings, relative MSEs
##############################################################################

## load results if analysis has already been done
load("DTI_App_Results.Rdata")

mean(ret$time)

library(ggplot2)
library(plyr)
library(scales)
library(gridExtra)
library(reshape2)

ret <- melt(ret, id.vars=c("name","rep","seed","ntrain","time"), value.name="mse")
colnames(ret)[7] = "mse"

#add ranks, relative errors for each replicate
ret <- ddply(ret, ~ name + rep, function(dd){
  #browser()
           
  #rank with smallest first, NAs as NA
  ranks <- ranks.single <- ranks.ensemble <- rep(NA, nrow(dd))
            
  ranks.single[grepl("wrap", dd$variable)] <- ordered(
    rank(dd[grepl("wrap", dd$variable), "mse"], na.last = "keep"))
            
  ranks.ensemble[grepl("pred.vals", dd$variable)] <- ordered(
    rank(dd[grepl("pred.vals", dd$variable),"mse"], na.last = "keep"))
            
  ranks[grepl("pred.vals", dd$variable) | grepl("wrap", dd$variable)] <- ordered(
    rank(dd[grepl("pred.vals", dd$variable) | grepl("wrap", dd$variable), "mse"], 
    na.last = "keep"))
            
  dd <- data.frame(dd, rank=ranks, rank.single=ranks.single, 
    rank.ensemble=ranks.ensemble)
  dd$rmse <- sqrt(dd$mse)
            
  # relMSE = MSE/min(MSE)
            
  dd$relmse <- with(dd, mse/min(mse, na.rm=TRUE))
  dd$relmse.single[grepl("wrap", dd$variable)] <- with(dd[grepl("wrap", dd$variable),],
    mse/min(mse, na.rm=TRUE))
  dd$relmse.ensemble[grepl("pred.vals", dd$variable)] <- with(dd[grepl("pred.vals", dd$variable),],
    mse/min(mse, na.rm=TRUE))
            
  # relRMSE = RMSE/min(RMSE)
  dd$relrmse <- with(dd, rmse/min(rmse, na.rm=TRUE))
  dd$relrmse.single <- dd$relmse.ensemble <- NA
  dd$relrmse.single[grepl("wrap", dd$variable)] <- with(dd[grepl("wrap", dd$variable),],
    rmse/min(rmse, na.rm=TRUE))
  dd$relrmse.ensemble[grepl("pred.vals", dd$variable)] <- with(dd[grepl("pred.vals", dd$variable),],
    rmse/min(rmse, na.rm=TRUE))
            
            
  dd$ensemble <- grepl("pred.vals", dd$variable)
  return(dd)                    
})

##############################################################################
## figures
##############################################################################

attach(set)

par(mar=c(1,1,0,0))

clrs <- rev(colorRampPalette(c("blue", "green", "yellow", "red"))(40))    

x.seq = seq(0, 1, length = dim(spect)[2])

proj <- persp(x=x.seq, 
              y=seq(min(target), max(target), l=length(target)), 
              z=t(spect),
              xlab="Distance Along Tract",
              ylab="PASAT Score",
              zlab="Fractional Anisotropy",
              col=NA, border=NA,
              ticktype = "detailed", axes=TRUE,
              theta=30, phi=30)

colfct <- as.numeric(cut(target, 40))
o <- rev(order(target))
for(i in o){
  lines(trans3d(x=x.seq, 
                y=rep(target[i], ncol(spect)),
                z=spect[i,], pmat=proj), 
        col=clrs[colfct[i]])
}

## plot results
ggplot(ret, 
       aes(x=variable, y=relrmse, fill=ensemble)) + geom_line(aes(group=rep), alpha=.05) +
         geom_boxplot() + theme_bw(base_size=16) + scale_fill_manual(values=c("white","grey")) +
         theme(axis.text.x=element_text(angle=40, hjust=1), legend.position="none")  +
         coord_trans(ytrans = "log2", limy=c(.95, 2)) +  
         labs(x="", y="relative RMSE", title=paste("Relative RMSE"))

detach(set)

###############################################################################
###############################################################################
###############################################################################
###############################################################################
###############################################################################
###############################################################################


#DEBUGGING STUFF:
if(FALSE){
    
    test.methods <- use.methods
    
        
    testsets <- sets[6]
    testres <- lapply(testsets, function(set){
                ret <- try(doOneSet(set$name, set$spect, set$target, use.methods, reps=2, seed=NULL,
                                cores=cores,  ntrain=floor(.7*length(set$target)), J=10, PCA=FALSE, useParallel=FALSE)) 
                filename <- paste0("test_set_",set$name,"_", Sys.Date(), ".Rdata")
                try(save(ret, file=filename))
                cat("########################\n\n", filename, "done.\n########################\n\n")
                return(ret)
            })
    
    
    # tecator:
    # n=215
    # DTI:
    # n=229
    # cookie: 
    # n=72
    # gasoline:
    # n=60
    
    train <- 1:42
    spectTrain <- sets[[6]]$spect[train, ]
    spectTest <- sets[[6]]$spect[-train, ]
    valTrain <- sets[[6]]$target[train]
    testflm <- wrap.flm(spectTrain, spectTest, valTrain)
    
    testrf <- wrap.rf(spectTrain, spectTest, valTrain)
    
}    