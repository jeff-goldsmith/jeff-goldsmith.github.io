##################################################################
# Sept 15 2012
# Fabian Schiepl and Jeff Goldsmith
#
# the functions superfunc and superfunc.boot implement the super 
# learner for scalar-on-function regression and the bootstrap version
# of this, respectively.
#
# also included is a library of estimators used for super learner.
#
# there's a lot here.
# lines 20 - 125 are the superfunc() functions.
# lines 135 - 880 are wrappers for various methods. some of these
#   include functions for the methods themselves.
# lines 890 - 1280 are local verions of three functions, that either 
#   silent print statements or take additional arguments.
# lines 1280 - 2900 are copied from my.sisr, marx.sisr, and function.dump
##################################################################

if(FALSE){
    install.packages(c("fda","mgcv", "robustbase", "pcaPP", "chemometrics", "refund", "lpSolve", "gbm",
                    "glmnet", "randomForest", "wavethresh","monomvn", "nnls", "ppls",
                    "mboost", "spikeSlabGAM", "irlba", "svcm", "fda.usc", "lpSolve"), 
        repos="http://cran.r-project.org")    
}


##################################################################
##################################################################
## superfunc - implement the cross-validation procedure
##################################################################
##################################################################

superfunc = function(y.train, w.train, w.valid, methods, J = 5, PCA = TRUE,
        grid.length.PCA=128, nbasis.PCA=15, npc=15){
    stopifnot(require(nnls))
    stopifnot(require(refund))
    
    
    I = dim(w.train)[1]
    I.oos = dim(w.valid)[1]
    
    ##split into methods that use FPC loadings and those that use the function itself.
    fpc.methods <- paste("wrap", c("hs", "ng", "pclm", "pclmsisr", "spikeslabgam", 
                    "pcgamboost"), sep = ".")
    where.fpc.methods <- which(methods %in% fpc.methods)
    
    if(PCA | length(where.fpc.methods)){  
        W = fpca.sc.grid(Y = w.train, Y.pred = rbind(w.train, w.valid), grid.length = grid.length.PCA, 
                nbasis = nbasis.PCA, npc = npc)
    }
    if(PCA){
        w.train = W$Yhat[1:I,]
        w.valid = W$Yhat[(I+1):(I+I.oos),]
    }
    if(length(where.fpc.methods)){
        w.trainfpc <- W$scores[1:I,]
        w.validfpc <- W$scores[(I+1):(I+I.oos),]
    }
    
    
    ## matrix Z contains predicted values for each method based on J fold CV
    Z = matrix(NA, nrow = I, ncol = length(methods))
    colnames(Z) <- methods
    
    ## assign subjects to exclusive and exhaustive sets for cross-validation
    folds = sample(rep(1:J, ceiling(I/J))[1:I], I, replace = FALSE)
    
    for(j in 1:J){
        Tj = which(folds != j)
        Vj = which(folds == j)
        
        Z[Vj, -where.fpc.methods] = sapply(1:length(methods[-where.fpc.methods]), function(u) {
#    	        print(methods[u])    ## used for troubleshooting
                    do.call(methods[-where.fpc.methods][u], list(spectTrain = w.train[Tj,], valTrain = y.train[Tj], spectTest = w.train[Vj,]))
                })
        if(length(where.fpc.methods)){
            Z[Vj, where.fpc.methods] = sapply(1:length(methods[where.fpc.methods]), function(u) {
#    	        print(methods[u])    ## used for troubleshooting
                        do.call(methods[where.fpc.methods][u], list(spectTrain = w.trainfpc[Tj,], valTrain = y.train[Tj], spectTest = w.trainfpc[Vj,]))
                    })
        }
    }
    
    Z.oos = matrix(NA, nrow = I.oos, ncol = length(methods))
    colnames(Z.oos) <- methods
    
    ## fit each estimator to full data and make predictions on test data     
    Z.oos[, -where.fpc.methods] = sapply(1:length(methods[-where.fpc.methods]), function(u) {
                do.call(methods[-where.fpc.methods][u], list(spectTrain = w.train, valTrain = y.train, spectTest = w.valid))
            })
    if(length(where.fpc.methods)){
        Z.oos[, where.fpc.methods] = sapply(1:length(methods[where.fpc.methods]), function(u) {
                    do.call(methods[where.fpc.methods][u], list(spectTrain = w.trainfpc, valTrain = y.train, spectTest = w.validfpc))
                })
    }
    ## find weightings using linear regression
    ## find weightings using lasso
    err = which(is.na(apply(Z, 2, sum)))
    if(length(err)>0) {
        Z <- Z[,-err]
        Z.oos <- Z.oos[,-err]
    }
    
    pred.vals.lass = wrap.lasso(spectTrain = Z, spectTest = Z.oos, valTrain = y.train)
        
    fit = lm(y.train~Z-1)
    beta = fit$coef
    pred.vals.lm = Z.oos %*% beta
        
    fit.nnls <- nnls(Z, y.train)
    beta.nnls <- fit.nnls$x
    pred.vals.nnls <- Z.oos %*% beta.nnls
    
    svd.ZZ <- svd(rbind(Z, Z.oos), nu=ncol(Z), nv=0) 
    pred.vals.svd <- wrap.lasso(spectTrain = svd.ZZ$u[1:nrow(Z),], 
                          spectTest = svd.ZZ$u[-(1:nrow(Z)),], 
                          valTrain = y.train)
                  
    pred.vals.rf <- wrap.rf(spectTrain = Z, spectTest = Z.oos, valTrain = y.train)               
                  
    
    ## find weightings using choice of best within-sample
    MSL = sapply(1:ncol(Z), function(u) mean((y.train - Z[,u])^2))
    pred.vals.best = Z.oos[,which.min(MSL)]
    
    ret <- list(pred.vals.svd=drop(pred.vals.svd), pred.vals.lm = drop(pred.vals.lm), 
            pred.vals.lass = drop(pred.vals.lass), pred.vals.nnls = drop(pred.vals.nnls), 
            pred.vals.rf = drop(pred.vals.rf), pred.vals.best = drop(pred.vals.best), 
            Z.oos=Z.oos, Z=Z)
    ret
    
}





##################################################################
##################################################################
## superfunc.boot - bootstrap the super learner
##################################################################
##################################################################

superfunc.boot = function(y.train, w.train, w.valid, J = 5, NBS = 100){
    
    I = dim(w.train)[1]
    I.oos = dim(w.valid)[1]
    
    pred.boot = matrix(NA, nrow = NBS, ncol = I.oos)
    var.boot = matrix(NA, nrow = NBS, ncol = I.oos)
    
    ## doing sampling just one time - saves the looping
    ## each column is a sample
    samples = matrix(sample(1:I, I*NBS, replace = TRUE), ncol=NBS)
    for(i.boot in 1:NBS){
        
        set.seed(i.boot)
        
#        boot.samp = sample(1:I, I, replace = TRUE)   
		boot.samp <- samples[,i.boot]
        Y.boot = Y[boot.samp]
        X.boot = X.obs[boot.samp,]
        
        fit.iter = invisible(superfunc(y.train = Y.boot, w.train = X.boot, w.valid = X.obs.oos))
        
        pred.boot[i.boot,] = fit.iter$pred.vals
        var.boot[i.boot,] = fit.iter$mod.var
    }
    
    pred.vals = apply(pred.boot, 2, mean); sd.y = apply(pred.boot, 2, sd)
    iter.var = apply(pred.boot, 2, var) + apply(var.boot, 2, mean)
    
    ret = list(pred.vals, pred.boot, iter.var)
    names(ret) = c("pred.vals", "pred.boot", "iter.var")
    ret
    
}








##################################################################
##################################################################
## PFR - modified version of pfr.bslp from testing project
##################################################################
##################################################################

wrap.pfr <- function(spectTrain, spectTest, valTrain){
    
    kz = kb = 20
    
    stopifnot(require(mgcv))
    
    I = length(valTrain)
    t = seq(0, 1, length = dim(spectTrain)[2])
    
    # set the basis to be used for beta(t)
    phi = cbind(1, bs(t, df=kb-1, intercept=FALSE, degree=2))
    
    XJ = spectTrain %*% phi
    XJ.valid = spectTest %*% phi
    
    X = cbind(rep(1, I), XJ)
    
    ## set design and penalty matrices depending
    fixed.mat = X[,1:(1+1)]
    rand.mat = X[,(1+2):(1+kb)]
    
    temp=matrix(0, nrow=kb-1, ncol=kb-1)
    for(i in 1:(kb-1)){
        for(j in 1:(kb-1)){
            temp[i,j]=min(i,j)-1
        }
    }
    D = matrix(1, nrow=kb-1, ncol=kb-1)+temp
    Dinv=solve(D)
    PenMat = list(length = 1)
    PenMat[[1]] = cbind(matrix(0, 1+kb, 1+1), rbind(matrix(0, 1+1, kb-1), Dinv))
    
    m = try(gam(valTrain ~ X - 1, paraPen = list(X = PenMat), method = "REML", family = "gaussian"))
    
    if(class(m)[1] != "try-error"){
        
        coefs = m$coef
        
        X.valid = cbind(1, XJ.valid)
        pred = X.valid %*% coefs
        
        return(pred)    
    } else return(rep(NA, nrow(spectTest)))
    
}

##################################################################
##################################################################
## fpcr
##################################################################
##################################################################

wrap.fpcr <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(refund))
    ntrain <- nrow(spectTrain)
    ntest <- nrow(spectTest)
    
    m <- try(fpcr(y=c(valTrain, rep(0,ntest)), nbasis=min(ntrain+ntest-1, 80), 
                    ncomp=30, xfuncs=rbind(spectTrain, spectTest), 
                    weights=c(rep(1, ntrain), rep(0, ntest))))
    if(class(m)[1] != "try-error"){
        pred <- fitted(m)[-(1:ntrain)]
        # sqrt(mean((pred - val2)^2))
        return(pred)    
    } else return(rep(NA, nrow(spectTest)))
    
}

##################################################################
##################################################################
## flm
##################################################################
##################################################################

wrap.flm <- function(spectTrain, spectTest, valTrain, nc=ncol(spectTrain)){
    stopifnot(require(mgcv))
    ntrain <- nrow(spectTrain)
    ntest <- nrow(spectTest)
    freq <- matrix(1:ncol(spectTrain), ncol=ncol(spectTrain), nrow=ntrain, byrow=TRUE)
    
    m <- try(gam(valTrain ~ s(freq, by=spectTrain, k=min(nrow(spectTrain)-1, 40), bs="ad")))
    
    if(class(m)[1] != "try-error"){
        freq <- matrix(1:ncol(spectTrain), ncol=ncol(spectTrain), nrow=ntest, byrow=TRUE)
        pred <- predict(m, newdata=list(spectTrain=spectTest, freq=freq))
        # sqrt(mean((pred - val2)^2))
        return(pred)  
    } else return(rep(NA, nrow(spectTest)))
    
}

##################################################################
##################################################################
## flirti - modified from original flirti code; intercept and 
## some options have been removed.
##################################################################
##################################################################

wrap.flirti  = function(spectTrain, spectTest, valTrain, deriv=2, weight=1, sigma = .001){
    p <- ncol(spectTrain)
    beta.zero <- 0
    extra.con <- NULL
    if (length(weight)>1)
        deriv <- (1:4)[weight[-1]>0]  else{
        
        weight <- c(weight,0,0,0,0)
        weight[deriv+1] <- 1}
    
    weights <- rep(weight[1],2*p)
    for (i in 2:5)
        if (weight[i]>0)
            weights <- c(weights,rep(weight[i],2*(p-i+1)))
    
    A <- makeA(p,deriv,FALSE)
    colscale <- apply(spectTrain,2,function(x){sqrt(sum(x^2))})
    newW <- t(t(spectTrain)/colscale)
    
    m <- try(linearoptim(valTrain,newW,sigma,sqrt(2*p),weights,A%*%diag(1/colscale),extra.con))
    
    if(class(m)[1] != "try-error"){
        beta <- m$eta/colscale
        pred = spectTest%*%beta
        return(pred)    
    } else return(rep(NA, nrow(spectTest)))
    
}


## helper functions from James' code
`linearoptim` <-
        function(Y,X,sigma,lambdap,weights=1,A,extra.con=NULL){
    stopifnot(require(lpSolve))
    p <- ncol(X)
    K <- nrow(A)
    f.obj <- weights
    XX <- t(X)%*%X
    b1 <- lambdap*sigma+as.vector(t(X)%*%Y)
    b2 <- lambdap*sigma-as.vector(t(X)%*%Y)
    f.con1 <- cbind(XX,-XX,matrix(0,p,2*K))
    f.con2 <- cbind(-XX,XX,matrix(0,p,2*K))
    f.con3 <- cbind(A,-A,diag(K),-diag(K))
    f.con <- rbind(f.con1,f.con2,f.con3)
    f.rhs <- c(b1,b2,rep(0,K))
    f.dir <- c(rep("<=",2*p),rep("==",K))
    if (!is.null(extra.con)){
        f.con <- rbind(f.con,extra.con)
        f.rhs <- c(f.rhs,0)
        f.dir <- c(f.dir,"==")
    }
    lpout <- lp("min",f.obj,f.con,f.dir,f.rhs)
    eta <- lpout$sol[1:p]-lpout$sol[(p+1):(2*p)]
    gamma <-lpout$sol[(2*p+1):(2*p+K)]-lpout$sol[(2*p+K+1):(2*p+2*K)]#gamma here is acutally -gamma
    if (lpout$status!=0){
        print(paste("Error: Code = ",lpout$status))
    }
    list(eta=eta,gamma=gamma,lpfit=lpout,code=lpout$status)}

`makeA` <-
        function(p,deriv=2,int=F){
    A <- NULL
    if (!is.na(match(1,deriv))){
        a <- c(-1,1,rep(0,p-1))
        K <- p-1
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(2,deriv))){
        a <- c(1,-2,1,rep(0,p-2))
        K <- p-2
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(3,deriv))){
        a <- c(-1,3,-3,1,rep(0,p-3))
        K <- p-3
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(4,deriv))){
        a <- c(-1,4,-6,4,-1,rep(0,p-4))
        K <- p-4
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (int)
        A <- cbind(0,A)
    A}


##################################################################
##################################################################
## wavelet+lasso; note predictors have to have length of 2^k for some k.
##################################################################
##################################################################

wrap.wnet = function(spectTrain, spectTest, valTrain){
    
    stopifnot(require(refund))
    ntrain <- nrow(spectTrain)
    ntest <- nrow(spectTest)
    
    # make sure we have 2^k columns:
    if(log2(ncol(spectTrain))%%1 != 0){
        padding <- 2^ceiling(log2(ncol(spectTrain))) -ncol(spectTrain)
        spectTrain <- cbind(spectTrain, matrix(0, ncol=padding, nrow=nrow(spectTrain)))
        spectTest <- cbind(spectTest, matrix(0, ncol=padding, nrow=nrow(spectTest)))
    }
    
    m <- try(wnet.pred(y=valTrain, min.scale = 4, alpha = 1, xfuncs=spectTrain, xfuncs.pred = spectTest))
    if(class(m)[1] != "try-error"){
        pred <- m$fitted
        # sqrt(mean((pred - val2)^2))
        return(pred)    
    } else return(rep(NA, nrow(spectTest)))
    
}

## function for wnet that gives predictions; also silences output
wnet.pred =
        function (y, xfuncs, xfuncs.pred, min.scale, alpha, lambda = NULL, standardize = FALSE, 
                covt = NULL, pen.covt = FALSE, filter.number = 10, wavelet.family = "DaubLeAsymm", 
                family = "gaussian", nfold = 5, compare.fits = FALSE, store.cv = FALSE, 
                ...) 
{
    n <- length(y)
    if (!is.array(xfuncs) || !length(dim(xfuncs)) %in% 2:3) 
        stop("Argument xfuncs is invalid: must either be a 2D or 3D array.")
    dim.sig <- length(dim(xfuncs)) - 1
    if (dim(xfuncs)[1] != n) 
        stop("Arguments y and xfuncs has invalid lengths: ", 
                length(y), " and ", dim(xfuncs)[1], ".")
    if (dim(xfuncs)[2] != dim(xfuncs)[1 + dim.sig]) 
        stop("Number of rows and columns in image are not identical: ", 
                dim(xfuncs)[2], " and ", dim(xfuncs)[1 + dim.sig])
    d <- dim(xfuncs)[2]
    if (as.integer(log2(d)) != log2(d)) 
        stop("Argument xfuncs is invalid: the length of xfuncs must be of \n             power of 2.")
    if (sum(!min.scale %in% 0:(log2(d) - 1)) != 0) 
        stop("Argument min.scale is invalid: must be integer(s) between 0 and ", 
                log2(d) - 1, ".")
    if (alpha < 0 || alpha > 1) 
        stop("Argument alpha s invalid: must in [0,1].")
    if (!nfold %in% 1:n) 
        stop("Argument nfold is invalid: must be an integer between 1 and ", 
                n, ".")
    groups <- split(sample(1:n), rep(1:nfold, length = n))
    if (dim.sig == 1) {
        wave.decomp <- wd
        dec <- decomp
        rec <- reconstr
    }    else {
        wave.decomp <- imwd
        dec <- decomp2d
        rec <- reconstr2d
    }
    wdobjs <- apply(xfuncs, 1, wave.decomp, filter.number = filter.number, 
            family = wavelet.family)
    
    
    wdobjs.pred <- apply(xfuncs.pred, 1, wave.decomp, filter.number = filter.number, 
            family = wavelet.family)
    
    
    temp <- dec(wdobjs[[1]])
    p <- length(temp$coef)
    type.gaussian <- ifelse(p > n, "naive", "covariance")
    n.covt <- if (is.null(covt)) 
            { 0 } else ncol(as.matrix(covt))
    penalty.factor <- if (pen.covt) 
            {rep(1, n.covt + p)} else c(rep(0, n.covt), rep(1, p))
    cv.table <- lambda.table <- array(0, dim = c(length(min.scale), 
                    length(alpha), ifelse(is.null(lambda), 100, length(lambda))))
    dimnames(cv.table) <- list(paste("ms=", min.scale, sep = ""), 
            paste("alpha=", alpha, sep = ""), if (is.null(lambda)) NULL else paste("lambda=", 
                                lambda, sep = ""))
    if (compare.fits) {
        fhat.table <- array(0, dim = c(d^dim.sig, nfold, length(min.scale), 
                        length(alpha), ifelse(is.null(lambda), 100, length(lambda))))
        dimnames(fhat.table) <- list(NULL, paste("nfold =", 1:nfold), 
                paste("ms =", min.scale), paste("alpha =", alpha), 
                paste("lambda", if (is.null(lambda)) 1:100 else lambda))
    }
    for (ims in 1:length(min.scale)) {
        coef <- t(array(unlist(sapply(wdobjs, dec, min.scale = min.scale[ims])[1, 
                                ]), dim = c(p, n)))
        for (ialpha in 1:length(alpha)) {
            if (is.null(lambda)) {
                obje <- glmnet(x = as.matrix(cbind(covt, coef)), 
                        y = y, family = family, alpha = alpha[ialpha], 
                        standardize = standardize, type.gaussian = type.gaussian, 
                        penalty.factor = penalty.factor, ...)
                templam <- range(obje$lambda)
                lambda.table[ims, ialpha, ] <- seq(templam[1], 
                        templam[2], length = 100)
            }
            else {
                lambda.table[ims, ialpha, ] <- lambda
            }
            for (ifold in 1:nfold) {
#                cat("min.scale:", min.scale[ims], "\t", "alpha:", 
#                  alpha[ialpha], "fold:", ifold, "\n")
                idxTest <- groups[[ifold]]
                idxTrain <- (1:n)[-idxTest]
                obje <- glmnet(x = as.matrix(cbind(covt, coef)[idxTrain, 
                                ]), y = y[idxTrain], lambda = lambda.table[ims, 
                                ialpha, ], family = family, alpha = alpha[ialpha], 
                        standardize = standardize, type.gaussian = type.gaussian, 
                        penalty.factor = penalty.factor, ...)
                if (compare.fits) {
                    theta.w <- matrix(predict(obje, s = lambda.table[ims, 
                                            ialpha, ], type = "coefficients"), ncol = dim(lambda.table)[3])
                    temp$callInfo$min.scale <- min.scale[ims]
                    for (ilambda in 1:dim(lambda.table)[3]) {
                        temp$coef <- theta.w[, ilambda]
                        fhat.table[, ifold, ims, ialpha, ilambda] <- as.vector(rec(temp))
                    }
                }
                yhat <- predict(obje, newx = as.matrix(cbind(covt, 
                                        coef)[idxTest, ]), s = lambda.table[ims, ialpha, 
                        ], type = "response")
                if (family == "gaussian") 
                    cv.table[ims, ialpha, ] <- cv.table[ims, ialpha, 
                    ] + colMeans((y[idxTest] - yhat)^2)
                else if (family == "binomial") {
                    misclass <- function(x) mean((x > mean(y[idxTrain])) != 
                                        y[idxTest])
                    cv.table[ims, ialpha, ] <- cv.table[ims, ialpha, 
                    ] + apply(yhat > mean(y[idxTrain]), 2, misclass)
                }
            }
        }
    }
    idxmin <- which(cv.table == min(cv.table[cv.table != 0], 
                    na.rm = TRUE), arr.ind = TRUE)
    if (nrow(idxmin) > 1) 
        idxmin <- idxmin[1, ]
    min.scale <- min.scale[idxmin[1]]
    alpha <- alpha[idxmin[2]]
    lambda <- lambda.table[idxmin[1], idxmin[2], idxmin[3]]
    coef <- t(array(unlist(sapply(wdobjs, dec, min.scale = min.scale)[1, 
                            ]), dim = c(p, n)))
    
    
    coef.pred <- t(array(unlist(sapply(wdobjs.pred, dec, min.scale = min.scale)[1, 
                            ]), dim = c(p, dim(xfuncs.pred)[1])))
    
    
    obje <- glmnet(x = as.matrix(cbind(covt, coef)), y = y, lambda = lambda, 
            family = family, alpha = alpha, standardize = standardize, 
            type.gaussian = type.gaussian, penalty.factor = penalty.factor, ...)
    theta <- as.numeric(predict(obje, s = lambda, type = "coefficients"))
    yhat <- predict(obje, newx = as.matrix(cbind(covt, coef)), 
            s = lambda, type = "response")
    
    
    yhat.pred <- predict(obje, newx = as.matrix(cbind(covt, coef.pred)), 
            s = lambda, type = "response")
    
    
    ret = list(yhat.pred); names(ret) = c("fitted")
    return(ret)
}

##################################################################
##################################################################
## partial least squares
##################################################################
##################################################################

wrap.plsreg <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(chemometrics))
    d <- data.frame(valTrain=valTrain)
    d$spectTrain <- spectTrain 
    
    m <- try(mvr_dcv(valTrain~spectTrain,
                    method="simpls",
                    data=d, ncomp=50, repl=2, segments0=5))
    
    m <- try(mvr(valTrain~spectTrain, ncomp=m$afinal,
                    method="simpls",
                    data=d))
    if(class(m)[1] != "try-error"){
        d <- data.frame(valTrain=rep(NA, nrow(spectTest)))
        d$spectTrain <- spectTest 
        pred <- predict(m, newdata=d)
        #sqrt(mean((pred - val2)^2))
        return(pred[,,m$ncomp])
    } else {
        return(rep(NA, nrow(spectTest)))  
    } 
}

# use this, seems much more robust
wrap.plsreg2 <- function(spectTrain, spectTest, valTrain){

    stopifnot(require(ppls))
    m <-  try(penalized.pls.cv(X=spectTrain, y=valTrain, k=15))
    
    if(class(m)[1] != "try-error"){
        pred <- try(drop(new.penalized.pls(m, spectTest)$ypred))
        if(class(pred)[1] != "try-error"){
            return(pred)    
        } 
    }
    return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## robust partial least squares by M regression
##################################################################
##################################################################

wrap.prmreg <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(chemometrics))
    res.prmcv <- try(prm_cv(spectTrain, valTrain, a = 30, opt = "median"))
    m <- try(prm(spectTrain, valTrain, a = res.prmcv$optcomp, opt = "l1m", usesvd = TRUE))
    if(class(m)=="try-error") return(rep(NA, nrow(spectTest)))
    if(class(m)[1] != "try-error"){
        pred <- m$intercept + spectTest %*% m$coef
        #sqrt(mean((pred - val2)^2))
        return(pred)
    }
}

##################################################################
##################################################################
## single-index signal regression
##################################################################
##################################################################

wrap.sisr <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(mgcv))
    res <- try(sisr(y=valTrain, X=spectTrain, maxiter=500, d=40, pendegree=2, plot=FALSE, verbose=FALSE))
    if(class(res)=="try-error") return(rep(NA, nrow(spectTest)))
    if(class(res)!="try-error"){
        pred <- predict.sisr(res, Xnew=spectTest)
        #sqrt(mean((pred - val2)^2))
        return(pred)
    }
}

##################################################################
##################################################################
## penalized signal regression
##################################################################
##################################################################

wrap.psr <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(mgcv))
    res <- try(psr.wrapped(y=valTrain, x=spectTrain, lower = c(-12, 2), 
                    upper = c(-9,6), ngrid = 50))
    if(class(res)=="try-error") return(rep(NA, nrow(spectTest)))
    if(class(res)!="try-error"){
        pred <- predict.sim.psr(res, spectTest)
        #sqrt(mean((pred - val2)^2))
        return(pred)
    }
}

##################################################################
##################################################################
## wavelet signal regression?
##################################################################
##################################################################

wrap.wavesisr <- function(spectTrain, spectTest, valTrain){
    res <- try(wavesisr(y=valTrain, X=spectTrain, maxiter=500, numLevels=8,filterNumber=6, resolution=16384, 
                    alpha=1, plot=FALSE, verbose=FALSE))
    if(class(res)=="try-error") return(rep(NA, nrow(spectTest)))
    if(class(res)!="try-error"){
        pred <- predict.wavesisr(res, Xnew=spectTest)
        #sqrt(mean((pred - val2)^2))
        return(pred)
    }
}

##################################################################
##################################################################
## ad signal regression?
##################################################################
##################################################################

wrap.adsisr <- function(spectTrain, spectTest, valTrain){
    res <- try(adsisr(y=valTrain, X=spectTrain, d=40, plot=FALSE, verbose=FALSE))
    
    if(class(res)=="try-error") return(rep(NA, nrow(spectTest)))
    if(class(res)!="try-error"){
        pred <- predict.adsisr(res, Xnew=spectTest)
        #sqrt(mean((pred - val2)^2))
        return(pred)
    }
}

##################################################################
##################################################################
## random forest
##################################################################
##################################################################

wrap.rf <- function(spectTrain, spectTest, valTrain, 
        ntree=5000, mtry=min(500, ncol(spectTrain)/2)){
    stopifnot(require(randomForest))
    namesx <- paste("x", 1:ncol(spectTrain), sep="")
    colnames(spectTrain) <- colnames(spectTest) <- namesx
    m <- try(randomForest(formula=y~., ntree=5000, mtry=min(500, ncol(spectTrain)/2),  
                    corr.bias=TRUE, data=data.frame(y=valTrain, spectTrain)))  
    if(class(m)[1] != "try-error"){
        pred <- try(predict(m, newdata=data.frame(y=NA, spectTest)))
        # sqrt(mean((pred - val2)^2))
        if(class(pred)!="try-error") return(pred)
    }
    return(rep(NA, nrow(spectTest)))
}


##################################################################
##################################################################
## ridge
##################################################################
##################################################################

wrap.ridge = function(spectTrain, spectTest, valTrain){
    stopifnot(require(glmnet))
    m <- try(cv.glmnet(x=spectTrain, y=valTrain, alpha = 0))
    if(class(m)[1] != "try-error"){
        pred <- try(predict(m, newx=spectTest))
        # sqrt(mean((pred - val2)^2))
        if(class(pred)!="try-error") return(pred)
    }
    return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## lasso
##################################################################
##################################################################

wrap.lasso <- function(spectTrain, spectTest, valTrain){
    stopifnot(require(glmnet))
    m <- try(cv.glmnet(x=spectTrain, y=valTrain, alpha = 1))
    if(class(m)[1] != "try-error"){
        pred <- try(predict(m, newx=spectTest))
        # sqrt(mean((pred - val2)^2))
        if(class(pred)!="try-error") return(pred)
    }
    return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## gbm
##################################################################
##################################################################

wrap.gbm = function(spectTrain, spectTest, valTrain){
    stopifnot(require(gbm))    
    n.trees = 1000
    m = try(gbm(valTrain ~ ., data = as.data.frame(spectTrain),
                    n.trees = n.trees,
                    shrinkage = .022,
                    interaction.dept = 3,
                    train.fraction = .75,
                    distribution = "gaussian",
                    keep.data = FALSE,
                    verbose = FALSE,
                    cv.folds = 5))
    if(class(m)[1] != "try-error"){
        best.iter = gbm.perf(m, method = "cv", plot.it = FALSE)
        pred = predict.gbm(m, newdata = as.data.frame(spectTest), n.trees = best.iter)
        if(class(pred)!="try-error") return(pred)
    }
    return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## blasso (with "h"s and "ng" options)
##################################################################
##################################################################

wrap.blasso <- function(spectTrain, spectTest, valTrain, 
        case,
        T=1500, nc=NCOL(spectTrain)){
    stopifnot(require(monomvn))
    m <- try(blasso(y=valTrain, X = spectTrain[,1:nc], case=case, T=T, verb = 0))
    if(class(m)[1] != "try-error"){
        pred <- spectTest[,1:nc] %*% colMeans(m$beta) + mean(m$mu)
        # sqrt(mean((pred - val2)^2))
        return(pred)
    } else return(rep(NA, nrow(spectTest)))
}
wrap.hs <-  function(spectTrain, spectTest, valTrain){
    wrap.blasso(spectTrain, spectTest, valTrain, "hs")  
} 
wrap.ng <-  function(spectTrain, spectTest, valTrain) {
    wrap.blasso(spectTrain, spectTest, valTrain, "ng")
}    

##################################################################
##################################################################
## pc linear model
##################################################################
##################################################################

wrap.pclm <- function(spectTrain, spectTest, valTrain, nc=NCOL(spectTrain), B=20){
    boot <- function(){
        error <- rep(NA, nc)
        train <- sort(sample(1:nrow(spectTrain), nrow(spectTrain), replace=TRUE))
        test <- setdiff(1:nrow(spectTrain),train)
        for(n in 1:nc){
            y <- valTrain[train]
            X <- spectTrain[train,1:n]
            m <- lm(y ~ X)
            pred <- predict(m, newdata=list(X=spectTrain[test, 1:n]))
            error[n] <- mean((pred-valTrain[test])^2)
            #cat(".")
        }
        #cat("\n")
        return(error)
    } 
    err <- try(replicate(B, boot()))
    use.nc <- try(which.min(rowMeans(err)))
    X <- try(spectTrain[,1:use.nc])
    m <- try(lm(valTrain ~ X))
    if(class(m)[1] != "try-error"){
        pred <-  predict(m, newdata=list(X=spectTest[,1:use.nc]))
        # sqrt(mean((pred - val2)^2))
        return(pred)
    } else return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## pc sisr linear model
##################################################################
##################################################################

wrap.pclmsisr <- function(spectTrain, spectTest, valTrain, nc=NCOL(spectTrain), B=20){
    m <- try(pclmsisr(y=valTrain, X=spectTrain[,1:nc], B=20, 
                    maxiter=1e3, tol=1e-3,
                    plot=FALSE, verbose=FALSE))
    if(class(m)[1] != "try-error"){
        pred <-  predict.pclmsisr(m, Xnew=spectTest[,1:nc])
        # sqrt(mean((pred - val2)^2))
        return(pred)
    } else return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## principal component boosting
##################################################################
##################################################################

wrap.pcgamboost <- function(spectTrain, spectTest, valTrain, nc=NCOL(spectTrain)){
    stopifnot(require(mboost))
    
    myCvrisk <- function(object, pi=NULL, B=100){
        
        selRisk <- function(model, mstop){
            return(list(select = mboost:::selected(model), risk = model$risk()))
        }
        
        win <- Sys.info()["sysname"]=="Windows"
        
        cv <- cvrisk(object, fun  = selRisk, folds=cv(model.weights(object), "bootstrap", B=B), papply=lapply)
        
        #oob risk
        r <- sapply(cv, "[[", "risk")
        attr(r, "mstop") <- which.min(rowSums(r))
        
        ## using cross-validated mstop makes more sense than using arbitrary control parameter 
        m <- attr(r, "mstop") 
        sel <- sapply(cv, function(x) x$select[1:m])
        cand <- unique(as.vector(sel))
        blsel <- lapply(cv, function(x) unique(x$select[1:m]))
        p <- rep(0, length(object$baselearner))
        for(i in cand){
            p[i] <- sum(sapply(blsel, function(x) i %in% x))/B
        }
        
        names(p) <- names(object$baselearner)
        attr(p, "selected") <- which(p >= pi)
        
        return(list(select=p, risk=r))
    }
    
    myMboost <- function(formula, data, family, test=attr(data, "test"), B, pi=0.5, max.iter=1, ...){
        bb <- gamboost(formula, data=data, family=family, ...)
        n <- nrow(data)
        
        if(B > 0){
            cvr <- myCvrisk(object=bb, pi=pi, B=B)
            
            iter <- 1
            while(attr(cvr$r,"mstop") == bb$control$mstop && iter < max.iter){
                cat("refitting model with increased mstop.\n")
                bb <- bb[floor(1.5*bb$control$mstop)]
                bb$control$mstop <- floor(1.5*bb$control$mstop)
                cvr <- myCvrisk(object=bb, pi=pi, B=B)
                iter <- iter + 1
            }
            if(attr(cvr$r,"mstop") == bb$control$mstop) 
                warning("mstop from CV is mstop from fitting - repeat fit with larger mstop or nu.")
            else cat("mstop from cv: ",  attr(cvr$r,"mstop") ,"\n")
            
            stopiter <- attr(cvr$r,"mstop")
        } else {
            stopiter <- mstop(aic <- AIC(bb, method="classical", df="actset"))
            iter <- 1
            while(stopiter == bb$control$mstop && iter < max.iter){
                cat("refitting model with increased mstop.\n")
                bb <- bb[floor(1.5*bb$control$mstop)]
                bb$control$mstop <- floor(1.5*bb$control$mstop)
                stopiter <- mstop(aic <- AIC(bb, method="classical", df="actset"))
                iter <- iter + 1
            }
            cvr <- NULL
        }
        pred <- predict(bb[stopiter], newdata=test)
        
        return(pred)
    }
    
    
    data <- data.frame(y=valTrain, spectTrain[,1:nc])
    pred <- try(myMboost(formula=y~., data=data, family=Gaussian(), test=data.frame(y=NA, spectTest[,1:nc]), 
                    B = 10, control=boost_control(mstop=500, nu=.1, trace=FALSE)))
    
    if(class(pred)!="try-error"){
        # sqrt(mean((pred - val2)^2))
        return(pred)
    } else return(rep(NA, nrow(spectTest)))
}

##################################################################
##################################################################
## spike and slab generalize additive model
##################################################################
##################################################################

wrap.spikeslabgam <- function(spectTrain, spectTest, valTrain, nc=NCOL(spectTrain)){
    stopifnot(require(spikeSlabGAM))
    if(is.null(options()$cores)) options(cores=1)
    
    scspectTrain <- scale(spectTrain[,1:nc])
    scspectTest <- scale(spectTest[,1:nc], 
            center=attr(scspectTrain, "scaled:center"),
            scale=attr(scspectTrain, "scaled:scale"))
    if(is.null(colnames(scspectTrain))) {
        colnames(scspectTrain) <- colnames(scspectTest) <- paste("x",1:nc,sep="")
    }
    scy <- scale(valTrain)/2
    data <- data.frame(y=scy, scspectTrain)
    frml <- formula(paste("y~", paste("sm(", colnames(scspectTrain), ", K=8, centerBase=F)", collapse="+")))
    m <- try(spikeSlabGAM(formula=frml, data=data))
    pred <-  try(2*attr(scy, "scaled:scale")*predict(m, 
                            newdata=data.frame(y=NA, scspectTest)) +
                    attr(scy, "scaled:center"))
    if(class(pred)!="try-error"){
        # sqrt(mean((pred - val2)^2))
        return(pred)
    } else return(rep(NA, nrow(spectTest)))
}


##################################################################
##################################################################
## local version of fpca.sc to take grid length as argument
##################################################################
##################################################################

fpca.sc.grid = 
        function (Y, Y.pred = NULL, nbasis = 10, pve = 0.99, npc = NULL, 
                useSymm = FALSE, 
                makePD = FALSE, grid.length = 128) 
{
    require(mgcv)
    require(MASS)
    if (is.null(Y.pred)) 
        Y.pred = Y
    D = NCOL(Y)
    I = NROW(Y)
    I.pred = NROW(Y.pred)
    d.vec = rep((1:D)/D, each = I)
    gam0 = gam(as.vector(Y) ~ s(d.vec, k = nbasis))
    mu = predict(gam0, newdata = data.frame(d.vec = (1:D)/D))
    
    mu.grid = predict(gam0, newdata = data.frame(d.vec = (1:grid.length)/grid.length))
    
    Y.tilde = Y - matrix(mu, I, D, byrow = TRUE)
    cov.sum = cov.count = cov.mean = matrix(0, D, D)
    for (i in 1:I) {
        obs.points = which(!is.na(Y[i, ]))
        cov.count[obs.points, obs.points] = cov.count[obs.points, 
                obs.points] + 1
        cov.sum[obs.points, obs.points] = cov.sum[obs.points, 
                obs.points] + tcrossprod(Y.tilde[i, obs.points])
    }
    G.0 = ifelse(cov.count == 0, NA, cov.sum/cov.count)
    diag.G0 = diag(G.0)
    diag(G.0) = NA
    if (!useSymm) {
        row.vec = rep((1:D)/D, each = D)
        col.vec = rep((1:D)/D, D)
        row.vec.grid = rep((1:grid.length)/grid.length, each = grid.length)
        col.vec.grid = rep((1:grid.length)/grid.length, grid.length)
        
        fit = gam(as.vector(G.0) ~ te(row.vec, col.vec, k = nbasis))
        
        npc.0 = matrix(predict(fit, newdata = data.frame(row.vec = row.vec, 
                                col.vec = col.vec)), D, D)
        npc.0 = (npc.0 + t(npc.0))/2
        
        npc.0.grid = matrix(predict(fit, newdata = data.frame(row.vec = row.vec.grid, 
                                col.vec = col.vec.grid)), grid.length, grid.length)
        npc.0.grid = (npc.0.grid + t(npc.0.grid))/2
        
    }
    
    evalues = eigen(npc.0, symmetric = TRUE, only.values = TRUE)$values
    evalues = replace(evalues, which(evalues <= 0), 0)
    npc = ifelse(is.null(npc), min(which(cumsum(evalues)/sum(evalues) > 
                                    pve)), npc)
    efunctions = matrix(eigen(npc.0, symmetric = TRUE)$vectors[, 
                    seq(len = npc)], nrow = D, ncol = npc)
    evalues = eigen(npc.0, symmetric = TRUE, only.values = TRUE)$values[1:npc]
    
    efunctions.grid = matrix(eigen(npc.0.grid, symmetric = TRUE)$vectors[, 
                    seq(len = npc)], nrow = grid.length, ncol = npc)
    evalues.grid = eigen(npc.0.grid, symmetric = TRUE, only.values = TRUE)$values[1:npc]
    
    
    cov.hat = efunctions %*% tcrossprod(diag(evalues, nrow = npc, 
                    ncol = npc), efunctions)
    DIAG = (diag.G0 - diag(cov.hat))[floor(D * 0.2):ceiling(D * 
                            0.8)]
    sigma2 = max(mean(DIAG, na.rm = TRUE), 0)
    D.inv = diag(1/evalues, nrow = npc, ncol = npc)
    Z = efunctions
    Y.tilde = Y.pred - matrix(mu, I.pred, D, byrow = TRUE)
    Yhat = matrix(0, nrow = I.pred, ncol = grid.length)
    scores = matrix(NA, nrow = I.pred, ncol = npc)
    VarMats = vector("list", I.pred)
    for (i in 1:I.pred) VarMats[[i]] = matrix(NA, nrow = D, ncol = D)
    diag.var = matrix(NA, nrow = I.pred, ncol = D)
    crit.val = rep(0, I.pred)
    for (i.subj in 1:I.pred) {
        obs.points = which(!is.na(Y.pred[i.subj, ]))
        if (sigma2 == 0 & length(obs.points) < npc) {
            stop("Measurement error estimated to be zero and there are fewer observed points than PCs; scores cannot be estimated.")
        }
        Zcur = matrix(Z[obs.points, ], nrow = length(obs.points), 
                ncol = dim(Z)[2])
        ZtZ_sD.inv = solve(crossprod(Zcur) + sigma2 * D.inv)
        scores[i.subj, ] = ZtZ_sD.inv %*% t(Zcur) %*% (Y.tilde[i.subj, 
                            obs.points])
        Yhat[i.subj, ] = t(as.matrix(mu.grid)) + scores[i.subj, ] %*% 
                t(efunctions.grid)
    }
    
    
    
    
    
    ret.objects = c("Yhat", "mu.grid", "efunctions.grid", "evalues.grid", "npc", "scores")
    ret = lapply(1:length(ret.objects), function(u) get(ret.objects[u]))
    names(ret) = c("Yhat", "mu", "efunctions", "evalues", "npc", "scores")
    return(ret)
}



##################################################################
##################################################################
## local version of fpcr to silent the cat() statement
##################################################################
##################################################################

fpcr = 
        function (y, xfuncs = NULL, fdobj = NULL, ncomp = NULL, pve = 0.99, 
                nbasis = NULL, basismat = NULL, penmat = NULL, argvals = NULL, 
                covt = NULL, mean.signal.term = FALSE, spline.order = NULL, 
                family = "gaussian", method = "REML", sp = NULL, pen.order = 2, 
                cv1 = FALSE, nfold = 5, store.cv = FALSE, store.gam = TRUE, 
                ...) 
{
    require(mgcv)
    require(fda)
    require(MASS)
    n <- length(y)
    do.cv <- FALSE
    if (!nfold %in% 1:n) 
        stop("Argument 'nfold' is invalid: must be an integer between 1 and ", 
                n, ".")
    if (!family %in% c("gaussian", "binomial")) 
        stop("Only 'gaussian' and 'binomial' models are implemented in the current version.")
    if (is.null(fdobj)) {
        if (!is.array(xfuncs) || !length(dim(xfuncs)) %in% 2:3) 
            stop("xfuncs must either be a 2D or 3D array")
        dim.sig <- length(dim(xfuncs)) - 1
        if (is.null(nbasis)) 
            nbasis <- ifelse(dim.sig == 1, 40, 15)
        if (dim.sig == 1) {
            if (!is.list(nbasis) && is.vector(nbasis)) 
                nbs <- matrix(nbasis, ncol = 1)
            else stop("for 1D predictors, 'nbasis' must be a vector")
            siglength <- ncol(xfuncs)
        }
        else {
            if (is.list(nbasis) && length(nbasis) == 2) 
                nbs <- cbind(rep(nbasis[[1]], length(nbasis[[2]])), 
                        rep(nbasis[[2]], each = length(nbasis[[1]])))
            else if (!is.list(nbasis) && is.vector(nbasis)) 
                nbs <- matrix(rep(nbasis, 2), ncol = 2)
            else stop("for 2D predictors, 'nbasis' must either be a vector or a list of length 2")
            d1 <- dim(xfuncs)[2L]
            d2 <- dim(xfuncs)[3L]
            siglength <- d1 * d2
        }
        if (cv1 || length(ncomp) + nrow(nbs) > 2) 
            do.cv <- TRUE
    }
    else if (cv1 || length(ncomp) > 1) 
        do.cv <- TRUE
    if (!do.cv) {
        store.cv <- FALSE
        nfold <- 1
    }
    groups <- split(sample(1:n), rep(1:nfold, length = n))
    n.unpen.cols <- 1 + mean.signal.term + ifelse(is.null(covt), 
            0, ncol(as.matrix(covt)))
    cv.table <- array(0, dim = c(ifelse(is.null(fdobj), nrow(nbs), 
                            1), length(ncomp)))
    for (inb in 1:dim(cv.table)[1]) {
        st <- fpcr.setup(y = y, xfuncs = xfuncs, fdobj = fdobj, 
                nbasis = if (is.null(fdobj)) 
                            nbs[inb, ]
                        else NULL, basismat = basismat, penmat = penmat, 
                argvals = argvals, covt = covt, mean.signal.term = mean.signal.term, 
                spline.order = spline.order, pen.order = pen.order)
        argvals <- st$argvals
#        if (is.null(fdobj)) 
#            cat("nbasis:", st$nbasis, "\n")
        for (ifold in 1:nfold) {
            if (do.cv) {
                idxTest <- groups[[ifold]]
                idxTrain <- (1:n)[-idxTest]
            }
            else idxTest <- idxTrain <- 1:n
            X0.tr <- st$X0[idxTrain, ]
            SB.tr <- st$SB[idxTrain, ]
            svdSB <- svd(SB.tr)
            if (is.null(ncomp)) 
                ncomp <- min(which(cumsum(svdSB$d) > pve * sum(svdSB$d)))
            for (incomp in 1:length(ncomp)) {
                V.ncomp <- svdSB$v[, 1:ncomp[incomp]]
                X <- cbind(X0.tr, SB.tr %*% V.ncomp)
                S <- list(matrix(0, ncol(X), ncol(X)))
                S[[1]][-(1:n.unpen.cols), -(1:n.unpen.cols)] <- crossprod(V.ncomp, 
                        st$penmat %*% V.ncomp)
                obje <- gam(y[idxTrain] ~ X - 1, paraPen = list(X = S), 
                        family = get(family), method = method, sp = sp, 
                        ...)
                BV <- st$basismat %*% V.ncomp
                fhat <- BV %*% obje$coef[-(1:n.unpen.cols)]
                undecor.coef <- obje$coef[1:n.unpen.cols] - ginv(X0.tr) %*% 
                        st$xfuncs[idxTrain, ] %*% fhat
                yhat <- st$X0[idxTest, ] %*% undecor.coef + st$xfuncs[idxTest, 
                ] %*% fhat
                if (family == "gaussian") 
                    cv.table[inb, incomp] <- cv.table[inb, incomp] + 
                            mean((yhat - y[idxTest])^2)
                else if (family == "binomial") {
                    phat <- exp(yhat)/(1 + exp(yhat))
                    phat <- replace(phat, exp(yhat) == Inf, 1)
                    cv.table[inb, incomp] <- cv.table[inb, incomp] + 
                            mean((phat > mean(y[idxTrain])) != y[idxTest])
                }
            }
        }
    }
    if (do.cv) {
        idxmin <- which(cv.table == min(cv.table[cv.table != 
                                        0], na.rm = TRUE), arr.ind = TRUE)
        if (nrow(idxmin) > 1) 
            idxmin <- idxmin[1, ]
        if (is.list(nbasis)) {
            dim(cv.table) <- c(length(nbasis[[1]]), length(nbasis[[2]]), 
                    length(ncomp))
            dimnames(cv.table) <- list(paste("nbasis1=", nbasis[[1]]), 
                    paste("nbasis2=", nbasis[[2]]), paste("ncomp", 
                            ncomp))
        }
        else dimnames(cv.table) <- list(paste("nbasis=", nbasis), 
                    paste("ncomp", ncomp))
        if (dim.sig == 1) 
            nbasis <- nbs[idxmin[1], ]
        else {
            nbasis <- list()
            nbasis[[1]] <- nbs[idxmin[1], 1]
            nbasis[[2]] <- nbs[idxmin[1], 2]
        }
        obje <- fpcr(y = y, xfuncs = xfuncs, fdobj = fdobj, ncomp = ncomp[idxmin[2]], 
                nbasis = nbasis, basismat = basismat, penmat = penmat, 
                argvals = argvals, covt = covt, mean.signal.term = mean.signal.term, 
                spline.order = spline.order, family = family, method = method, 
                sp = sp, pen.order = pen.order, cv1 = FALSE, store.gam = store.gam, 
                ...)
        ncomp <- ncomp[idxmin[2]]
        if (store.cv) 
            obje$cv.table <- cv.table
        else obje$cv.table <- min(cv.table[cv.table != 0])
    }
    else {
        se <- sqrt(rowSums((BV %*% obje$Vp[-(1:n.unpen.cols), 
                                            -(1:n.unpen.cols)]) * BV))
        if (!store.gam) {
            yhat <- obje$fitted.values
            obje <- list()
            obje$fitted.values <- yhat
        }
        obje$se <- se
        obje$argvals <- argvals
        obje$undecor.coef <- as.matrix(undecor.coef, nrow = 1)
        colnames(obje$undecor.coef) <- if (is.null(dimnames(covt)) || 
                        is.null(dimnames(covt)[[2]])) 
                    paste("X", 0:(n.unpen.cols - 1), sep = "")
                else c("Intercept", dimnames(covt)[[2]])
        if (st$dim.sig == 2) 
            dim(fhat) <- c(d1, d2)
        obje$fhat <- fhat
        obje$nbasis <- nbasis
        obje$ncomp <- ncomp
    }
    class(obje) = "fpcr"
    return(obje)
}

##################################################################
##################################################################
## local version of mvr_dcv to silent the print() statement
##################################################################
##################################################################

mvr_dcv = 
        function (formula, ncomp, data, subset, na.action, method = c("kernelpls", 
                        "widekernelpls", "simpls", "oscorespls", "svdpc"), scale = FALSE, 
                repl = 100, sdfact = 2, segments0 = 4, segment0.type = c("random", 
                        "consecutive", "interleaved"), length.seg0, segments = 10, 
                segment.type = c("random", "consecutive", "interleaved"), 
                length.seg, trace = FALSE, plot.opt = FALSE, selstrat = "hastie", 
                ...) 
{
    error.bars <- function(x, upper, lower, width = 0.02, ...) {
        xlim <- range(x)
        barw <- diff(xlim) * width
        segments(x, upper, x, lower, ...)
        segments(x - barw, upper, x + barw, upper, ...)
        segments(x - barw, lower, x + barw, lower, ...)
        range(upper, lower)
    }
    require(pls)
    mf <<- match.call(expand.dots = FALSE)
    m <- match(c("formula", "data", "subset", "na.action"), names(mf), 
            0)
    mf <- mf[c(1, m)]
    mf[[1]] <- as.name("model.frame")
    mf <- eval(mf, parent.frame())
    method <- match.arg(method, c("kernelpls", "widekernelpls", 
                    "simpls", "oscorespls", "svdpc", "model.frame"))
    if (method == "model.frame") 
        return(mf)
    mt <- attr(mf, "terms")
    Y <- model.response(mf, "numeric")
    if (is.matrix(Y)) {
        if (is.null(colnames(Y))) 
            colnames(Y) <- paste("Y", 1:dim(Y)[2], sep = "")
    }
    else {
        Y <- as.matrix(Y)
        colnames(Y) <- deparse(formula[[2]])
    }
    X <- pls:::delete.intercept(model.matrix(mt, mf))
    nobj <- dim(X)[1]
    npred <- dim(X)[2]
    if (length(attr(mt, "term.labels")) == 1 && !is.null(colnames(mf[[attr(mt, 
                                    "term.labels")]]))) 
        colnames(X) <- sub(attr(mt, "term.labels"), "", colnames(X))
    if (missing(ncomp)) {
        ncomp <- min(nobj - 1, npred)
        ncompWarn <- FALSE
    }
    else {
        if (ncomp < 1 || ncomp > min(nobj - 1, npred)) 
            stop("Invalid number of components, ncomp")
        ncompWarn <- TRUE
    }
    Y <- as.matrix(Y)
    dy <- dim(Y)
    dx <- dim(X)
    dnX <- dimnames(X)
    dnY <- dimnames(Y)
    dimnames(X) <- dimnames(Y) <- NULL
    if (!is.logical(scale) || length(scale) != 1) 
        stop("'scale' must be 'TRUE' or 'FALSE'")
    ncomp <- min(ncomp, dx[1] - max(sapply(segments0, length)) - 
                    1)
    pred <- array(dim = c(dx[1], dy[2], ncomp, repl))
    predopt <- array(dim = c(dx[1], dy[2], repl))
    optcomp <- matrix(NA, nrow = segments0, ncol = repl)
    for (i in 1:repl) {
#        print(i)
        if (missing(length.seg0)) {
            segment0 <- cvsegments(dx[1], k = segments0, type = segment0.type)
        }
        else {
            segment0 <- cvsegments(dx[1], length.seg = length.seg0, 
                    type = segment0.type)
        }
        if (trace) 
            cat(paste("Replication: ", i))
        for (n.seg0 in 1:length(segment0)) {
            if (trace) 
                cat(n.seg0, "")
            seg0 <- segment0[[n.seg0]]
            obsuse <- as.numeric(unlist(segment0[-n.seg0]))
            res <- mvr(Y ~ X, ncomp = ncomp, subset = obsuse, 
                    na.action = na.action, method = method, scale = scale, 
                    segments = segments, segment.type = segment.type, 
                    trace = trace, validation = "CV")
            MSEPj <- matrix(NA, nrow = segments, ncol = ncomp)
            for (j in 1:segments) {
                predj <- res$vali$pred[res$vali$seg[[j]], , ]
                obsj <- obsuse[res$vali$seg[[j]]]
                resj <- predj - Y[obsj]
                MSEPj[j, ] <- apply(resj^2, 2, mean)
            }
            MSEPm <- apply(MSEPj, 2, mean)
            MSEPsd <- apply(MSEPj, 2, sd)/sqrt(segments)
            if (selstrat == "diffnext") {
                fvec <- (diff(MSEPm) + sdfact * MSEPsd[-1]) < 
                        0
                fvec <- c(TRUE, fvec)
                ind <- which.min(MSEPm)
                optcomp[n.seg0, i] <- max((1:ind)[fvec[1:ind]])
            }
            else if (selstrat == "hastie") {
                ind <- which.min(MSEPm)
                fvec <- (MSEPm < (MSEPm[ind] + sdfact * MSEPsd[ind]))
                optcomp[n.seg0, i] <- min((1:ind)[fvec[1:ind]])
            }
            else if (selstrat == "relchange") {
                ind <- which.min(MSEPm)
                MSEPsel <- MSEPm[1:ind]
                relchange <- (MSEPsel - MSEPm[ind])/max(MSEPsel) > 
                        0.001
                ind2 <- which.max((1:length(relchange))[relchange])
                MSEPm2 <- MSEPsel[1:ind2]
                MSEPsd2 <- MSEPsd[1:ind2]
                indm <- which.min(MSEPm2)
                fvec <- (MSEPm2 < (MSEPm2[indm] + sdfact * MSEPsd2[indm]))
                optcomp[n.seg0, i] <- min((1:indm)[fvec[1:indm]])
            }
            if (plot.opt) {
                plot(1:ncomp, MSEPm, xlab = "Component number", 
                        ylab = "Average MSEP", ylim = range(MSEPm, 
                                MSEPm + MSEPsd, MSEPm - MSEPsd), type = "b")
                error.bars(1:ncomp, MSEPm + MSEPsd, MSEPm - MSEPsd, 
                        width = 1/ncomp, col = 3)
                abline(v = optcomp[n.seg0, i], col = 2)
            }
            predopt[seg0, , i] <- predict(res, data, ncomp = optcomp[n.seg0, 
                            i])[seg0, , ]
            pred[seg0, , , i] <- predict(res, data)[seg0, , ]
        }
    }
    resopt <- predopt - c(Y)
    MSEPopt <- mean(as.vector(resopt)^2)
    biasopt <- mean(resopt)
    SEPopt <- sqrt(sum((resopt - biasopt)^2)/(prod(dim(resopt)) - 
                        1))
    sIQRopt <- IQR(resopt)/1.349
    sMADopt <- mad(resopt)
    objnames <- dnX[[1]]
    if (is.null(objnames)) 
        objnames <- dnY[[1]]
    yvarnames <- dnY[[2]]
    nCompnames <- paste(1:ncomp, "comps")
    nreplnames <- paste(1:repl, "repl")
    nsegnames <- paste(1:segments0, "segm")
    dimnames(pred) <- list(objnames, yvarnames, nCompnames, nreplnames)
    dimnames(predopt) <- list(objnames, yvarnames, nreplnames)
    dimnames(resopt) <- list(objnames, yvarnames, nreplnames)
    dimnames(optcomp) <- list(nsegnames, nreplnames)
    afinaldistr <- table(optcomp)/sum(table(optcomp))
    afinal <- as.numeric(names(which.max(afinaldistr)))
    residcomp <- pred - c(Y)
    biascomp <- apply(residcomp, 3, mean)
    dimr <- dim(residcomp)
    biascomp1 <- array(biascomp, c(dimr[3], dimr[1], dimr[2], 
                    dimr[4]))
    biascomp1 <- aperm(biascomp1, c(2, 3, 1, 4))
    SEPfinal <- sqrt(apply((residcomp - biascomp1)^2, 3, sum)/(prod(dim(resopt)) - 
                        1))
    list(resopt = resopt, predopt = predopt, optcomp = optcomp, 
            pred = pred, SEPopt = SEPopt, sIQRopt = sIQRopt, sMADopt = sMADopt, 
            MSEPopt = MSEPopt, afinal = afinal, SEPfinal = SEPfinal)
}





##################################################################
##################################################################
## code copied from my.sisr
##################################################################
##################################################################

sisr <- function(y, t=1:ncol(X), X, d=40, pendegree=2, 
        tol=1e-3, maxiter=50,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    d <- pmin(d, length(y)-1)
    D <- switch(pendegree, 
            "null"=diag(d), "1"=diff(diag(d)), "2"=diff(diff(diag(d))))
    P <- crossprod(D)
    
    T <- bs(t, intercept = TRUE, df=d)
    M <- X%*%T
    
    y <- drop(y)
    
    
    if(plot) layout(t(1:5))
    
    ystar <- y
    Mstar <- M
    m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
    gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(M%*%gammahat.new) 
    mse <- rep(NA,maxiter)
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        
        mf <- gam(y ~ s(Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, T%*%gammahat.new, type="l", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Mstar <- diag(fderiv)%*%M
        
        m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
        gammahat.0 <- gammahat.new
        gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
        Mgamma <- drop(M%*%gammahat.new)
        
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, T=T, call=match.call())
    return(ret)
}    

predict.wavesisr <- predict.sisr <- function(obj, Xnew){
    Mgammanew <- Xnew%*%(obj$T%*%obj$gammahat)
    predict(obj$mf, newdata=list(Mgamma=Mgammanew))
}


########## R function: ZDaub ##########
# Creates a Daubechies wavelet basis function
# design matrix for a given input vector "x".
# Last changed: 09 SEP 2011
## dl'ed 15.08.2012, 15:32:36 @ http://projecteuclid.org/DPubS/Repository/1.0/Disseminate?view=body&id=supzip_1&handle=euclid.ejs/1323785605
## (supplementary material to Wand/Ormerod(2011)"Penalized wavelets: Embedding wavelets into semiparametric regression")
ZDaub <- function(x,range.x=range(x),numLevels=6,filterNumber=5,
        resolution=16384)
{
    # Load required package:
    
    library(wavethresh)
    
    # Check that x within support limits:
    
    if (any(x<range.x[1])|any(x>range.x[2]))
        stop("All abscissae should be within range.x values.")
    
    # Ensure that the number of levels is `allowable'.
    
    if (!any(numLevels==(1:10)))
        stop("Number of levels should be between 2 and 10.")
    
    # Ensure the resolution value is `allowable'.
    
    if (!any(resolution==(2^(10:20))))
        stop("Resolution value should be a power of 2, with the
                        power between 10 and 20.")
    
    # Transform x to the unit interval and obtain variables
    # required for linear interpolation:
    
    xUnit <- (x - range.x[1])/(range.x[2] - range.x[1])
    xUres <- xUnit*resolution
    fXuRes <- floor(xUres)
    
    # Set filter and wavelet family  
    
    family <- "DaubExPhase"
    K <- 2^numLevels - 1
    
    # Create a dummy wavelet transform object
    
    wdObj <- wd(rep(0,resolution),filter.number=filterNumber,
            family="DaubExPhase")
    
    Z <- matrix(0,length(x),K)
    for (k in 1:K)
    {
        # Create wobj so that it contains the Kth basis
        # function of the Z matrix with `resolution' regularly 
        # spaced points:
        
        putCobj <- putC(wdObj,level=0,v=0)
        putCobj$D <- putCobj$D*0
        putCobj$D[resolution-k] <- 1
        
        # Obtain kth column of Z via linear interpolation
        # of the wr(putCobj) grid values:
        
        wtVec <- xUres - fXuRes
        wvVec <- wr(putCobj)
        wvVec <- c(wvVec,rep(wvVec[length(wvVec)],2))
        Z[,k] <- sqrt(resolution)*((1 - wtVec)*wvVec[fXuRes+1]
                    + wtVec*wvVec[fXuRes+2])
    }
    
    # Create column indices to impose "left-to-right" ordering
    # within the same level:
    
    newColInds <- 1
    for (ell in 1:(numLevels-1))
        newColInds <- c(newColInds,(2^(ell+1)-1):(2^(ell)))
    
    Z <- Z[,newColInds]
    
    return(Z)
}
############ End of ZDaub ###########

wavesisr <- function(y, t=1:ncol(X), X,
        numLevels=8,filterNumber=6, resolution=16384, 
        tol=1e-3, maxiter=500, alpha=.5,
        plot=TRUE, verbose=TRUE){
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    
    stopifnot(require(wavethresh))
    stopifnot(require(glmnet))
    stopifnot(require(mgcv))
    
    T <- ZDaub(x=t, range.x=range(t), numLevels=numLevels, 
            filterNumber=filterNumber, resolution=resolution)
    M <- X%*%T
    
    y <- drop(y)
    
    ystar <- y
    Mstar <- M
    m <- cv.glmnet(x=Mstar, y=ystar, alpha=alpha)
    optiter <- which(m$lambda==m$lambda.1se)
    gammaraw <- m$glmnet$beta[,optiter]
    gammahat.new <- gammaraw#/sqrt(sum(gammaraw^2))
    gammahat.0 <- 2*gammahat.new+.1
    Mgamma <- drop(M%*%gammahat.new) 
    fit <- Mgamma
    fit.new <- 2*Mgamma
    
    if(plot) layout(t(1:5))
    iter <- 0
    mse <- rep(NA,maxiter)
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(1e-6, abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        #while((mean(abs(fit - fit.new)/pmax(1e-6, abs(fit),abs(fit.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        fit <- fit.new
        mf <- gam(y ~ s(Mgamma))
        
        fhat <- fit.new <- drop(fitted(mf))
        mse[iter] <- mean((fit.new-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    # "diff(fit)/|fit|:", mean(abs(fit - fit.new)/pmax(1e-6, abs(fit),abs(fit.new))),
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(1e-6, abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop(predict(mf, newdata=data.frame(Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, T%*%gammahat.new, type="l")
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Mstar <- diag(fderiv)%*%M
        
        m <- cv.glmnet(x=Mstar, y=as.numeric(ystar), alpha=alpha)
        optiter <- which(m$lambda==m$lambda.1se)
        gammaraw <- m$glmnet$beta[,optiter]
        gammahat.0 <- gammahat.new
        gammahat.new <- gammaraw#/sqrt(sum(gammaraw^2))
        Mgamma <- drop(M%*%gammahat.new)
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, T=T, call=match.call())
    return(ret)
}    

pclmsisr <- function(y, X, B=20, 
        maxiter=1e3, tol=1e-3,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    
    boot <- function(){
        error <- rep(NA, nc)
        train <- sort(sample(1:nrow(X), nrow(X), replace=TRUE))
        test <- setdiff(1:nrow(X),train)
        for(n in 1:nc){
            yb <- y[train]
            Xb <- X[train, 1:n]
            m <- lm(yb ~ Xb)
            pred <- predict(m, newdata=list(Xb=X[test, 1:n]))
            error[n] <- mean((pred-y[test])^2)
            if(verbose) cat(".")
        }
        if(verbose) cat("\n")
        return(error)
    } 
    nc <- ceiling(min(ncol(X), nrow(X))*.666)
    err <- try(replicate(B, boot()))
    use.nc <- which.min(rowMeans(err))
    M <- cbind(1, X[,1:use.nc])
    
    ystar <- y
    Mstar <- M
    m <- lm(ystar ~ Mstar-1)
    
    gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(M%*%gammahat.new) 
    mse <- rep(NA,maxiter)
    if(plot) layout(t(1:5))
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        mf <- gam(y ~ s(Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, median(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(0:use.nc, gammahat.new, type="s", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Mstar <- diag(fderiv)%*%M
        
        m <- lm(ystar ~ Mstar -1)
        gammahat.0 <- gammahat.new
        gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
        Mgamma <- drop(M%*%gammahat.new)
        
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, nc=use.nc, call=match.call())
    return(ret)
}    
predict.pclmsisr <- function(obj, Xnew){
    Mgammanew <- cbind(1, Xnew[,1:obj$nc])%*%obj$gammahat
    predict(obj$mf, newdata=list(Mgamma=Mgammanew))
}

adsisr <- function(y, t=1:ncol(X), X, d=40,  
        tol=1e-3, maxiter=150,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    
    n <- nrow(X)
    indmat <- matrix(t, nrow=n, ncol=ncol(X), byrow=TRUE) 
    
    
    y <- drop(y)
    
    if(plot) layout(t(1:5))
    
    ystar <- y
    Xstar <- X
    
    m <- gam(ystar ~ 0 +  s(indmat, by=Xstar, k=d, bs="ad"))
    gammahat <- predict(m, newdata=data.frame(indmat=t, Xstar=1))
    
    gammahat.new <- gammahat/sqrt(sum(gammahat^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(X %*% gammahat.new)
    mse <- rep(NA,maxiter)
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        
        mf <- gam(y ~ s(Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, gammahat.new, type="l", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Xstar <- diag(fderiv)%*%X
        
        m <- gam(ystar ~ 0 +  s(indmat, by=Xstar, k=d, bs="ad"))
        gammahat.0 <- gammahat.new
        gammahat <- predict(m, newdata=data.frame(indmat=t, Xstar=1))
        gammahat.new <- gammahat/sqrt(sum(gammahat^2))
        Mgamma <- drop(X %*% gammahat.new)
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, call=match.call())
    return(ret)
}   
predict.adsisr <- function(obj, Xnew){
    Mgammanew <- Xnew%*%obj$gammahat
    predict(obj$mf, newdata=list(Mgamma=Mgammanew))
}



sisrVcf <- function(y, z, t=1:ncol(X), X, d=40, pendegree=2, 
        tol=1e-3, maxiter=150,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    D <- switch(pendegree, 
            "null"=diag(d), "1"=diff(diag(d)), "2"=diff(diff(diag(d))))
    P <- crossprod(D)
    
    T <- bs(t, intercept = TRUE, df=d)
    M <- X%*%T
    
    y <- drop(y)
    
    
    if(plot) layout(t(1:5))
    
    ystar <- y
    Mstar <- M
    m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
    gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(M%*%gammahat.new) 
    mse <- rep(NA,maxiter)
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        
        mf <- gam(y ~ te(z, Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(z=z, Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(z=z, Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, T%*%gammahat.new, type="l", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Mstar <- diag(fderiv)%*%M
        
        m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
        gammahat.0 <- gammahat.new
        gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
        Mgamma <- drop(M%*%gammahat.new)
        
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, T=T, call=match.call())
    return(ret)
}

predict.sisrVcf <- function(obj, Xnew, znew){
    Mgammanew <- Xnew%*%(obj$T%*%obj$gammahat)
    predict(obj$mf, newdata=list(Mgamma=Mgammanew, z=znew))
}

adsisrVcf <- function(y, t=1:ncol(X), X, z, d=40,  
        tol=1e-3, maxiter=150,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    
    n <- nrow(X)
    indmat <- matrix(t, nrow=n, ncol=ncol(X), byrow=TRUE) 
    
    
    y <- drop(y)
    
    if(plot) layout(t(1:5))
    
    ystar <- y
    Xstar <- X
    
    m <- gam(ystar ~ 0 +  s(indmat, by=Xstar, k=d, bs="ad"))
    gammahat <- predict(m, newdata=data.frame(indmat=t, Xstar=1))
    
    gammahat.new <- gammahat/sqrt(sum(gammahat^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(X %*% gammahat.new)
    mse <- rep(NA,maxiter)
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        
        mf <- gam(y ~ te(z, Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(z=z, Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(z=z, Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, gammahat.new, type="l", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Xstar <- diag(fderiv)%*%X
        
        m <- gam(ystar ~ 0 +  s(indmat, by=Xstar, k=d, bs="ad"))
        gammahat.0 <- gammahat.new
        gammahat <- predict(m, newdata=data.frame(indmat=t, Xstar=1))
        gammahat.new <- gammahat/sqrt(sum(gammahat^2))
        Mgamma <- drop(X %*% gammahat.new)
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, call=match.call())
    return(ret)
}   
predict.adsisrVcf <- function(obj, Xnew, znew){
    Mgammanew <- Xnew%*%obj$gammahat
    predict(obj$mf, newdata=list(Mgamma=Mgammanew, z=znew))
}


##################################################################
##################################################################
## code copied from marx.sisr
##################################################################
##################################################################

#Single Index Model function 
sim.psr <- function(x, y, ps., lam., ord., max.iter){
    
    #1: Initialization: estimate alpha (from signal.fit) and f (from pnormal) 
    x.index <- 1:ncol(x)
    psr.fit <- signal.fit(y, x.index, x, ps.int=ps.[1], lambda=10^6, 
            ridge.adj=0, coef.plot=F, order=1, se=F, int=T)
    b       <- psr.fit$b
    u       <- x%*%b
    D       <- diag(ncol(b))
    for (j in 1:ord.[1]) { D <- diff(D) }
    alpha   <- as.vector(psr.fit$coef[-1])
    int     <- as.vector(psr.fit$coef[1])
    eta     <- as.vector(u%*%alpha) + int
    
    f.fit   <- pnormal.der(x=eta, y=y, nseg=ps.[2], bdeg=3, pord=ord.[2], 
            lambda=lam.[2], plot = F, se = F)
    der     <- predict.pnormal(f.fit, eta, 1)
    f.eta   <- predict.pnormal(f.fit, eta, 0)
    
    iter    <- 1                 #Initialize number of iterations
    cv      <- f.fit$cv          #Track the cv errors
    d.alpha <- NULL              #Track convergence of alpha
    
    #2: Start iteration
    for (it in 2:max.iter){
        
        ## Update alpha and intercept through lsfit
        y.star    <- y-f.eta+der*eta
        u.tilda   <- diag(der)%*%cbind(1,u)
        p         <- cbind(0,sqrt(lam.[1])*D)
        nix       <- rep(0,nrow(D))
        u.p       <- rbind(u.tilda,p)
        y.p       <- c(y.star, nix)
        
        fit1      <- lsfit(u.p, y.p, intercept=F)
        int.new   <- as.vector(fit1$coef[1])
        alpha.new <- as.vector(fit1$coef[2:ncol(u.p)])  
        
        ## Check the convergence of alpha
        tmp1      <- alpha/sqrt(mean(alpha^2))
        tmp2      <- alpha.new/sqrt(mean(alpha.new^2))
        d.alpha   <- c(d.alpha,mean((tmp2-tmp1)^2)/mean(tmp2^2))
        
        if ( d.alpha[(it-1)] < 10^(-3) ) 
            break 
        
        ## Estimate f through pnormal
        alpha  <- alpha.new
        int    <- int.new
        eta    <- as.vector(u%*%alpha) + int
        f.fit   <- pnormal.der(x=eta, y=y, nseg=ps.[2], bdeg=3, pord=ord.[2], 
                lambda=lam.[2], plot = F, se = F)
        der     <- predict.pnormal(f.fit, eta, 1)
        f.eta   <- predict.pnormal(f.fit, eta, 0)
    }
    
    out<-list(cv=cv, iter=(it-1), alpha=alpha, int=int, b=b, f=f.fit, ps.=ps., 
            lam.=lam., ord.=ord., delta.alpha=d.alpha)
}

predict.sim.psr <- function(obj, x){
    eta <- as.vector(x%*%obj$b%*%obj$alpha) + obj$int
    out <- predict.pnormal(obj$f, eta, 0) 
    out
}

fit.one.iter<-function(x,y,ps.,ord.,lam.,rdg.adj){
    x.index<-1:ncol(x)
    psr<-signal.fit(y, x.index, x, ps.int=ps.[1], lambda=lam.[1], ridge.adj=rdg.adj,
            coef.plot=F, order=ord.[1], se=F, x.predicted=x, y.predicted=y)
    eta<-as.vector(psr$eta.predicted)
    f<-pnormal.der(x=eta,y=y,nseg=ps.[2],bdeg=3,pord=ord.[2],lambda=lam.[2],
            plot=F, se=F)
    out<-list(psr=psr,f=f)
    out
}

pred.one.iter<-function(xnew,psr,f){
    eta<-as.vector(xnew%*%psr$b%*%psr$coef[-1]+psr$coef[1])
    out<-as.vector(predict.pnormal(f,eta,0))
    out
}

psr.wrapped <- function(x, y, 
        ps.=c(80,20),      # no. of basis functions 
        ord.=c(3,2),       # order of diff. penalties
        max.iter= 200,     # max no. of iterations 
        lower = c(-8,-4), 
        upper = c(-4,4),   #lower /upper bounds for log(lambda) 
        start = upper,     
        ngrid = 20,        #size of grid for lambda-search
        validratio=.25){   #ratio of cases in validation set
    
    stopifnot(require(svcm))
    #split validation/training data
    valid <- sort(sample(1:nrow(x), nrow(x)*validratio))
    x.train <- x[-valid, ]
    y.train <- y[-valid]
    x.valid <- x[valid, ]
    y.valid <- y[valid]
    
    cleverwrapper<-function(vec){
        fit  <- sim.psr(x.train, y.train, ps., vec, ord., max.iter)
        tmp1 <- predict.sim.psr(fit, x.valid)
        out  <- sqrt(mean(((tmp1-y.valid)^2)))
        out
    }
    
    opt.sim<-cleversearch(cleverwrapper, lower, upper, ngrid, start, 
            logscale=TRUE, clever=TRUE, verbose=FALSE)
    
    fit<-sim.psr(rbind(x.train,x.valid), c(y.train,y.valid), ps., 
            lam.=opt.sim$par, ord., max.iter) 
    
    #return validation data indices for reproducibility
    fit$valid <- valid
    
    return(fit)
}

##################################################################
##################################################################
## code necessary for marx.sisr (copied from functions.dump)
##################################################################
##################################################################

`poly.signal.fit` <-
        function(response, x.index, x.signal, poly.order=1,importance = NULL, m.binomial = NULL, 
                ps.intervals = 8, degree = 3, order = 3, wts = NULL, link = "default", 
                family = "gaussian", r.gamma = NULL, lambda.vector = 0, y.predicted = NULL, 
                x.predicted = NULL, ridge.adj = 0, int = T, coef.plot = T
)
{
# Function signal.fit: smooths signal (multivariate calibration) beta's using P-splines.
# Input: x.index= abcissae of spectra (1:p).
# Input: x.signal= (n X p) explanatory variable signal matrix (p >> n possible).
# Input: response= response variable.
# Input: importance: a vector of importance of B-splines for variable lambda: (ps.int+q) x 1
# Input: poly.order: order of polynomial for additive polynomial signal regression (1=PSR)
# Input: family=gaussian, binomial, poisson, Gamma distribution.
# Input: m.binomial=vector of binomial trials. Default is 1 vector.
# Input: r.gamma=vector of gamma shape parameters. Default is 1 vector.
# Input: link= link function (identity, log, sqrt, logit, probit, cloglog, loglog, recipical).
# Input: ps.intervals= number of intervals for B-splines. Default=8.
# Input: degree= degree of B-splines. Default=3.
# Input: order= order of difference penalty. Default=3.
# Input: lambda.vector= must have length = poly.order; smoothness regulalizing parameter ( >= 0). Default=0.
# Input: x.predicted=a matrix of row (original) signals for prediction and twice stderr limits.
# Input: y.predicted= a vector of responses from a cv data set (assoc. with cv x.predicted).
# Input: ridge.adj= a small positive constant to help stabilize linear dependencies among B-splines.
# Result: a plot of smoothed beta's and twice stderr.
# Output: A list: including, AIC= deviance + 2*trace(Hat), dispers.parm, etc.
#
# Support Functions: pspline.fitter() and pspline.checker()
#
# References:
# Marx, B.D. and Eilers, P.H.C. (1999). Generalized linear regression for sampled signals and
#        curves: A P-spline approach. Technometrics, 41(1): 1-13.
# Eilers, P.H.C. and Marx, B.D. (1996). Flexible smoothing with B-splines and penalties (with comments
#        and rejoinder). Statistical Science, 11(2): 89-121.
#
# (c) 1995 Paul Eilers & Brian Marx
#
    y <- response
    x <- x.index
    vv <- importance
    n <- length(y)
    if(missing(wts)) {
        wts <- rep(1, n)
    }
    parms <- pspline.checker(family, link, degree, order, ps.intervals, 
            lambda=1, ridge.adj, wts)
    if(length(lambda.vector)!=poly.order){
        lambda.vector<-rep(lambda.vector[1],poly.order)
        warning(paste("Only used first lambda.vector entry: lambda.vec should have length = poly.ord"))}
    family <- parms$family
    link <- parms$link
    q <- parms$degree
    d <- parms$order
    ridge.adj <- parms$ridge.adj
#lambda <- parms$lambda
    ndx <- parms$ps.intervals
    wts <- parms$wts
    if(missing(m.binomial)) {
        m.binomial <- rep(1, n)
    }
    if(missing(r.gamma)) {
        r.gamma <- rep(1, n)
    }
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.01 * (xr - xl)
    xmin <- xl - 0.01 * (xr - xl)
    dx <- (xmax - xmin)/ndx
    knots <- seq(xmin - q * dx, xmax + q * dx, by = dx)
    b <- spline.des(knots, x, q + 1, 0 * x)$design
    n.col <- ncol(b)
    if(missing(importance)) {
        vv <- rep(1, n.col)
    }
    if(d < 0) {
        d <- min(3, (n.col - 1))
        warning(paste("penalty order cannot be negative: have used", d)
        )
    }
    if((d - n.col + 1) > 0) {
        d <- n.col - 1
        warning(paste("penalty order was too large: have used", d))
    }
    p.ridge <- NULL
    if(ridge.adj > 0) {
        nix.ridge <- rep(0, poly.order*n.col)
        p.ridge <- sqrt(ridge.adj) * diag(rep(1, poly.order*n.col))
    }
    p <- diag(n.col)
    if(d != 0) {
        for(j in 1:d) {
            p <- diff(p)
        }
    }
    pdiff<-p
    n.row<-nrow(p)
    
    p <- sqrt(lambda.vector[1]) * (1/sqrt(vv + 1e-008)) * p
    nix <- rep(0, poly.order*(n.col - d))
    x.signal <- as.matrix(x.signal)
    b<-as.matrix(b)
    xb <- x.signal %*% b
    
    PPen<-matrix(0,poly.order*n.row,poly.order*n.col)
    if(poly.order>1){
        for(iii in 1:poly.order)
        {PPen[((iii-1)*n.row+1):(iii*n.row),((iii-1)*n.col+1):(iii*n.col)]<-sqrt(lambda.vector[iii])*(1/sqrt(vv+1e-8))*pdiff
        }
        p<-PPen
    }
    if(poly.order>1){
        for(ii in c(2:poly.order)){
            xbnew<-cbind(xb,(x.signal^ii)%*%b)
            xb<-xbnew
        }
    }
    
    if(int) {
        xb <- cbind(rep(1, n), xb)
        p <- cbind(rep(0, nrow(p)), p)
        if(ridge.adj > 0) {
            p.ridge <- cbind(rep(0, nrow(p.ridge)), p.ridge)
        }
    }
    ps.fit <- pspline.fitter(family, link, n.col, m.binomial, r.gamma, y, b
                    = xb, p, p.ridge, nix, nix.ridge, ridge.adj, wts)
    mu <- ps.fit$mu
    coef <- ps.fit$coef
    bin.percent.correct <- NULL
    if(family == "binomial") {
        pcount <- 0
        p.hat <- mu/m.binomial
        for(ii in 1:n) {
            if(p.hat[ii] > 0.5) {
                count <- y[ii]
            }
            if(p.hat[ii] <= 0.5) {
                count <- m.binomial[ii] - y[ii]
            }
            count <- pcount + count
            pcount <- count
        }
        bin.percent.correct <- count/sum(m.binomial)
    }
    w <- ps.fit$w
    e <- 1e-009
    h <- hat(ps.fit$f$qr, intercept = F)[1:n]
    trace <- sum(h)
    if(family == "binomial") {
        dev <- 2 * sum((y + e) * log((y + e)/mu) + (m.binomial - y + e) *
                        log((m.binomial - y + e)/(m.binomial - mu)))
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "poisson") {
        dev <- 2 * sum(y * log(y + e) - y - y * log(mu) + mu)
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "Gamma") {
        dev <- -2 * sum(r.gamma * (log((y + e)/mu) - ((y - mu)/mu)))
        ave.dev <- dev/n
        dispersion.parm <- (ave.dev * (6 + ave.dev))/(6 + 2 * ave.dev)
        cv <- NULL
    }
    cv <- press.mu <- press.e <- NULL
    if(family == "gaussian") {
        dev <- sum(ps.fit$f$residuals[1:n]^2)
        dispersion.parm <- dev/(n - trace)
        press.e <- ps.fit$f$residuals[1:n]/(1 - h)
        cv <- sqrt(sum((press.e)^2)/(n))
        press.mu <- y - press.e
    }
    aic <- dev + 2 * trace
    w.aug <- c(w, (nix + 1))
    yint<-NULL
    if(int){
        yint <- ps.fit$coef[1]
    }
    
    
#summary.beta <- beta
    if(coef.plot) {
        par(mfrow=c(2,2))
        
        for(ii in c(1:poly.order)){
            beta.in<-b%*%(as.vector(ps.fit$f$coef)[(int+(ii-1)*n.col+1):(int+(ii*n.col))])
            plot(x.index, beta.in, col = 1, type = "l", 
                    lty = 1, xlab = "Coefficient Index", ylab = 
                            "P-spline Coefficient")
        }
    }
    summary.predicted <- NULL
    cv.predicted <- eta.predicted <- avediff.pred <- NULL
    
    if(!missing(x.predicted)) {
        x.predicted <- as.matrix(x.predicted)
        xpb<-x.predicted%*%b
        if(poly.order>1){
            for(ii in c(2:poly.order)){
                xpbnew<-cbind(xpb,(x.predicted^ii)%*%b)
                xpb<-xpbnew
            }
        }
        if(!int) {
            if(ncol(x.predicted) > 1) {
                eta.predicted <- xpb %*% as.vector(ps.fit$f$coef)
                
            }
            if(ncol(x.predicted) == 1) {
                eta.predicted <- t(xpb) %*% as.vector(ps.fit$f$coef)
                
            }
        }
        if(int) {
            dim.xp <- nrow(x.predicted)
            if(ncol(x.predicted) > 1) {
                
                one.xpred.b <- cbind(rep(1, dim.xp), (
                                    xpb))
                
                eta.predicted <- one.xpred.b %*% as.vector(ps.fit$f$coef) #+ yint
                
            }
            if(ncol(x.predicted) == 1) {
                one.xpred.b <- cbind(1, t(xpb))
                eta.predicted <- t(one.xpred.b) %*% as.vector(ps.fit$f$coef) #+ yint
                
            }
        }
        
        summary.predicted <-  eta.predicted
        if(!missing(y.predicted)) {
            if(family == "gaussian") {
                cv.predicted <- sqrt(sum((y.predicted - 
                                            eta.predicted)^2)/(length(y.predicted)))
                avediff.pred <- (sum(y.predicted - 
                                            eta.predicted))/length(y.predicted)
            }
        }
        bin.percent.correct <- NULL
        if(link == "logit") {
            summary.predicted <- 1/(1 + exp( - summary.predicted))
            pcount <- 0
            p.hat <- exp(eta.predicted)/(1 + exp(eta.predicted))
            if(!missing(y.predicted)) {
                for(ii in 1:length(eta.predicted)) {
                    if(p.hat[ii] > 0.5) {
                        count <- y.predicted[ii]
                    }
                    if(p.hat[ii] <= 0.5) {
                        count <- 1 - y.predicted[ii]
                    }
                    count <- pcount + count
                    pcount <- count
                }
                bin.percent.correct <- count/length(y.predicted
                )
            }
        }
        if(link == "probit") {
            summary.predicted <- apply(summary.predicted, c(1, 2), 
                    pnorm)
        }
        if(link == "cloglog") {
            summary.predicted <- (1 - exp( - exp(summary.predicted)
                        ))
        }
        if(link == "loglog") {
            summary.predicted <- exp( - exp( - summary.predicted))
        }
        if(link == "sqrt") {
            summary.predicted <- summary.predicted^2
        }
        if(link == "log") {
            summary.predicted <- exp(summary.predicted)
        }
        if(link == "recipical") {
            summary.predd <- 1/(summary.predicted)
            summary.predd <- NULL
        }
        
    }
    llist <- list()
    llist$b <- b
    llist$coef <- coef
    llist$y.intercept <- yint
    llist$int <- int
    llist$press.mu <- press.mu
    llist$bin.percent.correct <- bin.percent.correct
    llist$family <- family
    llist$link <- link
    llist$ps.intervals <- ndx
    llist$order <- d
    llist$degree <- q
    llist$lambda <- lambda.vector
    llist$aic <- aic
    llist$deviance <- dev
    llist$eff.df <- trace - 1
    llist$df.resid <- n - trace + 1
    llist$bin.percent.correct <- bin.percent.correct
    llist$dispersion.param <- dispersion.parm
    llist$summary.predicted <- summary.predicted
    llist$eta.predicted <- eta.predicted
    llist$cv.deleteone <- cv
    llist$mu <- mu
    llist$avediff.pred <- avediff.pred
    llist$cv.predicted <- cv.predicted
    llist
}

`pspline.checker` <-
        function(family, link, degree, order, ps.intervals, lambda, ridge.adj, wts)
{
    if(link == "default" && family == "gaussian") {
        link <- "identity"
    }
    if(link == "default" && family == "poisson") {
        link <- "log"
    }
    if(link == "default" && family == "binomial") {
        link <- "logit"
    }
    if(link == "default" && family == "Gamma") {
        link <- "log"
    }
    if(family != "binomial" && family != "gaussian" && family != "poisson" && 
            family != "Gamma") {
        warning(paste("Improper FAMILY option. Choose: gaussian, poisson, binomial or Gamma"
                ))
    }
    if((family == "binomial") && (link != "logit" && link != "probit" && 
                link != "cloglog" && link != "loglog")) {
        warning(paste("Improper LINK option with family=binomial. Choose: logit, probit, loglog, cloglog"
                ))
    }
    if((family == "Gamma") && (link != "log" && link != "recipical" && link !=
                "identity")) {
        warning(paste("Improper LINK option with family=Gamma. Choose: recipical, log, identity"
                ))
    }
    if((family == "poisson") && (link != "log" && link != "sqrt" && link != 
                "identity")) {
        warning(paste("Improper LINK option with family=poisson. Choose: log, sqrt, identity"
                ))
    }
    if((family == "gaussian") && (link != "identity")) {
        warning(paste("Improper LINK option with family=gaussian. Choose: identity"
                ))
    }
    if(degree < 0) {
        degree <- 1
        warning(paste("degree must be non-neg integer: have used 1"))
    }
    if(order < 0) {
        order <- 0
        warning(paste("order must be non-neg integer: have used 0"))
    }
    if(ps.intervals < 2) {
        ps.intervals <- 2
        warning(paste("ps.intervals must be positive integer, > 1: have used 2"
                ))
    }
    if(lambda < 0) {
        lambda <- 0
        warning(paste("lambda cannot be negative: have used 0"))
    }
    if(ridge.adj < 0) {
        ridge.adj <- 0
        warning(paste("ridge.adj cannot be negative: have used 0"))
    }
    if(min(wts) < 0) {
        warning(paste("At least one weight entry is negative"))
    }
    llist <- list(family = family, link = link, degree = degree, order = 
                    order, ps.intervals = ps.intervals, lambda = lambda, ridge.adj
                    = ridge.adj, wts = wts)
    return(llist)
}

`pspline.fitter` <-
        function(family, link, n.col, m.binomial, r.gamma, y, b, p, p.ridge, nix, 
                nix.ridge, ridge.adj, wts, ...)
{
    coef.est <- rep(1, ncol(b))
    if(family == "binomial") {
        mu <- (y + 0.5 * m.binomial)/2
    }
    if(family == "Gamma" || family == "poisson") {
        mu <- log(y + 3)
    }
    if(family == "gaussian") {
        mu <- rep(mean(y), length(y))
    }
    it <- 0
    repeat {
        if(it == 0) {
            if(link == "identity") {
                eta <- mu
            }
            if(link == "log") {
                eta <- log(mu)
            }
            if(link == "sqrt") {
                eta <- sqrt(mu)
            }
            if(link == "logit") {
                eta <- log(mu/(m.binomial - mu))
            }
            if(link == "recipical") {
                eta <- 1/mu
            }
            if(link == "probit") {
                eta <- qnorm(mu/m.binomial)
            }
            if(link == "cloglog") {
                eta <- log( - log(1 - mu/m.binomial))
            }
            if(link == "loglog") {
                eta <-  - log( - log(mu/m.binomial))
            }
        }
        it<-it+1
        if(it > 25)
            break
        if(link == "identity") {
            mu <- eta
            h.prime <- 1
        }
        if(link == "log") {
            mu <- exp(eta)
            h.prime <- mu
        }
        if(link == "sqrt") {
            mu <- eta^2
            h.prime <- 2 * eta
        }
        if(link == "logit") {
            mu <- m.binomial/(1 + exp( - eta))
            h.prime <- mu * (1 - mu/m.binomial)
        }
        if(link == "recipical") {
            mu <- 1/eta
            h.prime <-  - (mu^2)
        }
        if(link == "probit") {
            mu <- m.binomial * pnorm(eta)
            h.prime <- m.binomial * dnorm(eta)
        }
        if(link == "cloglog") {
            mu <- m.binomial * (1 - exp( - exp(eta)))
            h.prime <- (m.binomial) * exp(eta) * exp( - exp(eta))
        }
        if(link == "loglog") {
            mu <- m.binomial * exp( - exp( - eta))
            h.prime <- m.binomial * exp( - eta) * exp( - exp( - eta
                    ))
        }
        if(family == "gaussian") {
            w <- rep(1, length(y))
        }
        if(family == "poisson") {
            w <- h.prime^2/mu
        }
        if(family == "binomial") {
            w <- h.prime^2/(mu * (1 - mu/m.binomial))
        }
        if(family == "Gamma") {
            w <- (r.gamma * h.prime^2)/mu^2
        }
        u <- (y - mu)/h.prime + eta
        if(ridge.adj > 0) {
            f <- lsfit(rbind(b, p, p.ridge), c(u, nix, nix.ridge), 
                    wt = c(wts, nix + 1, nix.ridge + 1) * c(w, (nix +
                                        1), (nix.ridge + 1)), intercept = F)
        }
        if(ridge.adj == 0) {
            f <- lsfit(rbind(b, p), c(u, nix), wt = c(wts, nix + 1) *
                            c(w, (nix + 1)), intercept = F)
        }
        coef.old <- coef.est
        coef.est <- as.vector(f$coef)
        d.coef <- max(abs((coef.est - coef.old)/coef.old))
        
#            print(c(it, d.coef))
        if(d.coef < 1e-008)
            break
        eta <- b %*% coef.est
    }
    if(it > 24) {
        warning(paste("parameter estimates did NOT converge in 25 iterations"
                ))
    }
    llist <- list(coef = coef.est, mu = mu, f = f, w = w * wts)
    return(llist)
}

`signal.fit` <-
        function(response, x.index, x.signal, importance = NULL, m.binomial = NULL, 
                ps.intervals = 8, degree = 3, order = 3, wts = NULL, link = "default", 
                family = "gaussian", r.gamma = NULL, lambda = 0, y.predicted = NULL, 
                x.predicted = NULL, ridge.adj = 0, int = T, coef.plot = T, se.bands = T
)
{
# Function signal.fit: smooths signal (multivariate calibration) beta's using P-splines.
# Input: x.index= abcissae of spectra (1:p).
# Input: x.signal= (n X p) explanatory variable signal matrix (p >> n possible).
# Input: response= response variable.
# Input: importance: a vector of importance of B-splines for variable lambda: (ps.int+q)
# Input: family=gaussian, binomial, poisson, Gamma distribution.
# Input: m.binomial=vector of binomial trials. Default is 1 vector.
# Input: r.gamma=vector of gamma shape parameters. Default is 1 vector.
# Input: link= link function (identity, log, sqrt, logit, probit, cloglog, loglog, recipical).
# Input: ps.intervals= number of intervals for B-splines. Default=8.
# Input: degree= degree of B-splines. Default=3.
# Input: order= order of difference penalty. Default=3.
# Input: lambda= smoothness regulalizing parameter ( >= 0). Default=0.
# Input: x.predicted=a matrix of row (original) signals for prediction and twice stderr limits.
# Input: y.predicted= a vector of responses from a cv data set (assoc. with cv x.predicted).
# Input: ridge.adj= a small positive constant to help stabilize linear dependencies among B-splines.
# Result: a plot of smoothed beta's and twice stderr.
# Output: A list: including, AIC= deviance + 2*trace(Hat), dispers.parm, etc.
#
# Support Functions: pspline.fitter() and pspline.checker()
#
# References:
# Marx, B.D. and Eilers, P.H.C. (1999). Generalized linear regression for sampled signals and
#        curves: A P-spline approach. Technometrics, 41(1): 1-13.
# Eilers, P.H.C. and Marx, B.D. (1996). Flexible smoothing with B-splines and penalties (with comments
#        and rejoinder). Statistical Science, 11(2): 89-121.
#
# (c) 1995 Paul Eilers & Brian Marx
#
    y <- response
    x <- x.index
    vv <- importance
    n <- length(y)
    if(missing(wts)) {
        wts <- rep(1, n)
    }
    parms <- pspline.checker(family, link, degree, order, ps.intervals, 
            lambda, ridge.adj, wts)
    family <- parms$family
    link <- parms$link
    q <- parms$degree
    d <- parms$order
    ridge.adj <- parms$ridge.adj
    lambda <- parms$lambda
    ndx <- parms$ps.intervals
    wts <- parms$wts
    if(missing(m.binomial)) {
        m.binomial <- rep(1, n)
    }
    if(missing(r.gamma)) {
        r.gamma <- rep(1, n)
    }
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.01 * (xr - xl)
    xmin <- xl - 0.01 * (xr - xl)
    dx <- (xmax - xmin)/ndx
    knots <- seq(xmin - q * dx, xmax + q * dx, by = dx)
    b <- spline.des(knots, x, q + 1, 0 * x)$design
    n.col <- ncol(b)
    if(missing(importance)) {
        vv <- rep(1, n.col)
    }
    if(d < 0) {
        d <- min(3, (n.col - 1))
        warning(paste("penalty order cannot be negative: have used", d)
        )
    }
    if((d - n.col + 1) > 0) {
        d <- n.col - 1
        warning(paste("penalty order was too large: have used", d))
    }
    p.ridge <- NULL
    if(ridge.adj > 0) {
        nix.ridge <- rep(0, n.col)
        p.ridge <- sqrt(ridge.adj) * diag(rep(1, n.col))
    }
    p <- diag(n.col)
    if(d != 0) {
        for(j in 1:d) {
            p <- diff(p)
        }
    }
    p <- sqrt(lambda) * (1/sqrt(vv + 1e-008)) * p
    nix <- rep(0, n.col - d)
    x.signal <- as.matrix(x.signal)
    xb <- x.signal %*% as.matrix(b)
    if(int) {
        xb <- cbind(rep(1, n), xb)
        p <- cbind(rep(0, nrow(p)), p)
        if(ridge.adj > 0) {
            p.ridge <- cbind(rep(0, nrow(p.ridge)), p.ridge)
        }
    }
    ps.fit <- pspline.fitter(family, link, n.col, m.binomial, r.gamma, y, b
                    = xb, p, p.ridge, nix, nix.ridge, ridge.adj, wts)
    mu <- ps.fit$mu
    coef <- ps.fit$coef
    bin.percent.correct <- NULL
    if(family == "binomial") {
        pcount <- 0
        p.hat <- mu/m.binomial
        for(ii in 1:n) {
            if(p.hat[ii] > 0.5) {
                count <- y[ii]
            }
            if(p.hat[ii] <= 0.5) {
                count <- m.binomial[ii] - y[ii]
            }
            count <- pcount + count
            pcount <- count
        }
        bin.percent.correct <- count/sum(m.binomial)
    }
    w <- ps.fit$w
    e <- 1e-009
    h <- hat(ps.fit$f$qr, intercept = F)[1:n]
    trace <- sum(h)
    if(family == "binomial") {
        dev <- 2 * sum((y + e) * log((y + e)/mu) + (m.binomial - y + e) *
                        log((m.binomial - y + e)/(m.binomial - mu)))
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "poisson") {
        dev <- 2 * sum(y * log(y + e) - y - y * log(mu) + mu)
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "Gamma") {
        dev <- -2 * sum(r.gamma * (log((y + e)/mu) - ((y - mu)/mu)))
        ave.dev <- dev/n
        dispersion.parm <- (ave.dev * (6 + ave.dev))/(6 + 2 * ave.dev)
        cv <- NULL
    }
    cv <- press.mu <- press.e <- NULL
    if(family == "gaussian") {
        dev <- sum(ps.fit$f$residuals[1:n]^2)
        dispersion.parm <- dev/(n - trace)
        press.e <- ps.fit$f$residuals[1:n]/(1 - h)
        cv <- sqrt(sum((press.e)^2)/(n))
        press.mu <- y - press.e
    }
    aic <- dev + 2 * trace
    w.aug <- c(w, (nix + 1))
    if(int) {
        beta <- b %*% (as.vector(ps.fit$f$coef)[2:(n.col + 1)])
        yint <- ps.fit$coef[1]
    }
    if(!int) {
        yint <- NULL
        beta <- b %*% as.vector(ps.fit$f$coef)
    }
    half.meat <- sqrt(c(w)) * xb
    meat <- t(half.meat) %*% half.meat
    if(ridge.adj > 0) {
        bread <- solve(meat + t(p) %*% p + t(p.ridge) %*% p.ridge)
    }
    if(ridge.adj == 0) {
        bread <- solve(meat + t(p) %*% p)
    }
    half.sw <- half.meat %*% bread[, (1 + int):(n.col + int)]
    var.c <- t(half.sw) %*% half.sw
    half.lunch <- half.sw %*% t(b)
    ones <- 0 * y + 1
    var.beta <- ones %*% (half.lunch * half.lunch)
    stdev.beta <- sqrt(dispersion.parm) * t(sqrt(var.beta))
    pivot <- 2 * stdev.beta
    upper <- beta + pivot
    lower <- beta - pivot
    summary.beta <- cbind(lower, beta, upper)
    if(coef.plot) {
        if(se.bands) {
            matplot(x.index, summary.beta, type = "l", lty = c(3, 1,
                            3), col = rep(1, 3), xlab = "Coefficient Index",
                    ylab = "P-spline Coefficient")
        }
        if(!se.bands) {
            plot(x.index, summary.beta[, 2], col = 1, type = "l", 
                    lty = 1, xlab = "Coefficient Index", ylab = 
                            "P-spline Coefficient")
        }
    }
    summary.predicted <- NULL
    cv.predicted <- eta.predicted <- avediff.pred <- NULL
    if(!missing(x.predicted)) {
        x.predicted <- as.matrix(x.predicted)
        if(!int) {
            if(ncol(x.predicted) > 1) {
                eta.predicted <- x.predicted %*% beta
                var.pred <- x.predicted %*% b %*% var.c %*% t(
                        x.predicted %*% b)
            }
            if(ncol(x.predicted) == 1) {
                eta.predicted <- t(x.predicted) %*% beta
                var.pred <- t(x.predicted) %*% b %*% var.c %*% 
                        t(b) %*% x.predicted
            }
        }
        if(int) {
            var.c <- t(bread) %*% t(half.meat) %*% half.meat %*% 
                    bread
            dim.xp <- nrow(x.predicted)
            if(ncol(x.predicted) > 1) {
                one.xpred.b <- cbind(rep(1, dim.xp), (
                                    x.predicted %*% b))
                eta.predicted <- x.predicted %*% beta + yint
                var.pred <- one.xpred.b %*% var.c %*% t(
                        one.xpred.b)
            }
            if(ncol(x.predicted) == 1) {
                one.xpred.b <- cbind(1, t(x.predicted) %*% b)
                eta.predicted <- t(x.predicted) %*% beta + yint
                var.pred <- (one.xpred.b) %*% var.c %*% t(
                        one.xpred.b)
            }
        }
        stdev.pred <- as.vector(sqrt(diag(var.pred)))
        stdev.pred <- sqrt(dispersion.parm) * stdev.pred
        pivot <- as.vector(2 * stdev.pred)
        upper <- eta.predicted + pivot
        lower <- eta.predicted - pivot
        summary.predicted <- cbind(lower, eta.predicted, upper)
        if(!missing(y.predicted)) {
            if(family == "gaussian") {
                cv.predicted <- sqrt(sum((y.predicted - 
                                            eta.predicted)^2)/(length(y.predicted)))
                avediff.pred <- (sum(y.predicted - 
                                            eta.predicted))/length(y.predicted)
            }
        }
        bin.percent.correct <- NULL
        if(link == "logit") {
            summary.predicted <- 1/(1 + exp( - summary.predicted))
            pcount <- 0
            p.hat <- exp(eta.predicted)/(1 + exp(eta.predicted))
            if(!missing(y.predicted)) {
                for(ii in 1:length(eta.predicted)) {
                    if(p.hat[ii] > 0.5) {
                        count <- y.predicted[ii]
                    }
                    if(p.hat[ii] <= 0.5) {
                        count <- 1 - y.predicted[ii]
                    }
                    count <- pcount + count
                    pcount <- count
                }
                bin.percent.correct <- count/length(y.predicted
                )
            }
        }
        if(link == "probit") {
            summary.predicted <- apply(summary.predicted, c(1, 2), 
                    pnorm)
        }
        if(link == "cloglog") {
            summary.predicted <- (1 - exp( - exp(summary.predicted)
                        ))
        }
        if(link == "loglog") {
            summary.predicted <- exp( - exp( - summary.predicted))
        }
        if(link == "sqrt") {
            summary.predicted <- summary.predicted^2
        }
        if(link == "log") {
            summary.predicted <- exp(summary.predicted)
        }
        if(link == "recipical") {
            summary.predd <- 1/(summary.predicted)
            summary.predicted[, 1] <- summary.predd[, 3]
            summary.predicted[, 3] <- summary.predd[, 1]
            summary.predd <- NULL
        }
        summary.predicted <- as.matrix(summary.predicted)
        dimnames(summary.predicted) <- list(NULL, c("-2std_Lower", 
                        "Predicted", "+2std_Upper"))
    }
    llist <- list()
    llist$b <- b
    llist$coef <- coef
    llist$y.intercept <- yint
    llist$int <- int
    llist$press.mu <- press.mu
    llist$bin.percent.correct <- bin.percent.correct
    llist$family <- family
    llist$link <- link
    llist$ps.intervals <- ndx
    llist$order <- d
    llist$degree <- q
    llist$lambda <- lambda
    llist$aic <- aic
    llist$deviance <- dev
    llist$eff.df <- trace - 1
    llist$df.resid <- n - trace + 1
    llist$bin.percent.correct <- bin.percent.correct
    llist$dispersion.param <- dispersion.parm
    llist$summary.predicted <- summary.predicted
    llist$eta.predicted <- eta.predicted
    llist$cv.predicted <- cv.predicted
    llist$cv <- cv
    llist$mu <- mu
    llist$avediff.pred <- avediff.pred
    llist$beta<-beta
    llist
}

`ndiff` <-
        function(n, d = 1) {
# Construct the matrix for n-th differences
    if (d == 1)
    {D <- diff(diag(n))}
    else
    {D <- diff(ndiff(n, d - 1))}
    D}

`tpower` <-
        function(x, t, p)
# Truncated p-th power function
    (x - t) ^ p * (x > t)

`bbase` <-
        function(x, xl, xr, ndx, deg){
# Construct B-spline basis
    dx <- (xr - xl) / ndx
    knots <- seq(xl - deg * dx, xr + deg * dx, by = dx)
    P <- outer(x, knots, tpower, deg)
    n <- dim(P)[2]
    D <- ndiff(n, deg + 1) / (gamma(deg + 1) * dx ^ deg)
    B <- (-1) ^ (deg + 1) * P %*% t(D)
    B }

`gauss` <-
        function(x, mu, sig) {
# Gaussian-shaped function
    u <- (x - mu) / sig
    y <- exp(- u * u / 2)
    y }

`gbase` <-
        function(x, mus) {
# Construct Gaussian basis
    sig <- (mus[2] - mus[1]) / 2
    G <- outer(x, mus, gauss, sig)
    G }

`pbase` <-
        function(x, n) {
# Construct polynomial basis
    u <- (x - min(x)) / (max(x) - min(x))
    u <- 2 * (u - 0.5);
    P <- outer(u, seq(0, n, by = 1), "^")
    P }

`pnormal.der` <-
        function(x, y, nseg, bdeg, pord, lambda, plot = F, se = F) #, xpred)
{
    # Function pnormal: smooths scatterplot data with P-splines.
    # Input: 
    #   x = abcissae of data
    #   y = response
    #   nseg = number of intervals for B-splines
    #   bdeg = degree of B-splines
    #   pord = order of difference penalty
    #   lambda = smoothness parameter
    #   plot = plot parameter (T of F)
    #   se = plot parameter (T or F)
    
    # Output: an object of class "pspfit" with the following fields
    #   bdeg = degree of B-splines
    #   cv = cross-validation sum of squares
    #   ed.resid = effective degrees of freedom residuals
    #   effdim = effective dimension P-spline model
    #   family = "gaussian" (like glm object)
    #   lambda = smoothing parameter
    #   link = "identity" (like glm object)
    #   muhat = expected values for y (at x)
    #   mse = standard deviation of errors
    #   nseg = number of B-spline segments on domain from xmin to xmax)
    #   pord = order of difference penalty
    #   x = x as input
    #   xgrid = x grid used for plotting curve
    #   xmin = left boundary of B-spline domain
    #   xmax = right boundary of B-spline domain
    #   y = y as input
    #   ygrid = computed curve on x grid
    
    #
    # Side effect: a plot of (x,y) and the estimated curve (if plot = T) with twice se bands (if se=T).
    
    #
    # Paul Eilers and Brian Marx, 2003 (c)
    #
    
    # Compute B-spline basis 
    
    m <- length(x)
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.5 * (xr - xl)
    xmin <- xl - 0.5 * (xr - xl)
    B <- bbase(x, xmin, xmax, nseg, bdeg)
    
# Construct penalty stuff
    n <- dim(B)[2]
    P <- sqrt(lambda) * ndiff(n, pord)
    nix <- rep(0, n - pord)
    
# Fit
    if(lambda == 0) {
        f <- lsfit(B, y, intercept = F)
    }
    if(lambda > 0) {
        f <- lsfit(rbind(B, P), c(y, nix), intercept = F)
    }
    h <- hat(f$qr)[1:m]
    beta <- as.vector(f$coef)
    mu <- B %*% beta
    
# Cross-validation and dispersion
    r <- (y - mu)/(1 - h)
    cv <- sqrt((sum(r^2))/m)
    s <- sqrt(sum((y - mu)^2)/(m - sum(h)))
    
# Compute curve on grid
    u <- seq(xl, xr, length = 100)
    Bu <- bbase(u, xmin, xmax, nseg, bdeg)
    zu <- Bu %*% as.vector(f$coef)
#Bu2<-bbase(xpred, xmin, xmax, nseg, bdeg)
#fit.xpred<-Bu2 %*% as.vector(f$coef)
    
#Derivative
    B.der <- bbase(x, xmin, xmax, nseg, bdeg-1)
    alpha.der <- diff(f$coef)
    der <- B.der%*%alpha.der
#B.der2 <- bbase(xpred, xmin, xmax, nseg, bdeg-1)
#der.xpred<-B.der2 %*% alpha.der
    
# Compute derivative on grid
#u <- seq(xl, xr, length = 100)
#Bu.der <- bbase(u, xmin, xmax, nseg, bdeg-1)
#zu.der <- Bu.der %*% as.vector(diff(f$coef))
    
    
# Plot data and fit
    if(plot) {
        plot(x, y)
        lines(u, zu, col = 2)
        lines(u, zu.der, col = 4)
        if(se) {
            varf <- diag(Bu %*% solve(t(B) %*% B + t(P) %*% P) %*% t(Bu))
            sef <- s * sqrt(varf)
            upperu <- zu + 2 * sef
            loweru <- zu - 2 * sef
            lines(u, upperu, lty = 3, col = 3)
            lines(u, loweru, lty = 3, col = 3)
        }
    }
    
# Return list
    pp <- list(x = x, y = y, muhat = mu, nseg = nseg, xmin = xmin, bdeg = bdeg, pord
                    = pord, lambda = lambda, xgrid = u, ygrid = zu, cv = cv, effdim = sum(h
            ), ed.resid = m - sum(h), family = "gaussian", link = "identity", sqrt.mse = 
                    s, pcoef=beta, xmin=xmin, xmax=xmax) #, fit.xpred=fit.xpred, der.xpred=der.xpred)
    class(pp) <- "pspfit"
    pp
}

`predict.pnormal` <-
        function(obj,x,der){
    #der can only be either 0 or 1
    if (der==0){
        bu<-bbase(x,obj$xmin,obj$xmax,obj$nseg,obj$bdeg)
        out<-as.vector(bu%*%obj$pcoef)
    }
    if (der==1){
        B.der<-bbase(x, obj$xmin, obj$xmax, obj$nseg, obj$bdeg-1)
        alpha.der<-diff(obj$pcoef)
        out<-as.vector(B.der%*%alpha.der)/((obj$xmax-obj$xmin)/obj$nseg)
    }
    out
}



##################################################################


wrap.fgam <- function(spectTrain, spectTest, valTrain, nc=ncol(spectTrain)){
    stopifnot(require(mgcv))
    ntrain <- nrow(spectTrain)
    ntest <- nrow(spectTest)
     
    splinepars <- list(bs = "ps", k= rep(min(floor(sqrt(ntrain)), 8), 2))
    
    m <- try(fgam(valTrain ~ af(spectTrain, splinepars=splinepars, presmooth=FALSE, 
                            Xrange=range(spectTrain, spectTest))))
    
    if(class(m)[1] != "try-error"){
        freq <- matrix(1:ncol(spectTrain), ncol=ncol(spectTrain), nrow=ntest, byrow=TRUE)
        pred <- predict(m, newdata=list(spectTrain=spectTest))
        # sqrt(mean((pred - val2)^2))
        return(pred)  
    } else return(rep(NA, nrow(spectTest)))
    
}


# Nov 15, 2012; 10:34:50 AM: from rev 20 of refundDevel
fgam <- function(formula,fitter=NA,tensortype=c('te','t2'),...){
    
    call <- match.call()
    tensortype <- as.symbol(match.arg(tensortype))
    dots <- list(...)
    if (length(dots)) {
        validDots <- if (!is.na(fitter) && fitter == "gamm4") {
                    c(names(formals(gamm4)), names(formals(lmer)))
                }
                else {
                    c(names(formals(gam)), names(formals(gam.fit)))
                }
        notUsed <- names(dots)[!(names(dots) %in% validDots)]
        if (length(notUsed)) 
            warning("Arguments <", paste(notUsed, collapse = ", "), 
                    "> supplied but not used.")
    }
    tf <- terms.formula(formula, specials = c("s", "te", "t2", "lf", "af"))
    trmstrings <- attr(tf, "term.labels")
    terms <- sapply(trmstrings, function(trm) as.call(parse(text = trm))[[1]], 
            simplify = FALSE)
    frmlenv <- environment(formula)
    where.af <- attr(tf, "specials")$af - 1
    where.lf <- attr(tf, "specials")$lf - 1
    where.s <- attr(tf, "specials")$s - 1
    where.te <- attr(tf, "specials")$te - 1
    where.t2 <- attr(tf, "specials")$t2 - 1
    
    
    if (length(trmstrings)) {
        where.par <- which(!(1:length(trmstrings) %in% c(where.af, where.lf, where.s,where.te, where.t2)))
    }else where.par <- numeric(0)
    
    responsename <- attr(tf, "variables")[2][[1]]
    newfrml <- paste(responsename, "~", sep = "")
    newfrmlenv <- new.env()
    evalenv <- if ("data" %in% names(call)) 
                eval(call$data)
            else NULL
    nobs <- length(eval(responsename, envir = evalenv, enclos = frmlenv))
    
    if (missing(fitter) || is.na(fitter)) {
        fitter <- ifelse(nobs > 1e+05, "bam", "gam")
    }
    
    fitter <- as.symbol(fitter)
    if (as.character(fitter) == "bam" && !("chunk.size" %in% 
                names(call))) {
        call$chunk.size <- max(nobs/5, 10000)
    }
    if (as.character(fitter) == "gamm4") 
        stopifnot(length(where.te) < 1)
    
    assign(x = deparse(responsename), value = as.vector(t(eval(responsename, 
                                    envir = evalenv, enclos = frmlenv))), envir = newfrmlenv)
    
    newtrmstrings <- attr(tf, "term.labels")
    if (!attr(tf, "intercept")) {
        newfrml <- paste(newfrml, "0", sep = "")
    }
    
    if (length(c(where.af, where.lf))) {
        fterms <- lapply(terms[c(where.af, where.lf)], function(x) {
                    eval(x, envir = evalenv, enclos = frmlenv)
                })
        newtrmstrings[c(where.af, where.lf)] <- sapply(fterms, 
                function(x) {
                    safeDeparse(x$call)
                })
        lapply(fterms, function(x) {
                    lapply(names(x$data), function(nm) {
                                assign(x = nm, value = x$data[[nm]], envir = newfrmlenv)
                                invisible(NULL)
                            })
                    invisible(NULL)
                })
        fterms <- lapply(fterms, function(x) x[names(x) != 
                                    "data"])
    }
    else fterms <- NULL
    
    where.notf <- c(where.par,where.s,where.te,where.t2)
    if (length(where.notf)) {
        if ("data" %in% names(call)) 
            frmlenv <- list2env(eval(call$data), frmlenv)
        lapply(terms[where.notf], function(x) {
                    
                    nms <- if (!is.null(names(x))) {
                                all.vars(x[names(x) == ""])
                            }
                            else all.vars(x)
                    sapply(nms, function(nm) {
                                stopifnot(length(get(nm, envir = frmlenv)) == 
                                                nobs)
                                assign(x = nm, value = get(nm, envir = frmlenv), envir = newfrmlenv)
                                invisible(NULL)
                            })
                    invisible(NULL)
                })
    }
    
    newfrml <- formula(paste(c(newfrml, newtrmstrings), collapse = "+"))
    environment(newfrml) <- newfrmlenv
    fgamdata <- list2df(as.list(newfrmlenv))
    datameans <- sapply(as.list(newfrmlenv),mean)
    newcall <- expand.call(fgam, call)
    newcall$fitter <- type <- newcall$bs.int <- newcall$bs.yindex <- newcall$fitter <- NULL
    newcall$formula <- newfrml
    newcall$data <- quote(fgamdata)
    newcall$fitter <- newcall$tensortype <- NULL
    newcall[[1]] <- fitter
    
    
    res <- eval(newcall)
    
    res.smooth <- if (as.character(fitter) %in% c("gamm4", "gamm")) {
                res$gam$smooth
            }else res$smooth
    
    trmmap <- newtrmstrings
    names(trmmap) <- names(terms)
    labelmap <- as.list(trmmap)
    names(trmmap) <- names(terms)
    
    
    lbls <- sapply(res.smooth, function(x) x$label)
    if (length(where.par)) {
        for (w in where.par) labelmap[[w]] <- {
                where <- sapply(res.smooth, function(x) x$by) == 
                        names(labelmap)[w]
                sapply(res.smooth[where], function(x) x$label)
            }
        labelmap[-c(where.par)] <- lbls[pmatch(sapply(labelmap[-c(where.par)], function(x) {
                                    tmp <- eval(parse(text = x))
                                    if (is.list(tmp)) {
                                        return(tmp$label)
                                    }else {
                                        return(x)
                                    }
                                }), lbls)]
    }else{
        labelmap[1:length(labelmap)] <- lbls[pmatch(sapply(labelmap, 
                                function(x) {
                                    tmp <- eval(parse(text = x))
                                    if (is.list(tmp)) {
                                        return(tmp$label)
                                    }
                                    else {
                                        return(x)
                                    }
                                }), lbls)]
    }
    if (any(nalbls <- sapply(labelmap, function(x) any(is.na(x))))) {
        labelmap[nalbls] <- trmmap[nalbls]
    }
    names(res.smooth) <- lbls
    if (as.character(fitter) %in% c("gamm4", "gamm")) {
        res$gam$smooth <- res.smooth
    }else {
        res$smooth <- res.smooth
    }
    ret <- list(formula = formula, termmap = trmmap, labelmap = labelmap, 
            responsename = responsename, nobs = nobs,
            where = list(where.af = where.af, where.lf = where.lf, 
                    where.s = where.s, where.te = where.te, where.t2 = where.t2, 
                    where.par = where.par), datameans=datameans,ft = fterms)
    if (as.character(fitter) %in% c("gamm4", "gamm")) {
        res$gam$fgam <- ret
        class(res$gam) <- c("fgam", class(res$gam))
    }
    else {
        res$fgam <- ret
        class(res) <- c("fgam", class(res))
    }
    
    return(res)
}




# Nov 15, 2012; 10:34:50 AM: from rev 20 of refundDevel
af <- function(X, xind = seq(0, 1, l = ncol(X)), basistype = c("te","t2", "s"), 
        integration = c("simpson", "trapezoidal", "riemann"), 
        L = NULL, splinepars = list(bs = "ps", k= rep(min(ceiling(sqrt(nrow(X))),20),2),
                m = list(c(2, 2), c(2, 2))), presmooth = TRUE,Xrange=range(X),Qtransform=FALSE) {
    
    n=nrow(X)
    nt=ncol(X)
    basistype <- match.arg(basistype)
    integration <- match.arg(integration)
    if(is.null(splinepars$bs)) splinepars$bs <- 'ps'
    if(is.null(splinepars$k)) splinepars$k <- rep(min(ceiling(sqrt(nrow(X))),20),2)
    if(is.null(splinepars$m)) splinepars$m = list(c(2, 2), c(2, 2))
    
    xindname <- paste(deparse(substitute(X)), ".omat", sep = "")
    tindname <- paste(deparse(substitute(X)), ".tmat", sep = "")
    Lname <- paste("L.", deparse(substitute(X)), sep = "")
    
    if (is.null(dim(xind))) {
        xind <- t(xind)
        stopifnot(ncol(xind) == nt)
        if (nrow(xind) == 1) {
            xind <- matrix(as.vector(xind), nrow = n, ncol = nt, 
                    byrow = T)
        }
        stopifnot(nrow(xind) == n)
    }
    
    Xfd=NULL
    if(presmooth){
        bbt=create.bspline.basis(rangeval=range(xind),nbasis=ceiling(nt/4),                                   
                norder=splinepars$m[[2]][1]+2, breaks=NULL)
        
        # pre-smooth functional predictor
        temp <- smooth.basisPar(t(xind),t(X),bbt,int2Lfd(splinepars$m[[2]][2])) 
        Xfd <- temp$fd
        Xfd$y2cMap <-temp$y2cMap
        X <- t(sapply(1:n,function(i){eval.fd(xind[i,],Xfd[i])}))
        
        # need to check that smoothing didn't change range of data
        if(!Qtransform){
            if(max(X)>Xrange[2]){
                Xrange[2] <- max(X)
            } 
            if(min(X)<Xrange[1]){
                Xrange[1] <- min(X)
            }
        }
    }
    
    ecdf=NULL
    if(Qtransform){
        Xrange <- c(0,1)
        X <- apply(X, 2, function(x){ (rank(x)-1)/(length(x)-1)} )
        # need to keep ecdf's for prediction later
        ecdflist <- apply(X, 2, ecdf)     
    }
    
    if (!is.null(L)) {
        stopifnot(nrow(L) == n, ncol(L) == nt)
    }else {
        L <- switch(integration, simpson = {
                    ((xind[, nt] - xind[, 1])/nt)/3 * matrix(c(1,rep(c(4, 2), length = nt - 2), 1), nrow = n, 
                            ncol = nt, byrow = T)
                }, trapezoidal = {
                    diffs <- t(apply(xind, 1, diff))
                    0.5 * cbind(diffs[, 1], t(apply(diffs, 1, filter,filter = c(1, 1)))[, -(nt - 1)], 
                            diffs[,(nt - 1)])
                }, riemann = {
                    diffs <- t(apply(xind, 1, diff))
                    cbind(rep(mean(diffs), n), diffs)
                })
    }
    
    data <- list(X, xind, L)
    names(data) <- c(xindname, tindname, Lname)
    splinefun <- as.symbol(basistype)
    frmls <- formals(getFromNamespace(deparse(splinefun), ns = "mgcv"))
    frmls <- modifyList(frmls[names(frmls) %in% names(splinepars)], 
            splinepars)
    call <- as.call(c(list(splinefun, x = as.symbol(substitute(xindname)), 
                            z = as.symbol(substitute(tindname)), by = as.symbol(substitute(Lname))), 
                    frmls))
    res <-list(call = call, data = data, xind = xind[1,], L = L, xindname = xindname, tindname=tindname,
            Lname=Lname,Qtransform=Qtransform,presmooth=presmooth,Xrange=Xrange)
    if(Qtransform) res$ecdflist <- ecdflist
    if(presmooth) res$Xfd <- Xfd
    return(res)
}

# Nov 15, 2012; 10:34:50 AM: from rev 30 of refundDevel
predict.fgam <- function(object,newdata,type='response',
        se.fit=FALSE,terms=NULL,PredOutOfRange=FALSE,...){
    
    call <- match.call()
    string <- NULL
    if (!missing(newdata)) {
        nobs <- nrow(as.matrix(newdata[[1]]))
        
        #if (!(all(names(newdata) %in% names(object$model)))) {
        stopifnot(length(unique(sapply(newdata, function(x) ifelse(is.matrix(x),
                                                    nrow(x), length(x))))) == 1)
        gamdata <- list()
        varmap <- sapply(names(object$fgam$labelmap), function(x) all.vars(formula(paste("~",
                                            x))))
        
        for (cov in names(newdata)) {
            trms <- which(sapply(varmap, function(x) any(grep(paste("^",
                                                        cov, "$", sep = ""), x))))
            if (length(trms) != 0) {
                for (trm in trms) {
                    is.af <- trm %in% object$fgam$where$where.af
                    is.lf <- trm %in% object$fgam$where$where.lf
                    
                    if (is.af) {
                        af <- object$fgam$ft[[grep(paste(cov, "[,\\)]",
                                                sep = ""), names(object$fgam$ft))]]
                        if (grepl(paste(cov, "\\.[ot]mat", sep = ""),
                                deparse(af$call$x))) {
                            
                            if(length(attr(newdata[[cov]],"L"))){
                                if(nobs==nrow(attr(newdata[[cov]],"L"))){
                                    L <- attr(newdata[[cov]],"L")
                                }else{
                                    L <- matrix(af$L[1,],nobs,length(af$L[1,]),byrow=T)
                                }
                            }else{
                                L <- matrix(af$L[1,],nobs,length(af$L[1,]),byrow=T)
                            }
                            if(length(attr(newdata[[cov]],"tmat"))){
                                if(nobs==nrow(attr(newdata[[cov]],"tmat"))){
                                    tmat <- attr(newdata[[cov]],"tmat")
                                }else{
                                    tmat <- matrix(af$xind, ncol = length(af$xind),nrow = nobs,byrow=T)  
                                }
                            }else{
                                tmat <- matrix(af$xind, ncol = length(af$xind),nrow = nobs,byrow=T)
                            }
#                 if (any(apply(L, 2, function(x) length(unique(x))) !=
#                   1)) {
#                   stop("Error for ", names(varmap)[trm],
#                        "-- Prediction for af-terms with varying rows in integration operator L not implememented yet.")
#                 }
                            if(af$presmooth & !type=='lpmatrix'){
                                newXfd <- fd(tcrossprod(af$Xfd$y2cMap,newdata[[cov]]),af$Xfd$basis)
                                newdata[[cov]] <- t(eval.fd(af$xind,newXfd))
                            }
                            
                            if(af$Qtransform & !type=='lpmatrix'){
                                for(i in 1:nobs){
                                    newdata[[cov]][i,] <- mapply(function(tecdf,x){tecdf(x)},
                                            tecdf=af$ecdflist,x=newdata[[cov]][i,])
                                }
                            }
                            
                            gamdata[[paste(cov, ".omat", sep = "")]] <- newdata[[cov]]
                            gamdata[[paste(cov, ".tmat", sep = "")]] <- tmat
                            gamdata[[paste("L.", cov, sep = "")]] <- L
                            
                        }
                    }
                    if (is.lf) {
                        lf <- object$fgam$ft[[grep(paste(cov, "[,\\)]",
                                                sep = ""), names(object$fgam$ft))]]
                        
                        if (grepl(paste(cov, "\\.[t]mat", sep = ""),
                                deparse(lf$call$x))) {
                            
                            if(length(attr(newdata[[cov]],"L"))){
                                if(nobs==nrow(attr(newdata[[cov]],"L"))){
                                    L <- attr(newdata[[cov]],"L")
                                }else{
                                    L <- matrix(lf$L[1,],nobs,length(lf$L[1,]),byrow=T)
                                }
                            }else{
                                L <- matrix(lf$L[1,],nobs,length(lf$L[1,]),byrow=T)
                            }
                            if(length(attr(newdata[[cov]],"tmat"))){
                                if(nobs==nrow(attr(newdata[[cov]],"tmat"))){
                                    tmat <- attr(newdata[[cov]],"tmat")
                                }else{
                                    tmat <- matrix(lf$xind, ncol = length(lf$xind),nrow = nobs,byrow=T)  
                                }
                            }else{
                                tmat <- matrix(lf$xind, ncol = length(lf$xind),nrow = nobs,byrow=T)
                            }
#                 if (any(apply(L, 2, function(x) length(unique(x))) !=
#                   1)) {
#                   stop("Error for ", names(varmap)[trm],
#                        "-- Prediction for lf-terms with varying rows in integration operator L not implememented yet.")
#                 }
#                 predL <- matrix(L[1, ], byrow = TRUE,
#                                 nrow = nrow(newdata[[cov]]), ncol = ncol(L))
                            
                            if(af$presmooth){
                                newXfd <- fd(tcrossprod(lf$Xfd$y2cMap,newdata[[cov]]),lf$Xfd$basis)
                                newdata[[cov]] <- t(eval.fd(lf$xind,newXfd))
                            }
                            
                            gamdata[[paste(cov, ".tmat", sep = "")]] <- tmat
                            gamdata[[paste("L.", cov, sep = "")]] <- L*newdata[[cov]]
                        }
                        
                    }
                    if (!(is.af || is.lf)) {
                        gamdata[[cov]] <- drop(newdata[[cov]])
                    }
                }
            }
        }
        
        gamdata <- list2df(gamdata)
        call[["newdata"]] <- gamdata
        #}
    }
    else { #when newdata not specified
        call$newdata <- eval(call$newdata)
        nobs <- object$fgam$nobs
    }
    
    if(PredOutOfRange){
        suppressMessages(trace(splines::spline.des, at=2, quote({
                                    outer.ok <- TRUE
                                }),print=FALSE))
        on.exit(suppressMessages(try(untrace(splines::spline.des),silent=TRUE)))
    }
    
    oterms <- terms
    if(type %in% c('terms','iterms') & !all(terms %in% 
                    c(names(object$smooth),attr(object$pterms,'term.labels')))){
        if(terms %in% unlist(varmap)){
            tnames <- c(names(object$smooth),attr(object$pterms,'term.labels'))
            terms <- tnames[grep(paste(string, "[,\\.\\)]",sep = ""), tnames)]
        }else{
            stop('Invalid terms specified')
        }
    }
    
    
    call[[1]] <- mgcv::predict.gam
    call$object <- as.name("object")
    call$terms <- terms
    
    res <- eval(call)
    
    if(type %in% c('terms','iterms'))
        colnames(res) <- oterms
    
    return(res)
}


##################################################################
wrap.fregrenp <- function(spectTrain, spectTest, valTrain, nc=ncol(spectTrain)){
    stopifnot(require(fda.usc))
      
    fdTrain <- fdata(spectTrain)
    fdTest <- fdata(spectTest)            
    
    m <- try(fregre.np(fdTrain, valTrain))
    
    if(class(m)[1] != "try-error"){
        pred <- predict(m, new.fdataobj=fdTest)
        # sqrt(mean((pred - val2)^2))
        return(pred)  
    } else return(rep(NA, nrow(spectTest)))
    
}



##################################################################
##################################################################
##################################################################
##################################################################