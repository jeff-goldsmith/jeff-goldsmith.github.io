###############################################################################
# August 15 2013
#
# Jeff Goldsmith and Fabian Schiepl
#
# Complete data analysis of the Weather dataset, using the SuperLearner package
# framework. SuperLearner-style wrappers are included in "SL_Estimator_Lib.R".
# Note this package only allows one ensembler to be used. Figures similar to
# those in the full paper can be produced using this file.
###############################################################################

rm(list=ls())

library(SuperLearner)
library(ggplot2)
library(plyr)
library(scales)
library(gridExtra)
library(reshape2)

setwd("~/Online Code/Using SuperLearner Package/Weather")
source("SL_Estimator_Lib.R")

###############################################################################
## data input; estimator library; number of bootstrap replications
###############################################################################

library(fda)
data(CanadianWeather)

Y = log10(apply(CanadianWeather$dailyAv[,,"Precipitation.mm"], 2, sum))
X = as.data.frame(t(CanadianWeather$dailyAv[,,"Temperature.C"]))

I = length(Y)

## right now, PC-based estimators are commented out. this will be revised
## once the wrappers are updated to do a PC-decomposition.

SL.estimators = c("SL.flm", "SL.pfr", "SL.flirti", "SL.wnet",   ## FLMs
                  "SL.fpcr", #"SL.pclm",                         ## PC-based FLMs
#                  "SL.spikeslabgam",                            ## PC-based FAM
                  "SL.sisr", "SL.psr",                          ## single-index models
                  "SL.fgam", "SL.fregrenp",                     ## non-linear and non-parametric models
                  "SL.plsreg",                                  ## PLS
                  "SL.lasso", "SL.randomForest",      ## machine learning
                  "SL.mean")                                    ## mean-only (reference)
n.boot = 20


###############################################################################
## bootstrap super learner
###############################################################################

res = matrix(NA, nrow = n.boot, ncol = length(SL.estimators)+4)

for(i in 1:n.boot){
  
  set.seed(i)
  time.start = proc.time()
  
  ntrain=floor(.7*I)
  train <- sort(sample(1:I, ntrain))  

  SL.fit = SuperLearner(Y[train], X[train,], newX = X[-train,], 
                        SL.library = SL.estimators)    

  time.stop = proc.time()
  time = (time.stop - time.start)[3]
  res[i, ] = c(mean((Y[-train] - SL.fit$SL.pred)^2), colMeans((Y[-train] - SL.fit$library.predict)^2), i, ntrain, time)
               
  cat("\n", "Weather App: replication ", i, " done.\n")

}    

res = as.data.frame(res)

colnames(res) = c("ensemble", SL.estimators, "iteration", "ntrain", "time")
res$name = "Weather_App"


###############################################################################
## post-processing to find rankings, relative MSEs
##############################################################################

mean(res$time)

res <- melt(res, id.vars=c("name","iteration","ntrain","time"), value.name="mse")
colnames(res)[6] = "mse"

#add ranks, relative errors for each replicate
res <- ddply(res, ~ name + iteration, function(dd){
  #browser()
           
  #rank with smallest first, NAs as NA
  ranks <- ranks.single <- ranks.ensemble <- rep(NA, nrow(dd))
            
  ranks.single[grepl("SL", dd$variable)] <- ordered(
    rank(dd[grepl("SL", dd$variable), "mse"], na.last = "keep"))
            
  ranks[grepl("ensemble", dd$variable) | grepl("SL", dd$variable)] <- ordered(
    rank(dd[grepl("ensemble", dd$variable) | grepl("SL", dd$variable), "mse"], 
    na.last = "keep"))
            
  dd <- data.frame(dd, rank=ranks, rank.single=ranks.single)
  dd$rmse <- sqrt(dd$mse)
            
  # relMSE = MSE/min(MSE)
            
  dd$relmse <- with(dd, mse/min(mse, na.rm=TRUE))
  dd$relmse.single[grepl("SL", dd$variable)] <- with(dd[grepl("SL", dd$variable),],
    mse/min(mse, na.rm=TRUE))
            
  # relRMSE = RMSE/min(RMSE)
  dd$relrmse <- with(dd, rmse/min(rmse, na.rm=TRUE))
  dd$relrmse.single <- NA
  dd$relrmse.single[grepl("SL", dd$variable)] <- with(dd[grepl("SL", dd$variable),],
    rmse/min(rmse, na.rm=TRUE))
            
  dd$ensemble <- grepl("ensemble", dd$variable)
  return(dd)                    
})

##############################################################################
## figures
##############################################################################

par(mar=c(1,1,0,0))

clrs <- rev(colorRampPalette(c("blue", "green", "yellow", "red"))(40))    

x.seq = seq(0, 1, length = dim(X)[2])
X = as.matrix(X)
proj <- persp(x=x.seq, 
              y=seq(min(Y), max(Y), l=length(Y)), 
              z=t(X),
              xlab="Day",
              ylab="Log Annual Precip",
              zlab="Temperature",
              col=NA, border=NA,
              ticktype = "detailed", axes=TRUE,
              theta=30, phi=30)

colfct <- as.numeric(cut(Y, 40))
o <- rev(order(Y))
for(i in o){
  lines(trans3d(x=x.seq, 
                y=rep(Y[i], ncol(X)),
                z=X[i,], pmat=proj), 
        col=clrs[colfct[i]])
}

## plot results
ggplot(res, 
       aes(x=variable, y=relrmse, fill=ensemble)) + geom_line(aes(group=iteration), alpha=.05) +
         geom_boxplot() + theme_bw(base_size=16) + scale_fill_manual(values=c("white","grey")) +
         theme(axis.text.x=element_text(angle=40, hjust=1), legend.position="none")  +
         coord_trans(ytrans = "log2", limy=c(.95, 2)) +  
         labs(x="", y="relative RMSE", title=paste("Relative RMSE"))


###############################################################################
###############################################################################
###############################################################################
###############################################################################
###############################################################################
###############################################################################