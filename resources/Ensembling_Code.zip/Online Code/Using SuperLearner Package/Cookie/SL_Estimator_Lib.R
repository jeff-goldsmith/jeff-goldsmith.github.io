##################################################################
# August 15 2013
#
# Fabian Scheipl and Jeff Goldsmith
#
# This file contains a library of estimators for the scalar-on-
# function regression problem. Estimators are coded in the format
# of the SuperLearner package, and are called by the SuperLearner
# function. In many cases, wrappers are completely self-contained
# or use functions from existing packages. In other cases, helper
# functions precede the wrapper.
##################################################################


##################################################################
# the following code installs all packages needed by the SL
# estimation methods. it only needs to be run once.
##################################################################

if(FALSE){
    install.packages(c("fda","mgcv", "robustbase", "pcaPP", "chemometrics", "refund", "lpSolve", "gbm",
                    "glmnet", "randomForest", "wavethresh","monomvn", "nnls", "ppls",
                    "mboost", "spikeSlabGAM", "irlba", "svcm", "fda.usc", "lpSolve"), 
        repos="http://cran.r-project.org")    
}


##################################################################
##################################################################
## functional linear model
##################################################################
##################################################################

SL.flm <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(mgcv))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    ntrain <- nrow(X)
    ntest <- nrow(newX)
    freq <- matrix(1:ncol(X), ncol=ncol(X), nrow=ntrain, byrow=TRUE)
    
    m <- try(gam(Y ~ s(freq, by=X, k=min(nrow(X)-1, 40), bs="ad")))

    if(class(m)[1] != "try-error"){
      freq <- matrix(1:ncol(X), ncol=ncol(X), nrow=ntest, byrow=TRUE)
      pred <- predict(m, newdata=list(X=newX, freq=freq))
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## PFR - modified version of pfr.bslp 
##################################################################
##################################################################

SL.pfr <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(mgcv))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)
    
    kz = kb = 40
    
    I = length(Y)
    t = seq(0, 1, length = dim(X)[2])
    
    # set the basis to be used for beta(t)
    phi = cbind(1, bs(t, df=kb-1, intercept=FALSE, degree=2))
    
    XJ = X %*% phi
    XJ.valid = newX %*% phi
    
    X = cbind(rep(1, I), XJ)
    
    ## set design and penalty matrices depending
    fixed.mat = X[,1:(1+1)]
    rand.mat = X[,(1+2):(1+kb)]
    
    temp=matrix(0, nrow=kb-1, ncol=kb-1)
    for(i in 1:(kb-1)){
        for(j in 1:(kb-1)){
            temp[i,j]=min(i,j)-1
        }
    }
    D = matrix(1, nrow=kb-1, ncol=kb-1)+temp
    Dinv=solve(D)
    PenMat = list(length = 1)
    PenMat[[1]] = cbind(matrix(0, 1+kb, 1+1), rbind(matrix(0, 1+1, kb-1), Dinv))
    
    m = try(gam(Y ~ X - 1, paraPen = list(X = PenMat), method = "REML", family = "gaussian"))
    
    if(class(m)[1] != "try-error"){
        
      coefs = m$coef
        
      X.valid = cbind(1, XJ.valid)
      pred = X.valid %*% coefs
        
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## flirti - modified from original flirti code; intercept and 
## some options have been removed.
##################################################################
##################################################################

## helper functions from James' code
`linearoptim` <-
        function(Y,X,sigma,lambdap,weights=1,A,extra.con=NULL){
    p <- ncol(X)
    K <- nrow(A)
    f.obj <- weights
    XX <- t(X)%*%X
    b1 <- lambdap*sigma+as.vector(t(X)%*%Y)
    b2 <- lambdap*sigma-as.vector(t(X)%*%Y)
    f.con1 <- cbind(XX,-XX,matrix(0,p,2*K))
    f.con2 <- cbind(-XX,XX,matrix(0,p,2*K))
    f.con3 <- cbind(A,-A,diag(K),-diag(K))
    f.con <- rbind(f.con1,f.con2,f.con3)
    f.rhs <- c(b1,b2,rep(0,K))
    f.dir <- c(rep("<=",2*p),rep("==",K))
    if (!is.null(extra.con)){
        f.con <- rbind(f.con,extra.con)
        f.rhs <- c(f.rhs,0)
        f.dir <- c(f.dir,"==")
    }
    lpout <- lp("min",f.obj,f.con,f.dir,f.rhs)
    eta <- lpout$sol[1:p]-lpout$sol[(p+1):(2*p)]
    gamma <-lpout$sol[(2*p+1):(2*p+K)]-lpout$sol[(2*p+K+1):(2*p+2*K)]#gamma here is acutally -gamma
    if (lpout$status!=0){
        print(paste("Error: Code = ",lpout$status))
    }
    list(eta=eta,gamma=gamma,lpfit=lpout,code=lpout$status)}

`makeA` <-
        function(p,deriv=2,int=F){
    A <- NULL
    if (!is.na(match(1,deriv))){
        a <- c(-1,1,rep(0,p-1))
        K <- p-1
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(2,deriv))){
        a <- c(1,-2,1,rep(0,p-2))
        K <- p-2
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(3,deriv))){
        a <- c(-1,3,-3,1,rep(0,p-3))
        K <- p-3
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (!is.na(match(4,deriv))){
        a <- c(-1,4,-6,4,-1,rep(0,p-4))
        K <- p-4
        A <- rbind(A,matrix(rep(a,K)[1:(K*p)],K,p,byrow=T))
    }
    if (int)
        A <- cbind(0,A)
    A}


SL.flirti <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(mgcv))
  stopifnot(require(lpSolve))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    ## set tuning parameters
    deriv=2; weight=1; sigma = .001

    p <- ncol(X)
    beta.zero <- 0
    extra.con <- NULL
    if (length(weight)>1){
      deriv <- (1:4)[weight[-1]>0]  
    } else {
      weight <- c(weight,0,0,0,0)
      weight[deriv+1] <- 1
    }
    
    weights <- rep(weight[1],2*p)
      for (i in 2:5)
        if (weight[i]>0)
          weights <- c(weights,rep(weight[i],2*(p-i+1)))
    
    A <- makeA(p,deriv,FALSE)
    colscale <- apply(X,2,function(x){sqrt(sum(x^2))})
    newW <- t(t(X)/colscale)
    
    m <- try(linearoptim(Y,newW,sigma,sqrt(2*p),weights,A%*%diag(1/colscale),extra.con))
    
    if(class(m)[1] != "try-error"){
        beta <- m$eta/colscale
        pred = newX%*%beta
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## wavelet+lasso; note predictors have to have length of 2^k for some k.
##################################################################
##################################################################

## function for wnet that gives predictions; also silences output
wnet.pred =
        function (y, xfuncs, xfuncs.pred, min.scale, alpha, lambda = NULL, standardize = FALSE, 
                covt = NULL, pen.covt = FALSE, filter.number = 10, wavelet.family = "DaubLeAsymm", 
                family = "gaussian", nfold = 5, compare.fits = FALSE, store.cv = FALSE, 
                ...) 
{
    n <- length(y)
    if (!is.array(xfuncs) || !length(dim(xfuncs)) %in% 2:3) 
        stop("Argument xfuncs is invalid: must either be a 2D or 3D array.")
    dim.sig <- length(dim(xfuncs)) - 1
    if (dim(xfuncs)[1] != n) 
        stop("Arguments y and xfuncs has invalid lengths: ", 
                length(y), " and ", dim(xfuncs)[1], ".")
    if (dim(xfuncs)[2] != dim(xfuncs)[1 + dim.sig]) 
        stop("Number of rows and columns in image are not identical: ", 
                dim(xfuncs)[2], " and ", dim(xfuncs)[1 + dim.sig])
    d <- dim(xfuncs)[2]
    if (as.integer(log2(d)) != log2(d)) 
        stop("Argument xfuncs is invalid: the length of xfuncs must be of \n             power of 2.")
    if (sum(!min.scale %in% 0:(log2(d) - 1)) != 0) 
        stop("Argument min.scale is invalid: must be integer(s) between 0 and ", 
                log2(d) - 1, ".")
    if (alpha < 0 || alpha > 1) 
        stop("Argument alpha s invalid: must in [0,1].")
    if (!nfold %in% 1:n) 
        stop("Argument nfold is invalid: must be an integer between 1 and ", 
                n, ".")
    groups <- split(sample(1:n), rep(1:nfold, length = n))
    if (dim.sig == 1) {
        wave.decomp <- wd
        dec <- decomp
        rec <- reconstr
    }    else {
        wave.decomp <- imwd
        dec <- decomp2d
        rec <- reconstr2d
    }
    wdobjs <- apply(xfuncs, 1, wave.decomp, filter.number = filter.number, 
            family = wavelet.family)
    
    
    wdobjs.pred <- apply(xfuncs.pred, 1, wave.decomp, filter.number = filter.number, 
            family = wavelet.family)
    
    
    temp <- dec(wdobjs[[1]])
    p <- length(temp$coef)
    type.gaussian <- ifelse(p > n, "naive", "covariance")
    n.covt <- if (is.null(covt)) 
            { 0 } else ncol(as.matrix(covt))
    penalty.factor <- if (pen.covt) 
            {rep(1, n.covt + p)} else c(rep(0, n.covt), rep(1, p))
    cv.table <- lambda.table <- array(0, dim = c(length(min.scale), 
                    length(alpha), ifelse(is.null(lambda), 100, length(lambda))))
    dimnames(cv.table) <- list(paste("ms=", min.scale, sep = ""), 
            paste("alpha=", alpha, sep = ""), if (is.null(lambda)) NULL else paste("lambda=", 
                                lambda, sep = ""))
    if (compare.fits) {
        fhat.table <- array(0, dim = c(d^dim.sig, nfold, length(min.scale), 
                        length(alpha), ifelse(is.null(lambda), 100, length(lambda))))
        dimnames(fhat.table) <- list(NULL, paste("nfold =", 1:nfold), 
                paste("ms =", min.scale), paste("alpha =", alpha), 
                paste("lambda", if (is.null(lambda)) 1:100 else lambda))
    }
    for (ims in 1:length(min.scale)) {
        coef <- t(array(unlist(sapply(wdobjs, dec, min.scale = min.scale[ims])[1, 
                                ]), dim = c(p, n)))
        for (ialpha in 1:length(alpha)) {
            if (is.null(lambda)) {
                obje <- glmnet(x = as.matrix(cbind(covt, coef)), 
                        y = y, family = family, alpha = alpha[ialpha], 
                        standardize = standardize, type.gaussian = type.gaussian, 
                        penalty.factor = penalty.factor, ...)
                templam <- range(obje$lambda)
                lambda.table[ims, ialpha, ] <- seq(templam[1], 
                        templam[2], length = 100)
            }
            else {
                lambda.table[ims, ialpha, ] <- lambda
            }
            for (ifold in 1:nfold) {
#                cat("min.scale:", min.scale[ims], "\t", "alpha:", 
#                  alpha[ialpha], "fold:", ifold, "\n")
                idxTest <- groups[[ifold]]
                idxTrain <- (1:n)[-idxTest]
                obje <- glmnet(x = as.matrix(cbind(covt, coef)[idxTrain, 
                                ]), y = y[idxTrain], lambda = lambda.table[ims, 
                                ialpha, ], family = family, alpha = alpha[ialpha], 
                        standardize = standardize, type.gaussian = type.gaussian, 
                        penalty.factor = penalty.factor, ...)
                if (compare.fits) {
                    theta.w <- matrix(predict(obje, s = lambda.table[ims, 
                                            ialpha, ], type = "coefficients"), ncol = dim(lambda.table)[3])
                    temp$callInfo$min.scale <- min.scale[ims]
                    for (ilambda in 1:dim(lambda.table)[3]) {
                        temp$coef <- theta.w[, ilambda]
                        fhat.table[, ifold, ims, ialpha, ilambda] <- as.vector(rec(temp))
                    }
                }
                yhat <- predict(obje, newx = as.matrix(cbind(covt, 
                                        coef)[idxTest, ]), s = lambda.table[ims, ialpha, 
                        ], type = "response")
                if (family == "gaussian") 
                    cv.table[ims, ialpha, ] <- cv.table[ims, ialpha, 
                    ] + colMeans((y[idxTest] - yhat)^2)
                else if (family == "binomial") {
                    misclass <- function(x) mean((x > mean(y[idxTrain])) != 
                                        y[idxTest])
                    cv.table[ims, ialpha, ] <- cv.table[ims, ialpha, 
                    ] + apply(yhat > mean(y[idxTrain]), 2, misclass)
                }
            }
        }
    }
    idxmin <- which(cv.table == min(cv.table[cv.table != 0], 
                    na.rm = TRUE), arr.ind = TRUE)
    if (nrow(idxmin) > 1) 
        idxmin <- idxmin[1, ]
    min.scale <- min.scale[idxmin[1]]
    alpha <- alpha[idxmin[2]]
    lambda <- lambda.table[idxmin[1], idxmin[2], idxmin[3]]
    coef <- t(array(unlist(sapply(wdobjs, dec, min.scale = min.scale)[1, 
                            ]), dim = c(p, n)))
    
    
    coef.pred <- t(array(unlist(sapply(wdobjs.pred, dec, min.scale = min.scale)[1, 
                            ]), dim = c(p, dim(xfuncs.pred)[1])))
    
    
    obje <- glmnet(x = as.matrix(cbind(covt, coef)), y = y, lambda = lambda, 
            family = family, alpha = alpha, standardize = standardize, 
            type.gaussian = type.gaussian, penalty.factor = penalty.factor, ...)
    theta <- as.numeric(predict(obje, s = lambda, type = "coefficients"))
    yhat <- predict(obje, newx = as.matrix(cbind(covt, coef)), 
            s = lambda, type = "response")
    
    
    yhat.pred <- predict(obje, newx = as.matrix(cbind(covt, coef.pred)), 
            s = lambda, type = "response")
    
    
    ret = list(yhat.pred); names(ret) = c("fitted")
    return(ret)
}


SL.wnet <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(refund))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    ntrain <- nrow(X)
    ntest <- nrow(newX)
    
    # make sure we have 2^k columns:
    if(log2(ncol(X))%%1 != 0){
      padding <- 2^ceiling(log2(ncol(X))) -ncol(X)
      X <- cbind(X, matrix(0, ncol=padding, nrow=nrow(X)))
      newX <- cbind(newX, matrix(0, ncol=padding, nrow=nrow(newX)))
    }
    
    m <- try(wnet.pred(y=Y, min.scale = 4, alpha = 1, xfuncs=X, xfuncs.pred = newX))
    if(class(m)[1] != "try-error"){
      pred <- m$fitted
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## functional principal components regression
##################################################################
##################################################################

SL.fpcr <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(refund))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)
    
    ntrain <- nrow(X)
    ntest <- nrow(newX)
    
    m <- try(fpcr(y=c(Y, rep(0,ntest)), nbasis=min(ntrain+ntest-1, 80), 
                    ncomp=30, xfuncs=rbind(X, newX),
                    weights=c(rep(1, ntrain), rep(0, ntest))))
    if(class(m)[1] != "try-error"){
      pred <- fitted(m)[-(1:ntrain)]
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## partial least squares
##################################################################
##################################################################

SL.plsreg <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(ppls))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    m <-  try(penalized.pls.cv(X=X, y=Y, k=15))

    if(class(m)[1] != "try-error"){
      pred <- try(drop(new.penalized.pls(m, newX)$ypred))
      if(class(pred)[1] == "try-error"){
        pred = rep(NA, nrow(newX))
      } 
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## single-index signal regression
##################################################################
##################################################################

sisr <- function(y, t=1:ncol(X), X, d=40, pendegree=2, 
        tol=1e-3, maxiter=50,
        plot=TRUE, verbose=TRUE){
    stopifnot(require(mgcv))
    #use notation from B. Marx slides:
    # d = dim basis
    # P = penalty matrix
    # T = basis matrix
    d <- pmin(d, length(y)-1)
    D <- switch(pendegree, 
            "null"=diag(d), "1"=diff(diag(d)), "2"=diff(diff(diag(d))))
    P <- crossprod(D)
    
    T <- bs(t, intercept = TRUE, df=d)
    M <- X%*%T
    
    y <- drop(y)
    
    
    if(plot) layout(t(1:5))
    
    ystar <- y
    Mstar <- M
    m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
    gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
    gammahat.0 <- 2*gammahat.new
    Mgamma <- drop(M%*%gammahat.new) 
    mse <- rep(NA,maxiter)
    iter <- 0
    while((mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))) > tol) && (iter<maxiter)){
        iter  <- iter + 1
        
        
        mf <- gam(y ~ s(Mgamma))
        fhat <- drop(fitted(mf))
        
        mse[iter] <- mean((fhat-y)^2)
        if(verbose) {
            cat("iter: ", iter, 
                    "diff(gamma)/|gamma|:", mean(abs(gammahat.0 - gammahat.new)/pmax(abs(gammahat.0),abs(gammahat.new))), 
                    "mse:", mse[iter], "\n")
        }
        
        h <- max(1e-5, min(diff(sort(Mgamma)))/10 )
        fderiv <- drop( predict(mf, newdata=data.frame(Mgamma=Mgamma+h)) - predict(mf, newdata=data.frame(Mgamma=Mgamma-h)))/(2*h)
        if(plot){
            plot(t, T%*%gammahat.new, type="l", ask=TRUE)
            plot(Mgamma, fhat)
            plot(Mgamma, fderiv)
            plot(y, fhat); abline(c(0,1))
            plot(1:iter, mse[1:iter], type="l")
        } 
        
        ystar <- y - fhat + fderiv*Mgamma
        Mstar <- diag(fderiv)%*%M
        
        m <- gam(ystar ~ Mstar -1 , paraPen=list(Mstar=list(P)))
        gammahat.0 <- gammahat.new
        gammahat.new <- m$coefficients/sqrt(sum(m$coefficients^2))
        Mgamma <- drop(M%*%gammahat.new)
        
    }
    mf <- gam(y ~ s(Mgamma))
    
    ret <- list(gammahat=gammahat.new, fit=fitted(mf), mf=mf, T=T, call=match.call())
    return(ret)
}    

predict.sisr <- function(obj, Xnew){
    Mgammanew <- Xnew%*%(obj$T%*%obj$gammahat)
    predict(obj$mf, newdata=list(Mgamma=Mgammanew))
}


SL.sisr <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(mgcv))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    m <- try(sisr(y=Y, X=X, maxiter=500, d=40, pendegree=2, plot=FALSE, verbose=FALSE))
    
    if(class(m)[1] != "try-error"){
      pred <- predict.sisr(m, Xnew=newX)
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## penalized signal regression
##################################################################
##################################################################

sim.psr <- function(x, y, ps., lam., ord., max.iter){
    
    #1: Initialization: estimate alpha (from signal.fit) and f (from pnormal) 
    x.index <- 1:ncol(x)
    psr.fit <- signal.fit(y, x.index, x, ps.int=ps.[1], lambda=10^6, 
            ridge.adj=0, coef.plot=F, order=1, se=F, int=T)
    b       <- psr.fit$b
    u       <- x%*%b
    D       <- diag(ncol(b))
    for (j in 1:ord.[1]) { D <- diff(D) }
    alpha   <- as.vector(psr.fit$coef[-1])
    int     <- as.vector(psr.fit$coef[1])
    eta     <- as.vector(u%*%alpha) + int
    
    f.fit   <- pnormal.der(x=eta, y=y, nseg=ps.[2], bdeg=3, pord=ord.[2], 
            lambda=lam.[2], plot = F, se = F)
    der     <- predict.pnormal(f.fit, eta, 1)
    f.eta   <- predict.pnormal(f.fit, eta, 0)
    
    iter    <- 1                 #Initialize number of iterations
    cv      <- f.fit$cv          #Track the cv errors
    d.alpha <- NULL              #Track convergence of alpha
    
    #2: Start iteration
    for (it in 2:max.iter){
        
        ## Update alpha and intercept through lsfit
        y.star    <- y-f.eta+der*eta
        u.tilda   <- diag(der)%*%cbind(1,u)
        p         <- cbind(0,sqrt(lam.[1])*D)
        nix       <- rep(0,nrow(D))
        u.p       <- rbind(u.tilda,p)
        y.p       <- c(y.star, nix)
        
        fit1      <- lsfit(u.p, y.p, intercept=F)
        int.new   <- as.vector(fit1$coef[1])
        alpha.new <- as.vector(fit1$coef[2:ncol(u.p)])  
        
        ## Check the convergence of alpha
        tmp1      <- alpha/sqrt(mean(alpha^2))
        tmp2      <- alpha.new/sqrt(mean(alpha.new^2))
        d.alpha   <- c(d.alpha,mean((tmp2-tmp1)^2)/mean(tmp2^2))
        
        if ( d.alpha[(it-1)] < 10^(-3) ) 
            break 
        
        ## Estimate f through pnormal
        alpha  <- alpha.new
        int    <- int.new
        eta    <- as.vector(u%*%alpha) + int
        f.fit   <- pnormal.der(x=eta, y=y, nseg=ps.[2], bdeg=3, pord=ord.[2], 
                lambda=lam.[2], plot = F, se = F)
        der     <- predict.pnormal(f.fit, eta, 1)
        f.eta   <- predict.pnormal(f.fit, eta, 0)
    }
    
    out<-list(cv=cv, iter=(it-1), alpha=alpha, int=int, b=b, f=f.fit, ps.=ps., 
            lam.=lam., ord.=ord., delta.alpha=d.alpha)
}

predict.sim.psr <- function(obj, x){
    eta <- as.vector(x%*%obj$b%*%obj$alpha) + obj$int
    out <- predict.pnormal(obj$f, eta, 0) 
    out
}

fit.one.iter<-function(x,y,ps.,ord.,lam.,rdg.adj){
    x.index<-1:ncol(x)
    psr<-signal.fit(y, x.index, x, ps.int=ps.[1], lambda=lam.[1], ridge.adj=rdg.adj,
            coef.plot=F, order=ord.[1], se=F, x.predicted=x, y.predicted=y)
    eta<-as.vector(psr$eta.predicted)
    f<-pnormal.der(x=eta,y=y,nseg=ps.[2],bdeg=3,pord=ord.[2],lambda=lam.[2],
            plot=F, se=F)
    out<-list(psr=psr,f=f)
    out
}

pred.one.iter<-function(xnew,psr,f){
    eta<-as.vector(xnew%*%psr$b%*%psr$coef[-1]+psr$coef[1])
    out<-as.vector(predict.pnormal(f,eta,0))
    out
}

psr.wrapped <- function(x, y, 
        ps.=c(80,20),      # no. of basis functions 
        ord.=c(3,2),       # order of diff. penalties
        max.iter= 200,     # max no. of iterations 
        lower = c(-8,-4), 
        upper = c(-4,4),   #lower /upper bounds for log(lambda) 
        start = upper,     
        ngrid = 20,        #size of grid for lambda-search
        validratio=.25){   #ratio of cases in validation set
    
    stopifnot(require(svcm))
    #split validation/training data
    valid <- sort(sample(1:nrow(x), nrow(x)*validratio))
    x.train <- x[-valid, ]
    y.train <- y[-valid]
    x.valid <- x[valid, ]
    y.valid <- y[valid]
    
    cleverwrapper<-function(vec){
        fit  <- sim.psr(x.train, y.train, ps., vec, ord., max.iter)
        tmp1 <- predict.sim.psr(fit, x.valid)
        out  <- sqrt(mean(((tmp1-y.valid)^2)))
        out
    }
    
    opt.sim<-cleversearch(cleverwrapper, lower, upper, ngrid, start, 
            logscale=TRUE, clever=TRUE, verbose=FALSE)
    
    fit<-sim.psr(rbind(x.train,x.valid), c(y.train,y.valid), ps., 
            lam.=opt.sim$par, ord., max.iter) 
    
    #return validation data indices for reproducibility
    fit$valid <- valid
    
    return(fit)
}

SL.psr <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(mgcv))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    m <- try(psr.wrapped(y=Y, x=X, lower = c(-12, 2), 
                    upper = c(-9,6), ngrid = 50))
    
    if(class(m)[1] != "try-error"){
      pred <- predict.sim.psr(m, newX)
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## lasso
##################################################################
##################################################################

SL.lasso <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(glmnet))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    m <- try(cv.glmnet(x=X, y=Y, alpha = 1))
        
    if(class(m)[1] != "try-error"){
      pred <- try(predict(m, newx=newX))
      if(class(pred)[1] == "try-error"){
        pred = rep(NA, nrow(newX))
      } 
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## pc linear model
##################################################################
##################################################################

SL.pclm <- function(Y, X, newX, family, obsWeights, id, ...){
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    nc=NCOL(X)
    B=20

    boot <- function(){
        error <- rep(NA, nc)
        train <- sort(sample(1:nrow(X), nrow(X), replace=TRUE))
        test <- setdiff(1:nrow(X),train)
        for(n.col in 1:nc){
            y <- Y[train]
            x <- X[train,1:n.col]
            m <- lm(y ~ x)
            pred <- predict(m, newdata=list(x=X[test, 1:n.col]))
            error[n.col] <- mean((pred-Y[test])^2)
        }
        return(error)
    } 
    err <- try(replicate(B, boot()))
    use.nc <- try(which.min(rowMeans(err)))
    x <- try(X[,1:use.nc])
    m <- try(lm(Y ~ x))

    if(class(m)[1] != "try-error"){
      pred <-  predict(m, newdata=list(x=newX[,1:use.nc]))
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## spike and slab generalize additive model
##################################################################
##################################################################

SL.spikeslabgam <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(spikeSlabGAM))
  options(cores=1)
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    nc=NCOL(X)

    scX <- scale(X[,1:nc])
    scnewX <- scale(newX[,1:nc], 
            center=attr(scX, "scaled:center"),
            scale=attr(scX, "scaled:scale"))
    if(is.null(colnames(scX))) {
        colnames(scX) <- colnames(scnewX) <- paste("x",1:nc,sep="")
    }
    scy <- scale(Y)/2
    data <- data.frame(y=scy, scX)
    frml <- formula(paste("y~", paste("sm(", colnames(scX), ", K=8, centerBase=F)", collapse="+")))
    m <- try(spikeSlabGAM(formula=frml, data=data))
        
    if(class(m)[1] != "try-error"){
      pred <-  try(2*attr(scy, "scaled:scale")*predict(m, 
                   newdata=data.frame(y=NA, scnewX)) +
                   attr(scy, "scaled:center"))
      if(class(pred)[1] == "try-error"){
        pred = rep(NA, nrow(newX))
      } 
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## fgam
##################################################################
##################################################################

SL.fgam <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(refund))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    ntrain <- nrow(X)
    ntest <- nrow(newX)
    splinepars <- list(bs = "ps", k= rep(min(floor(sqrt(ntrain)), 8), 2))
    m <- try(fgam(Y ~ af(X, splinepars=splinepars, presmooth=FALSE, 
                            Xrange=range(X, newX))))
        
    if(class(m)[1] != "try-error"){
      pred <- predict(m, newdata=list(X=newX))
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## fregrenp
##################################################################
##################################################################

SL.fregrenp <- function(Y, X, newX, family, obsWeights, id, ...){

  stopifnot(require(fda.usc))
  
  if(family$family == 'gaussian'){
    X <- as.matrix(X)
    newX <- as.matrix(newX)

    fdTrain <- fdata(X)
    fdTest <- fdata(newX)            
    m <- try(fregre.np(fdTrain, Y))
        
    if(class(m)[1] != "try-error"){
      pred <- predict(m, new.fdataobj=fdTest)
    } else {
      pred = rep(NA, nrow(newX))
    }
  }
  if(family$family == 'binomial'){
    stop("Only gaussian outcomes allowed")
  }
  
  fit = vector("list", length = 0)
  class(fit) <- 'SL.template'
  out <- list(pred = pred, fit = fit)
  return(out)

}


##################################################################
##################################################################
## code necessary for marx.sisr (copied from functions.dump)
##################################################################
##################################################################

`poly.signal.fit` <-
        function(response, x.index, x.signal, poly.order=1,importance = NULL, m.binomial = NULL, 
                ps.intervals = 8, degree = 3, order = 3, wts = NULL, link = "default", 
                family = "gaussian", r.gamma = NULL, lambda.vector = 0, y.predicted = NULL, 
                x.predicted = NULL, ridge.adj = 0, int = T, coef.plot = T
)
{
# Function signal.fit: smooths signal (multivariate calibration) beta's using P-splines.
# Input: x.index= abcissae of spectra (1:p).
# Input: x.signal= (n X p) explanatory variable signal matrix (p >> n possible).
# Input: response= response variable.
# Input: importance: a vector of importance of B-splines for variable lambda: (ps.int+q) x 1
# Input: poly.order: order of polynomial for additive polynomial signal regression (1=PSR)
# Input: family=gaussian, binomial, poisson, Gamma distribution.
# Input: m.binomial=vector of binomial trials. Default is 1 vector.
# Input: r.gamma=vector of gamma shape parameters. Default is 1 vector.
# Input: link= link function (identity, log, sqrt, logit, probit, cloglog, loglog, recipical).
# Input: ps.intervals= number of intervals for B-splines. Default=8.
# Input: degree= degree of B-splines. Default=3.
# Input: order= order of difference penalty. Default=3.
# Input: lambda.vector= must have length = poly.order; smoothness regulalizing parameter ( >= 0). Default=0.
# Input: x.predicted=a matrix of row (original) signals for prediction and twice stderr limits.
# Input: y.predicted= a vector of responses from a cv data set (assoc. with cv x.predicted).
# Input: ridge.adj= a small positive constant to help stabilize linear dependencies among B-splines.
# Result: a plot of smoothed beta's and twice stderr.
# Output: A list: including, AIC= deviance + 2*trace(Hat), dispers.parm, etc.
#
# Support Functions: pspline.fitter() and pspline.checker()
#
# References:
# Marx, B.D. and Eilers, P.H.C. (1999). Generalized linear regression for sampled signals and
#        curves: A P-spline approach. Technometrics, 41(1): 1-13.
# Eilers, P.H.C. and Marx, B.D. (1996). Flexible smoothing with B-splines and penalties (with comments
#        and rejoinder). Statistical Science, 11(2): 89-121.
#
# (c) 1995 Paul Eilers & Brian Marx
#
    y <- response
    x <- x.index
    vv <- importance
    n <- length(y)
    if(missing(wts)) {
        wts <- rep(1, n)
    }
    parms <- pspline.checker(family, link, degree, order, ps.intervals, 
            lambda=1, ridge.adj, wts)
    if(length(lambda.vector)!=poly.order){
        lambda.vector<-rep(lambda.vector[1],poly.order)
        warning(paste("Only used first lambda.vector entry: lambda.vec should have length = poly.ord"))}
    family <- parms$family
    link <- parms$link
    q <- parms$degree
    d <- parms$order
    ridge.adj <- parms$ridge.adj
#lambda <- parms$lambda
    ndx <- parms$ps.intervals
    wts <- parms$wts
    if(missing(m.binomial)) {
        m.binomial <- rep(1, n)
    }
    if(missing(r.gamma)) {
        r.gamma <- rep(1, n)
    }
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.01 * (xr - xl)
    xmin <- xl - 0.01 * (xr - xl)
    dx <- (xmax - xmin)/ndx
    knots <- seq(xmin - q * dx, xmax + q * dx, by = dx)
    b <- spline.des(knots, x, q + 1, 0 * x)$design
    n.col <- ncol(b)
    if(missing(importance)) {
        vv <- rep(1, n.col)
    }
    if(d < 0) {
        d <- min(3, (n.col - 1))
        warning(paste("penalty order cannot be negative: have used", d)
        )
    }
    if((d - n.col + 1) > 0) {
        d <- n.col - 1
        warning(paste("penalty order was too large: have used", d))
    }
    p.ridge <- NULL
    if(ridge.adj > 0) {
        nix.ridge <- rep(0, poly.order*n.col)
        p.ridge <- sqrt(ridge.adj) * diag(rep(1, poly.order*n.col))
    }
    p <- diag(n.col)
    if(d != 0) {
        for(j in 1:d) {
            p <- diff(p)
        }
    }
    pdiff<-p
    n.row<-nrow(p)
    
    p <- sqrt(lambda.vector[1]) * (1/sqrt(vv + 1e-008)) * p
    nix <- rep(0, poly.order*(n.col - d))
    x.signal <- as.matrix(x.signal)
    b<-as.matrix(b)
    xb <- x.signal %*% b
    
    PPen<-matrix(0,poly.order*n.row,poly.order*n.col)
    if(poly.order>1){
        for(iii in 1:poly.order)
        {PPen[((iii-1)*n.row+1):(iii*n.row),((iii-1)*n.col+1):(iii*n.col)]<-sqrt(lambda.vector[iii])*(1/sqrt(vv+1e-8))*pdiff
        }
        p<-PPen
    }
    if(poly.order>1){
        for(ii in c(2:poly.order)){
            xbnew<-cbind(xb,(x.signal^ii)%*%b)
            xb<-xbnew
        }
    }
    
    if(int) {
        xb <- cbind(rep(1, n), xb)
        p <- cbind(rep(0, nrow(p)), p)
        if(ridge.adj > 0) {
            p.ridge <- cbind(rep(0, nrow(p.ridge)), p.ridge)
        }
    }
    ps.fit <- pspline.fitter(family, link, n.col, m.binomial, r.gamma, y, b
                    = xb, p, p.ridge, nix, nix.ridge, ridge.adj, wts)
    mu <- ps.fit$mu
    coef <- ps.fit$coef
    bin.percent.correct <- NULL
    if(family == "binomial") {
        pcount <- 0
        p.hat <- mu/m.binomial
        for(ii in 1:n) {
            if(p.hat[ii] > 0.5) {
                count <- y[ii]
            }
            if(p.hat[ii] <= 0.5) {
                count <- m.binomial[ii] - y[ii]
            }
            count <- pcount + count
            pcount <- count
        }
        bin.percent.correct <- count/sum(m.binomial)
    }
    w <- ps.fit$w
    e <- 1e-009
    h <- hat(ps.fit$f$qr, intercept = F)[1:n]
    trace <- sum(h)
    if(family == "binomial") {
        dev <- 2 * sum((y + e) * log((y + e)/mu) + (m.binomial - y + e) *
                        log((m.binomial - y + e)/(m.binomial - mu)))
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "poisson") {
        dev <- 2 * sum(y * log(y + e) - y - y * log(mu) + mu)
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "Gamma") {
        dev <- -2 * sum(r.gamma * (log((y + e)/mu) - ((y - mu)/mu)))
        ave.dev <- dev/n
        dispersion.parm <- (ave.dev * (6 + ave.dev))/(6 + 2 * ave.dev)
        cv <- NULL
    }
    cv <- press.mu <- press.e <- NULL
    if(family == "gaussian") {
        dev <- sum(ps.fit$f$residuals[1:n]^2)
        dispersion.parm <- dev/(n - trace)
        press.e <- ps.fit$f$residuals[1:n]/(1 - h)
        cv <- sqrt(sum((press.e)^2)/(n))
        press.mu <- y - press.e
    }
    aic <- dev + 2 * trace
    w.aug <- c(w, (nix + 1))
    yint<-NULL
    if(int){
        yint <- ps.fit$coef[1]
    }
    
    
#summary.beta <- beta
    if(coef.plot) {
        par(mfrow=c(2,2))
        
        for(ii in c(1:poly.order)){
            beta.in<-b%*%(as.vector(ps.fit$f$coef)[(int+(ii-1)*n.col+1):(int+(ii*n.col))])
            plot(x.index, beta.in, col = 1, type = "l", 
                    lty = 1, xlab = "Coefficient Index", ylab = 
                            "P-spline Coefficient")
        }
    }
    summary.predicted <- NULL
    cv.predicted <- eta.predicted <- avediff.pred <- NULL
    
    if(!missing(x.predicted)) {
        x.predicted <- as.matrix(x.predicted)
        xpb<-x.predicted%*%b
        if(poly.order>1){
            for(ii in c(2:poly.order)){
                xpbnew<-cbind(xpb,(x.predicted^ii)%*%b)
                xpb<-xpbnew
            }
        }
        if(!int) {
            if(ncol(x.predicted) > 1) {
                eta.predicted <- xpb %*% as.vector(ps.fit$f$coef)
                
            }
            if(ncol(x.predicted) == 1) {
                eta.predicted <- t(xpb) %*% as.vector(ps.fit$f$coef)
                
            }
        }
        if(int) {
            dim.xp <- nrow(x.predicted)
            if(ncol(x.predicted) > 1) {
                
                one.xpred.b <- cbind(rep(1, dim.xp), (
                                    xpb))
                
                eta.predicted <- one.xpred.b %*% as.vector(ps.fit$f$coef) #+ yint
                
            }
            if(ncol(x.predicted) == 1) {
                one.xpred.b <- cbind(1, t(xpb))
                eta.predicted <- t(one.xpred.b) %*% as.vector(ps.fit$f$coef) #+ yint
                
            }
        }
        
        summary.predicted <-  eta.predicted
        if(!missing(y.predicted)) {
            if(family == "gaussian") {
                cv.predicted <- sqrt(sum((y.predicted - 
                                            eta.predicted)^2)/(length(y.predicted)))
                avediff.pred <- (sum(y.predicted - 
                                            eta.predicted))/length(y.predicted)
            }
        }
        bin.percent.correct <- NULL
        if(link == "logit") {
            summary.predicted <- 1/(1 + exp( - summary.predicted))
            pcount <- 0
            p.hat <- exp(eta.predicted)/(1 + exp(eta.predicted))
            if(!missing(y.predicted)) {
                for(ii in 1:length(eta.predicted)) {
                    if(p.hat[ii] > 0.5) {
                        count <- y.predicted[ii]
                    }
                    if(p.hat[ii] <= 0.5) {
                        count <- 1 - y.predicted[ii]
                    }
                    count <- pcount + count
                    pcount <- count
                }
                bin.percent.correct <- count/length(y.predicted
                )
            }
        }
        if(link == "probit") {
            summary.predicted <- apply(summary.predicted, c(1, 2), 
                    pnorm)
        }
        if(link == "cloglog") {
            summary.predicted <- (1 - exp( - exp(summary.predicted)
                        ))
        }
        if(link == "loglog") {
            summary.predicted <- exp( - exp( - summary.predicted))
        }
        if(link == "sqrt") {
            summary.predicted <- summary.predicted^2
        }
        if(link == "log") {
            summary.predicted <- exp(summary.predicted)
        }
        if(link == "recipical") {
            summary.predd <- 1/(summary.predicted)
            summary.predd <- NULL
        }
        
    }
    llist <- list()
    llist$b <- b
    llist$coef <- coef
    llist$y.intercept <- yint
    llist$int <- int
    llist$press.mu <- press.mu
    llist$bin.percent.correct <- bin.percent.correct
    llist$family <- family
    llist$link <- link
    llist$ps.intervals <- ndx
    llist$order <- d
    llist$degree <- q
    llist$lambda <- lambda.vector
    llist$aic <- aic
    llist$deviance <- dev
    llist$eff.df <- trace - 1
    llist$df.resid <- n - trace + 1
    llist$bin.percent.correct <- bin.percent.correct
    llist$dispersion.param <- dispersion.parm
    llist$summary.predicted <- summary.predicted
    llist$eta.predicted <- eta.predicted
    llist$cv.deleteone <- cv
    llist$mu <- mu
    llist$avediff.pred <- avediff.pred
    llist$cv.predicted <- cv.predicted
    llist
}

`pspline.checker` <-
        function(family, link, degree, order, ps.intervals, lambda, ridge.adj, wts)
{
    if(link == "default" && family == "gaussian") {
        link <- "identity"
    }
    if(link == "default" && family == "poisson") {
        link <- "log"
    }
    if(link == "default" && family == "binomial") {
        link <- "logit"
    }
    if(link == "default" && family == "Gamma") {
        link <- "log"
    }
    if(family != "binomial" && family != "gaussian" && family != "poisson" && 
            family != "Gamma") {
        warning(paste("Improper FAMILY option. Choose: gaussian, poisson, binomial or Gamma"
                ))
    }
    if((family == "binomial") && (link != "logit" && link != "probit" && 
                link != "cloglog" && link != "loglog")) {
        warning(paste("Improper LINK option with family=binomial. Choose: logit, probit, loglog, cloglog"
                ))
    }
    if((family == "Gamma") && (link != "log" && link != "recipical" && link !=
                "identity")) {
        warning(paste("Improper LINK option with family=Gamma. Choose: recipical, log, identity"
                ))
    }
    if((family == "poisson") && (link != "log" && link != "sqrt" && link != 
                "identity")) {
        warning(paste("Improper LINK option with family=poisson. Choose: log, sqrt, identity"
                ))
    }
    if((family == "gaussian") && (link != "identity")) {
        warning(paste("Improper LINK option with family=gaussian. Choose: identity"
                ))
    }
    if(degree < 0) {
        degree <- 1
        warning(paste("degree must be non-neg integer: have used 1"))
    }
    if(order < 0) {
        order <- 0
        warning(paste("order must be non-neg integer: have used 0"))
    }
    if(ps.intervals < 2) {
        ps.intervals <- 2
        warning(paste("ps.intervals must be positive integer, > 1: have used 2"
                ))
    }
    if(lambda < 0) {
        lambda <- 0
        warning(paste("lambda cannot be negative: have used 0"))
    }
    if(ridge.adj < 0) {
        ridge.adj <- 0
        warning(paste("ridge.adj cannot be negative: have used 0"))
    }
    if(min(wts) < 0) {
        warning(paste("At least one weight entry is negative"))
    }
    llist <- list(family = family, link = link, degree = degree, order = 
                    order, ps.intervals = ps.intervals, lambda = lambda, ridge.adj
                    = ridge.adj, wts = wts)
    return(llist)
}

`pspline.fitter` <-
        function(family, link, n.col, m.binomial, r.gamma, y, b, p, p.ridge, nix, 
                nix.ridge, ridge.adj, wts, ...)
{
    coef.est <- rep(1, ncol(b))
    if(family == "binomial") {
        mu <- (y + 0.5 * m.binomial)/2
    }
    if(family == "Gamma" || family == "poisson") {
        mu <- log(y + 3)
    }
    if(family == "gaussian") {
        mu <- rep(mean(y), length(y))
    }
    it <- 0
    repeat {
        if(it == 0) {
            if(link == "identity") {
                eta <- mu
            }
            if(link == "log") {
                eta <- log(mu)
            }
            if(link == "sqrt") {
                eta <- sqrt(mu)
            }
            if(link == "logit") {
                eta <- log(mu/(m.binomial - mu))
            }
            if(link == "recipical") {
                eta <- 1/mu
            }
            if(link == "probit") {
                eta <- qnorm(mu/m.binomial)
            }
            if(link == "cloglog") {
                eta <- log( - log(1 - mu/m.binomial))
            }
            if(link == "loglog") {
                eta <-  - log( - log(mu/m.binomial))
            }
        }
        it<-it+1
        if(it > 25)
            break
        if(link == "identity") {
            mu <- eta
            h.prime <- 1
        }
        if(link == "log") {
            mu <- exp(eta)
            h.prime <- mu
        }
        if(link == "sqrt") {
            mu <- eta^2
            h.prime <- 2 * eta
        }
        if(link == "logit") {
            mu <- m.binomial/(1 + exp( - eta))
            h.prime <- mu * (1 - mu/m.binomial)
        }
        if(link == "recipical") {
            mu <- 1/eta
            h.prime <-  - (mu^2)
        }
        if(link == "probit") {
            mu <- m.binomial * pnorm(eta)
            h.prime <- m.binomial * dnorm(eta)
        }
        if(link == "cloglog") {
            mu <- m.binomial * (1 - exp( - exp(eta)))
            h.prime <- (m.binomial) * exp(eta) * exp( - exp(eta))
        }
        if(link == "loglog") {
            mu <- m.binomial * exp( - exp( - eta))
            h.prime <- m.binomial * exp( - eta) * exp( - exp( - eta
                    ))
        }
        if(family == "gaussian") {
            w <- rep(1, length(y))
        }
        if(family == "poisson") {
            w <- h.prime^2/mu
        }
        if(family == "binomial") {
            w <- h.prime^2/(mu * (1 - mu/m.binomial))
        }
        if(family == "Gamma") {
            w <- (r.gamma * h.prime^2)/mu^2
        }
        u <- (y - mu)/h.prime + eta
        if(ridge.adj > 0) {
            f <- lsfit(rbind(b, p, p.ridge), c(u, nix, nix.ridge), 
                    wt = c(wts, nix + 1, nix.ridge + 1) * c(w, (nix +
                                        1), (nix.ridge + 1)), intercept = F)
        }
        if(ridge.adj == 0) {
            f <- lsfit(rbind(b, p), c(u, nix), wt = c(wts, nix + 1) *
                            c(w, (nix + 1)), intercept = F)
        }
        coef.old <- coef.est
        coef.est <- as.vector(f$coef)
        d.coef <- max(abs((coef.est - coef.old)/coef.old))
        
#            print(c(it, d.coef))
        if(d.coef < 1e-008)
            break
        eta <- b %*% coef.est
    }
    if(it > 24) {
        warning(paste("parameter estimates did NOT converge in 25 iterations"
                ))
    }
    llist <- list(coef = coef.est, mu = mu, f = f, w = w * wts)
    return(llist)
}

`signal.fit` <-
        function(response, x.index, x.signal, importance = NULL, m.binomial = NULL, 
                ps.intervals = 8, degree = 3, order = 3, wts = NULL, link = "default", 
                family = "gaussian", r.gamma = NULL, lambda = 0, y.predicted = NULL, 
                x.predicted = NULL, ridge.adj = 0, int = T, coef.plot = T, se.bands = T
)
{
# Function signal.fit: smooths signal (multivariate calibration) beta's using P-splines.
# Input: x.index= abcissae of spectra (1:p).
# Input: x.signal= (n X p) explanatory variable signal matrix (p >> n possible).
# Input: response= response variable.
# Input: importance: a vector of importance of B-splines for variable lambda: (ps.int+q)
# Input: family=gaussian, binomial, poisson, Gamma distribution.
# Input: m.binomial=vector of binomial trials. Default is 1 vector.
# Input: r.gamma=vector of gamma shape parameters. Default is 1 vector.
# Input: link= link function (identity, log, sqrt, logit, probit, cloglog, loglog, recipical).
# Input: ps.intervals= number of intervals for B-splines. Default=8.
# Input: degree= degree of B-splines. Default=3.
# Input: order= order of difference penalty. Default=3.
# Input: lambda= smoothness regulalizing parameter ( >= 0). Default=0.
# Input: x.predicted=a matrix of row (original) signals for prediction and twice stderr limits.
# Input: y.predicted= a vector of responses from a cv data set (assoc. with cv x.predicted).
# Input: ridge.adj= a small positive constant to help stabilize linear dependencies among B-splines.
# Result: a plot of smoothed beta's and twice stderr.
# Output: A list: including, AIC= deviance + 2*trace(Hat), dispers.parm, etc.
#
# Support Functions: pspline.fitter() and pspline.checker()
#
# References:
# Marx, B.D. and Eilers, P.H.C. (1999). Generalized linear regression for sampled signals and
#        curves: A P-spline approach. Technometrics, 41(1): 1-13.
# Eilers, P.H.C. and Marx, B.D. (1996). Flexible smoothing with B-splines and penalties (with comments
#        and rejoinder). Statistical Science, 11(2): 89-121.
#
# (c) 1995 Paul Eilers & Brian Marx
#
    y <- response
    x <- x.index
    vv <- importance
    n <- length(y)
    if(missing(wts)) {
        wts <- rep(1, n)
    }
    parms <- pspline.checker(family, link, degree, order, ps.intervals, 
            lambda, ridge.adj, wts)
    family <- parms$family
    link <- parms$link
    q <- parms$degree
    d <- parms$order
    ridge.adj <- parms$ridge.adj
    lambda <- parms$lambda
    ndx <- parms$ps.intervals
    wts <- parms$wts
    if(missing(m.binomial)) {
        m.binomial <- rep(1, n)
    }
    if(missing(r.gamma)) {
        r.gamma <- rep(1, n)
    }
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.01 * (xr - xl)
    xmin <- xl - 0.01 * (xr - xl)
    dx <- (xmax - xmin)/ndx
    knots <- seq(xmin - q * dx, xmax + q * dx, by = dx)
    b <- spline.des(knots, x, q + 1, 0 * x)$design
    n.col <- ncol(b)
    if(missing(importance)) {
        vv <- rep(1, n.col)
    }
    if(d < 0) {
        d <- min(3, (n.col - 1))
        warning(paste("penalty order cannot be negative: have used", d)
        )
    }
    if((d - n.col + 1) > 0) {
        d <- n.col - 1
        warning(paste("penalty order was too large: have used", d))
    }
    p.ridge <- NULL
    if(ridge.adj > 0) {
        nix.ridge <- rep(0, n.col)
        p.ridge <- sqrt(ridge.adj) * diag(rep(1, n.col))
    }
    p <- diag(n.col)
    if(d != 0) {
        for(j in 1:d) {
            p <- diff(p)
        }
    }
    p <- sqrt(lambda) * (1/sqrt(vv + 1e-008)) * p
    nix <- rep(0, n.col - d)
    x.signal <- as.matrix(x.signal)
    xb <- x.signal %*% as.matrix(b)
    if(int) {
        xb <- cbind(rep(1, n), xb)
        p <- cbind(rep(0, nrow(p)), p)
        if(ridge.adj > 0) {
            p.ridge <- cbind(rep(0, nrow(p.ridge)), p.ridge)
        }
    }
    ps.fit <- pspline.fitter(family, link, n.col, m.binomial, r.gamma, y, b
                    = xb, p, p.ridge, nix, nix.ridge, ridge.adj, wts)
    mu <- ps.fit$mu
    coef <- ps.fit$coef
    bin.percent.correct <- NULL
    if(family == "binomial") {
        pcount <- 0
        p.hat <- mu/m.binomial
        for(ii in 1:n) {
            if(p.hat[ii] > 0.5) {
                count <- y[ii]
            }
            if(p.hat[ii] <= 0.5) {
                count <- m.binomial[ii] - y[ii]
            }
            count <- pcount + count
            pcount <- count
        }
        bin.percent.correct <- count/sum(m.binomial)
    }
    w <- ps.fit$w
    e <- 1e-009
    h <- hat(ps.fit$f$qr, intercept = F)[1:n]
    trace <- sum(h)
    if(family == "binomial") {
        dev <- 2 * sum((y + e) * log((y + e)/mu) + (m.binomial - y + e) *
                        log((m.binomial - y + e)/(m.binomial - mu)))
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "poisson") {
        dev <- 2 * sum(y * log(y + e) - y - y * log(mu) + mu)
        dispersion.parm <- 1
        cv <- NULL
    }
    if(family == "Gamma") {
        dev <- -2 * sum(r.gamma * (log((y + e)/mu) - ((y - mu)/mu)))
        ave.dev <- dev/n
        dispersion.parm <- (ave.dev * (6 + ave.dev))/(6 + 2 * ave.dev)
        cv <- NULL
    }
    cv <- press.mu <- press.e <- NULL
    if(family == "gaussian") {
        dev <- sum(ps.fit$f$residuals[1:n]^2)
        dispersion.parm <- dev/(n - trace)
        press.e <- ps.fit$f$residuals[1:n]/(1 - h)
        cv <- sqrt(sum((press.e)^2)/(n))
        press.mu <- y - press.e
    }
    aic <- dev + 2 * trace
    w.aug <- c(w, (nix + 1))
    if(int) {
        beta <- b %*% (as.vector(ps.fit$f$coef)[2:(n.col + 1)])
        yint <- ps.fit$coef[1]
    }
    if(!int) {
        yint <- NULL
        beta <- b %*% as.vector(ps.fit$f$coef)
    }
    half.meat <- sqrt(c(w)) * xb
    meat <- t(half.meat) %*% half.meat
    if(ridge.adj > 0) {
        bread <- solve(meat + t(p) %*% p + t(p.ridge) %*% p.ridge)
    }
    if(ridge.adj == 0) {
        bread <- solve(meat + t(p) %*% p)
    }
    half.sw <- half.meat %*% bread[, (1 + int):(n.col + int)]
    var.c <- t(half.sw) %*% half.sw
    half.lunch <- half.sw %*% t(b)
    ones <- 0 * y + 1
    var.beta <- ones %*% (half.lunch * half.lunch)
    stdev.beta <- sqrt(dispersion.parm) * t(sqrt(var.beta))
    pivot <- 2 * stdev.beta
    upper <- beta + pivot
    lower <- beta - pivot
    summary.beta <- cbind(lower, beta, upper)
    if(coef.plot) {
        if(se.bands) {
            matplot(x.index, summary.beta, type = "l", lty = c(3, 1,
                            3), col = rep(1, 3), xlab = "Coefficient Index",
                    ylab = "P-spline Coefficient")
        }
        if(!se.bands) {
            plot(x.index, summary.beta[, 2], col = 1, type = "l", 
                    lty = 1, xlab = "Coefficient Index", ylab = 
                            "P-spline Coefficient")
        }
    }
    summary.predicted <- NULL
    cv.predicted <- eta.predicted <- avediff.pred <- NULL
    if(!missing(x.predicted)) {
        x.predicted <- as.matrix(x.predicted)
        if(!int) {
            if(ncol(x.predicted) > 1) {
                eta.predicted <- x.predicted %*% beta
                var.pred <- x.predicted %*% b %*% var.c %*% t(
                        x.predicted %*% b)
            }
            if(ncol(x.predicted) == 1) {
                eta.predicted <- t(x.predicted) %*% beta
                var.pred <- t(x.predicted) %*% b %*% var.c %*% 
                        t(b) %*% x.predicted
            }
        }
        if(int) {
            var.c <- t(bread) %*% t(half.meat) %*% half.meat %*% 
                    bread
            dim.xp <- nrow(x.predicted)
            if(ncol(x.predicted) > 1) {
                one.xpred.b <- cbind(rep(1, dim.xp), (
                                    x.predicted %*% b))
                eta.predicted <- x.predicted %*% beta + yint
                var.pred <- one.xpred.b %*% var.c %*% t(
                        one.xpred.b)
            }
            if(ncol(x.predicted) == 1) {
                one.xpred.b <- cbind(1, t(x.predicted) %*% b)
                eta.predicted <- t(x.predicted) %*% beta + yint
                var.pred <- (one.xpred.b) %*% var.c %*% t(
                        one.xpred.b)
            }
        }
        stdev.pred <- as.vector(sqrt(diag(var.pred)))
        stdev.pred <- sqrt(dispersion.parm) * stdev.pred
        pivot <- as.vector(2 * stdev.pred)
        upper <- eta.predicted + pivot
        lower <- eta.predicted - pivot
        summary.predicted <- cbind(lower, eta.predicted, upper)
        if(!missing(y.predicted)) {
            if(family == "gaussian") {
                cv.predicted <- sqrt(sum((y.predicted - 
                                            eta.predicted)^2)/(length(y.predicted)))
                avediff.pred <- (sum(y.predicted - 
                                            eta.predicted))/length(y.predicted)
            }
        }
        bin.percent.correct <- NULL
        if(link == "logit") {
            summary.predicted <- 1/(1 + exp( - summary.predicted))
            pcount <- 0
            p.hat <- exp(eta.predicted)/(1 + exp(eta.predicted))
            if(!missing(y.predicted)) {
                for(ii in 1:length(eta.predicted)) {
                    if(p.hat[ii] > 0.5) {
                        count <- y.predicted[ii]
                    }
                    if(p.hat[ii] <= 0.5) {
                        count <- 1 - y.predicted[ii]
                    }
                    count <- pcount + count
                    pcount <- count
                }
                bin.percent.correct <- count/length(y.predicted
                )
            }
        }
        if(link == "probit") {
            summary.predicted <- apply(summary.predicted, c(1, 2), 
                    pnorm)
        }
        if(link == "cloglog") {
            summary.predicted <- (1 - exp( - exp(summary.predicted)
                        ))
        }
        if(link == "loglog") {
            summary.predicted <- exp( - exp( - summary.predicted))
        }
        if(link == "sqrt") {
            summary.predicted <- summary.predicted^2
        }
        if(link == "log") {
            summary.predicted <- exp(summary.predicted)
        }
        if(link == "recipical") {
            summary.predd <- 1/(summary.predicted)
            summary.predicted[, 1] <- summary.predd[, 3]
            summary.predicted[, 3] <- summary.predd[, 1]
            summary.predd <- NULL
        }
        summary.predicted <- as.matrix(summary.predicted)
        dimnames(summary.predicted) <- list(NULL, c("-2std_Lower", 
                        "Predicted", "+2std_Upper"))
    }
    llist <- list()
    llist$b <- b
    llist$coef <- coef
    llist$y.intercept <- yint
    llist$int <- int
    llist$press.mu <- press.mu
    llist$bin.percent.correct <- bin.percent.correct
    llist$family <- family
    llist$link <- link
    llist$ps.intervals <- ndx
    llist$order <- d
    llist$degree <- q
    llist$lambda <- lambda
    llist$aic <- aic
    llist$deviance <- dev
    llist$eff.df <- trace - 1
    llist$df.resid <- n - trace + 1
    llist$bin.percent.correct <- bin.percent.correct
    llist$dispersion.param <- dispersion.parm
    llist$summary.predicted <- summary.predicted
    llist$eta.predicted <- eta.predicted
    llist$cv.predicted <- cv.predicted
    llist$cv <- cv
    llist$mu <- mu
    llist$avediff.pred <- avediff.pred
    llist$beta<-beta
    llist
}

`ndiff` <-
        function(n, d = 1) {
# Construct the matrix for n-th differences
    if (d == 1)
    {D <- diff(diag(n))}
    else
    {D <- diff(ndiff(n, d - 1))}
    D}

`tpower` <-
        function(x, t, p)
# Truncated p-th power function
    (x - t) ^ p * (x > t)

`bbase` <-
        function(x, xl, xr, ndx, deg){
# Construct B-spline basis
    dx <- (xr - xl) / ndx
    knots <- seq(xl - deg * dx, xr + deg * dx, by = dx)
    P <- outer(x, knots, tpower, deg)
    n <- dim(P)[2]
    D <- ndiff(n, deg + 1) / (gamma(deg + 1) * dx ^ deg)
    B <- (-1) ^ (deg + 1) * P %*% t(D)
    B }

`gauss` <-
        function(x, mu, sig) {
# Gaussian-shaped function
    u <- (x - mu) / sig
    y <- exp(- u * u / 2)
    y }

`gbase` <-
        function(x, mus) {
# Construct Gaussian basis
    sig <- (mus[2] - mus[1]) / 2
    G <- outer(x, mus, gauss, sig)
    G }

`pbase` <-
        function(x, n) {
# Construct polynomial basis
    u <- (x - min(x)) / (max(x) - min(x))
    u <- 2 * (u - 0.5);
    P <- outer(u, seq(0, n, by = 1), "^")
    P }

`pnormal.der` <-
        function(x, y, nseg, bdeg, pord, lambda, plot = F, se = F) #, xpred)
{
    # Function pnormal: smooths scatterplot data with P-splines.
    # Input: 
    #   x = abcissae of data
    #   y = response
    #   nseg = number of intervals for B-splines
    #   bdeg = degree of B-splines
    #   pord = order of difference penalty
    #   lambda = smoothness parameter
    #   plot = plot parameter (T of F)
    #   se = plot parameter (T or F)
    
    # Output: an object of class "pspfit" with the following fields
    #   bdeg = degree of B-splines
    #   cv = cross-validation sum of squares
    #   ed.resid = effective degrees of freedom residuals
    #   effdim = effective dimension P-spline model
    #   family = "gaussian" (like glm object)
    #   lambda = smoothing parameter
    #   link = "identity" (like glm object)
    #   muhat = expected values for y (at x)
    #   mse = standard deviation of errors
    #   nseg = number of B-spline segments on domain from xmin to xmax)
    #   pord = order of difference penalty
    #   x = x as input
    #   xgrid = x grid used for plotting curve
    #   xmin = left boundary of B-spline domain
    #   xmax = right boundary of B-spline domain
    #   y = y as input
    #   ygrid = computed curve on x grid
    
    #
    # Side effect: a plot of (x,y) and the estimated curve (if plot = T) with twice se bands (if se=T).
    
    #
    # Paul Eilers and Brian Marx, 2003 (c)
    #
    
    # Compute B-spline basis 
    
    m <- length(x)
    xl <- min(x)
    xr <- max(x)
    xmax <- xr + 0.5 * (xr - xl)
    xmin <- xl - 0.5 * (xr - xl)
    B <- bbase(x, xmin, xmax, nseg, bdeg)
    
# Construct penalty stuff
    n <- dim(B)[2]
    P <- sqrt(lambda) * ndiff(n, pord)
    nix <- rep(0, n - pord)
    
# Fit
    if(lambda == 0) {
        f <- lsfit(B, y, intercept = F)
    }
    if(lambda > 0) {
        f <- lsfit(rbind(B, P), c(y, nix), intercept = F)
    }
    h <- hat(f$qr)[1:m]
    beta <- as.vector(f$coef)
    mu <- B %*% beta
    
# Cross-validation and dispersion
    r <- (y - mu)/(1 - h)
    cv <- sqrt((sum(r^2))/m)
    s <- sqrt(sum((y - mu)^2)/(m - sum(h)))
    
# Compute curve on grid
    u <- seq(xl, xr, length = 100)
    Bu <- bbase(u, xmin, xmax, nseg, bdeg)
    zu <- Bu %*% as.vector(f$coef)
#Bu2<-bbase(xpred, xmin, xmax, nseg, bdeg)
#fit.xpred<-Bu2 %*% as.vector(f$coef)
    
#Derivative
    B.der <- bbase(x, xmin, xmax, nseg, bdeg-1)
    alpha.der <- diff(f$coef)
    der <- B.der%*%alpha.der
#B.der2 <- bbase(xpred, xmin, xmax, nseg, bdeg-1)
#der.xpred<-B.der2 %*% alpha.der
    
# Compute derivative on grid
#u <- seq(xl, xr, length = 100)
#Bu.der <- bbase(u, xmin, xmax, nseg, bdeg-1)
#zu.der <- Bu.der %*% as.vector(diff(f$coef))
    
    
# Plot data and fit
    if(plot) {
        plot(x, y)
        lines(u, zu, col = 2)
        lines(u, zu.der, col = 4)
        if(se) {
            varf <- diag(Bu %*% solve(t(B) %*% B + t(P) %*% P) %*% t(Bu))
            sef <- s * sqrt(varf)
            upperu <- zu + 2 * sef
            loweru <- zu - 2 * sef
            lines(u, upperu, lty = 3, col = 3)
            lines(u, loweru, lty = 3, col = 3)
        }
    }
    
# Return list
    pp <- list(x = x, y = y, muhat = mu, nseg = nseg, xmin = xmin, bdeg = bdeg, pord
                    = pord, lambda = lambda, xgrid = u, ygrid = zu, cv = cv, effdim = sum(h
            ), ed.resid = m - sum(h), family = "gaussian", link = "identity", sqrt.mse = 
                    s, pcoef=beta, xmin=xmin, xmax=xmax) #, fit.xpred=fit.xpred, der.xpred=der.xpred)
    class(pp) <- "pspfit"
    pp
}

`predict.pnormal` <-
        function(obj,x,der){
    #der can only be either 0 or 1
    if (der==0){
        bu<-bbase(x,obj$xmin,obj$xmax,obj$nseg,obj$bdeg)
        out<-as.vector(bu%*%obj$pcoef)
    }
    if (der==1){
        B.der<-bbase(x, obj$xmin, obj$xmax, obj$nseg, obj$bdeg-1)
        alpha.der<-diff(obj$pcoef)
        out<-as.vector(B.der%*%alpha.der)/((obj$xmax-obj$xmin)/obj$nseg)
    }
    out
}


##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################