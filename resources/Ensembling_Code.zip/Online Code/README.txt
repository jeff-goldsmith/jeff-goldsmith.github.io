Online Supplement to:
"Estimator Selection and Combination in Scalar-on-Function Regression"
by Jeff Goldsmith and Fabian Schiepl


This supplement contains two folders with code for estimator selection and ensembling:
-- As In Paper
-- Using SuperLearner Package

The first folder contains the code that was used for the data analyses as they appear in the paper. The second folder implements similar analyses using the SuperLearner package. Subdirectories for each data set are contained in both folders. 

The primary differences between the folders are:
-- Format of wrappers for each estimation method
-- The SuperLearner package allows only one ensembling method; the code used in the paper compares several ensemblers.

The wrappers used for estimation techniques contain code from many sources, and we do not take credit for authorship in many cases. Also keep in mind that, because these wrappers are based on many sources, changes in the dependencies may change their behavior.
