Code for "Functional Regression via Variational Bayes"
By J. Goldsmith, M. Wand and C. Crainiceanu.

This folder contains four files to explore the use of variational Bayes methods in functional regression. The two R files general simulated datasets and fit cross-sectional or longitudinal regression models using VB. The .txt files contain WinBUGS models for fitting the same models; they are called from their respective R files using R2WinBUGS. 