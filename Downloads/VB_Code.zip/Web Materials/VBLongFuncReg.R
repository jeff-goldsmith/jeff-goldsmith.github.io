
#############################################################
# Jeff Goldsmith
# Last Updated: 11 Aug 2010
#
# in this file we compare the inference for a longitudinal
# functional regression model fit using two approaches: a
# fully bayesian approach and a variational approximation 
# approach. 
#############################################################

rm(list=ls())

library(nlme)
library(SemiPar)
library(splines)
library(R2WinBUGS)

###     Set the seed for simulation
set.seed(1)

I = 100		  			# sample size
J = 3					# number of visits
VarEps = .5				# measurement error variance
VarY = 10				# variance on the outcome
VarRanEf = 5
tlength = 10

## set some standard parameters
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

Kg=Kw=25

## select true gamma function
trueGamma = 2*sin(t*pi/5)
#trueGamma = sqrt(t)
#trueGamma = .25*(t-5)^2

## select the true non-functional parameter
trueBeta = c(0,3)

doGenData=T
doMCMC=T
doVB=T
doPlotGamma=T
doVBvsMCMC=T

#############################################################
# generate the functional covariates and the observed covariates
#############################################################

if(doGenData){
	funcs <- matrix(0, nrow=I*J, ncol=N_obs)
	for(i2 in 1:(I*J)){
		funcs[i2,]=funcs[i2,]+runif(1, 0, 5)
		funcs[i2,]=funcs[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs[i2,]=funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs[i2,]=funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}

	W = funcs + rnorm(I*J*N_obs, sd=sqrt(VarEps))
	X = cbind(1,runif(I*J, min=-5, max = 5))

	## generate random effects: subject specific intercepts
	ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)

	## generate outcomes from true Beta function and functions measured without error
	Y <- sapply(1:(I*J), function(u) sum(funcs[u,]*trueGamma)*by+trueBeta%*%X[u,]+ranef[u])+rnorm(I*J, 0, sqrt(VarY))


	#############################################################
	# compute covariance matrix and PC decomposition
	#############################################################


	meanFunc=apply(W, 2, mean, na.rm=TRUE)
	resd=sapply(1:length(t), function(u) W[,u]-meanFunc[u])
	W=resd

	# construct and smooth covariance matrices
	G.sum <- matrix(0, N_obs, N_obs)
	G.count <- matrix(0, N_obs, N_obs)

	for(i in 1:dim(resd)[1]){
    	row.ind=i
	    temp=resd[row.ind, ] %*% t( resd[row.ind, ])
		G.sum <- G.sum + replace(temp, which(is.na(temp)), 0)
		G.count <- G.count + as.numeric(!is.na(temp))
	}
	G <- ifelse(G.count==0, NA,  G.sum/G.count)   

	# smooth the covariance matrix
	gw.temp <- G
	diag(gw.temp) <- rep(NA, N_obs)
	gw <- as.vector(gw.temp)
	x1 <- rep(seq(0,1,length=N_obs), N_obs)
	x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
	myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
	fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
	newdata <- data.frame(x1=x1,x2=x2) 
	pred.w <- predict(fit.w,newdata)
	s.gw <-matrix(pred.w,N_obs) 

	smoothCov <- (s.gw + t(s.gw) )/2 
	
	# construct eigen decomposition
	eigenDecomp = eigen(smoothCov)
	eigenDecomp$vectors = eigenDecomp$vectors/sqrt(by)
	eigenDecomp$values = eigenDecomp$values*by
	#############################################################
	# set the bases for the predictors and coefficient
	#############################################################

	# define the PC basis used for the predictors
	psi=eigenDecomp$vectors[1:N_obs,1:Kw]

	# set the basis to be used for gamma(t)
	phi=bs(1:N_obs, df=Kg, intercept=TRUE)

	# evaluate the J matrix using numeric integration; assumes t is observed over an even grid
	M.mat <- t(psi[,1:Kw]) %*% phi * by

	#############################################################
	# compute the matrix of PC loadings
	#############################################################
	trueC=matrix(0, nrow=dim(resd)[1], ncol=Kw)
	for(i in 1:dim(resd)[1]){
		trueC[i,] <- by * replace(resd[i,], which(is.na(resd[i,])), 0) %*% eigenDecomp$vectors[ ,1:Kw ] 
	}
}

#############################################################
# fit the model using MCMC
#############################################################

if(doMCMC){
	## data passed to WinBUGS contains the outcomes, Y, the number of 
	## subjects, I, the number of visits per subject, J, the matrix of 
	## the inner products of phi and psi, M.mat, the dimension of phi 
	## and psi, Kw and Kg, and the observed functions W

	data<-list("Y", "W", "X", "M.mat", "psi", "I", "J", "Kw", "Kg", "N_obs")

	#Define the program file
	program.file.name="Long_Func_Reg.txt"
		
	#Define the initial values
	inits.ll=rep(0.01,Kw)
	inits<-function(){list(beta=rep(0, length(trueBeta)), C=matrix(0, nrow= I*J, ncol=Kw),
		tau_eps=.1, tau_g=.1, tau_u=.1, tau_Y=.01, ll=inits.ll)}

	#Define the parameters to be monitored
	parameters=list("beta", "g", "u", "tau_u", "tau_eps", "tau_g", "tau_Y", "ll")
	
	#Define the thinning, iteration and burn-in numbers for the MCMC simulation
	n.thin=1
	n.iter=1000
	n.burnin=500

	# define some necessary paths
	setwd("~/Documents/Projects/WinBUGS")
	WINE <- "/Applications/Darwine/Wine.bundle/Contents/bin/wine"
	WINEPATH <- "/Applications/Darwine/Wine.bundle/Contents/bin/winepath"
	BUGS.DIR <- "/Applications/WinBUGS14"

	timeMCMC=proc.time()

	Bayes.fit<- bugs(data, inits, parameters, model.file = program.file.name,
         n.chains = 1, n.iter = n.iter, n.burnin = n.burnin,
         n.thin = n.thin, debug = FALSE, bugs.directory=BUGS.DIR, 
         WINEPATH=WINEPATH, WINE=WINE, working.directory=".")

	timeMCMC=proc.time()-timeMCMC

	attach.bugs(Bayes.fit)

	## Recovery of the estimated gamma function
	mean_g=apply(g,2,mean)
	gammaHatMCMC=phi%*%mean_g

	## Recovery of the estimated random intercepts
	mean_u=apply(u,2,mean)

	## Recovery of the non-functional parameters
	mean_beta=apply(beta,2,mean)

	## construction of credible interval
	gammaHats=matrix(0, nrow=dim(g)[1], ncol=length(t))
	for(i in 1:dim(g)[1]){
		gammaHats[i,]=phi%*%g[i,]
	}
	
	Bounds=sapply(1:length(t), function(u) quantile(gammaHats[,u], probs=c(.025, .975)))
	uBoundMCMC=Bounds[2, ]
	lBoundMCMC=Bounds[1, ]
}

#############################################################
# fit the model using VB
#############################################################

if(doVB){
	SigmaBeta = 100

	Ay=.1
	By=.1

	Ag=10
	Bg=.1

	Al=.1
	Bl=.1

	Ae=.1
	Be=.1

	Au=.1
	Bu=.1

	N=N_obs
	
	temp=matrix(0, nrow=Kg, ncol=Kg)
	for(i in 1:Kg){
		for(j in 1:Kg){
			temp[i,j]=min(i,j)-1
		}	
	}
	D = matrix(10, nrow=Kg, ncol=Kg)+temp
	Dinv=solve(D)
	
	Z=matrix(c(rep(1, J), rep(0, I*J)), nrow=I*J, ncol=I)

	b.q.sigma.y = 10
	b.q.sigma.g = 10
	b.q.sigma.e = 10
	b.q.sigma.l = rep(1, Kw)
	b.q.sigma.u = 10

	mu.q.beta = rep(0, dim(Z)[2])
	mu.q.g = rep(0, Kg)
	mu.q.u = rep(0, I)
	mu.q.c=matrix(0, nrow=I*J, ncol=Kw)
	
	Lam = diag((Al+I*J/2)/b.q.sigma.l[1:Kw], nrow=Kg, ncol=Kg)
	sigma.q.g = matrix(0, nrow=Kg, ncol=Kg)
	sigma.q.c = Lam
	sigma.q.beta = diag(1, length(trueBeta))

	lpxq=c(0,1)
	i=2

	timeVB=proc.time()

 	while(i<4 | (lpxq[i]-lpxq[i-1])>1.0E-2){
		sigma.q.beta = solve(((Ay+I*J/2)/b.q.sigma.y)*t(X)%*%X + diag(1/SigmaBeta, length(trueBeta)))
		mu.q.beta = as.numeric(sigma.q.beta %*% (((Ay+I*J/2)/b.q.sigma.y)*t(X)%*%(Y - mu.q.c%*%M.mat%*%mu.q.g - 			Z%*% mu.q.u)))

		sigma.q.u = solve(((Ay+I*J/2)/b.q.sigma.y)* t(Z)%*%Z + ((Au+I/2)/b.q.sigma.u)*diag(1, nrow=I, ncol=I)  )
		mu.q.u = as.numeric(sigma.q.u %*% (((Ay+I*J/2)/b.q.sigma.y) *t(Z)%*% (Y - X %*% mu.q.beta - 
			mu.q.c%*%M.mat%*%mu.q.g)))
			
		sigma.q.c = solve(((Ay+I*J/2)/b.q.sigma.y)* M.mat %*% (mu.q.g%*%t(mu.q.g) + sigma.q.g) %*% t(M.mat) 
			+ ((Ae+I*J*N/2)/b.q.sigma.e) * t(psi)%*%psi + Lam )
		mu.q.c=t(sigma.q.c %*% t(((Ay+I*J/2)/b.q.sigma.y)* Y %*% t(mu.q.g)%*%t(M.mat) 
			- ((Ay+I*J/2)/b.q.sigma.y) * X %*% mu.q.beta %*% t(mu.q.g)%*%t(M.mat) 
			- ((Ay+I*J/2)/b.q.sigma.y) * Z %*% mu.q.u %*% t(mu.q.g)%*%t(M.mat) 
			+ ((Ae+I*J*N/2)/b.q.sigma.e) * W %*% psi  ))
			
		sigma.q.g = solve(((Ay+I*J/2)/b.q.sigma.y) * t(M.mat)%*%(t(mu.q.c)%*%(mu.q.c) + 
			I * J * sigma.q.c) %*%M.mat + ((Ag+Kg/2)/b.q.sigma.g) * Dinv)
		mu.q.g = sigma.q.g %*% ( ((Ay+I*J/2)/ b.q.sigma.y) * t(M.mat)%*%t(mu.q.c)%*%(Y 
			- X %*% mu.q.beta - Z%*%mu.q.u ))
		
		for(j in 1:Kw){
			b.q.sigma.l[j] = as.numeric(Bl + .5 * (t(mu.q.c[,j]) %*% mu.q.c[,j] + I*J * sigma.q.c[j,j]   )) 
		}
		Lam=diag((Al+I*J/2)/b.q.sigma.l[1:Kw])
		b.q.sigma.e	= as.numeric(Be + .5 * (sum( (W[,]- mu.q.c[,]%*%t(psi)  )^2 ) + I*J * 
			sum(diag(t(psi)%*%psi %*%sigma.q.c   ))))
		
		b.q.sigma.u = as.numeric(Bu + .5 * (t(mu.q.u)  %*% mu.q.u + sum(diag(sigma.q.u   ))))
	
		b.q.sigma.g = as.numeric(Bg + .5 * (t(mu.q.g) %*% Dinv %*% mu.q.g + sum(diag(Dinv %*%sigma.q.g   ))))
		
		b.q.sigma.y = as.numeric(By + .5 * ( sum( (Y- X %*% mu.q.beta - mu.q.c %*% M.mat %*% mu.q.g - Z%*%mu.q.u )^2 ) 
			+ sum(diag(t(X)%*%X%*%sigma.q.beta)) + sum(diag(t(Z)%*%Z%*%sigma.q.u))
			- t(mu.q.c%*%M.mat%*%mu.q.g) %*% (mu.q.c%*%M.mat%*%mu.q.g)
			+ t(mu.q.g)%*%t(M.mat)%*% (t(mu.q.c)%*%mu.q.c + I*J *sigma.q.c   ) %*% M.mat %*% mu.q.g
			+ sum(diag( t(M.mat)%*%( t(mu.q.c)%*%mu.q.c + I*J *sigma.q.c ) %*% M.mat %*% sigma.q.g           )) ))
			
		curlpxq = - (I*J/2)*log(2*pi) - (I*J*N/2)*log(2*pi) +
			.5*log(det(sigma.q.beta)*det(diag(1/SigmaBeta,2))) -
			(t(mu.q.beta)%*%mu.q.beta - det(sigma.q.beta))/(2)*det(diag(1/SigmaBeta,2)) + (1/2) +
			.5*log(det(sigma.q.g)) + .5*Kg +
			.5*log(det(sigma.q.u)) + .5*I +
			(I*J/2) * sum(log(diag(sigma.q.c))) + (I*J*Kw/2) +
			Ag*log(Bg) - log(gamma(Ag)) - (Ag + (Kg/2))*log(b.q.sigma.g) +
			Ay*log(By) - log(gamma(Ay)) - (Ay + (I*J/2))*log(b.q.sigma.y) +
			Ae*log(Be) - log(gamma(Ae)) - (Ae + (I*J*N/2))*log(b.q.sigma.e) +
			Au*log(Bu) - log(gamma(Au)) - (Au + (I/2))*log(b.q.sigma.u) +
			Kw*(Al*log(Bl) - log(gamma(Al)) + log(gamma(Al+(I*J/2)))) - (Al + (I*J/2))*sum(log(b.q.sigma.l))
	
		lpxq = c(lpxq, curlpxq)
		i=i+1
	}

	timeVB=proc.time()-timeVB

	lpxq=lpxq[-(1:2)]
	gammaHatVB=phi%*%mu.q.g
	
	varVB=rep(0, N_obs)
	for(i in 1:N_obs){
		var=diag(sigma.q.g)%*%(phi[i,]^2)
		cov=0
		for(i2 in 2:Kw){
			for(j2 in 1:(i2-1)){
				cov=cov+2*phi[i,i2]*phi[i,j2]*sigma.q.g[i2, j2]
			}
		}
		varVB[i]=var+cov
	}
	uBoundVB=gammaHatVB+1.96*sqrt(varVB)
	lBoundVB=gammaHatVB-1.96*sqrt(varVB)
}

#############################################################
# make a plot of the gammaHat funcs
#############################################################

if(doPlotGamma){
	quartz()
	plot(t, trueGamma, type='l')
	if(doMCMC){
		points(t, gammaHatMCMC, type='l', col='red')
		points(t, uBoundMCMC, type='l', lty=2, col="red")
		points(t, lBoundMCMC, type='l', lty=2, col="red")
	}
	if(doVB){
		points(t, gammaHatVB, type='l', col='blue')
		points(t, uBoundVB, type='l', lty=2, col='blue')
		points(t, lBoundVB, type='l', lty=2, col='blue')
	}
}

#############################################################
# make a plot comparing posterior densities
#############################################################

if(doVBvsMCMC){
	quartz(height=6, width=11)
	par(mfrow=c(2,5), mai=rep(.3,4))
	for(i in 1:10){
		dens=density(g[,i])
		plot(dens, xlab="", ylab="", main="")
		points(dens$x, dnorm(dens$x, mean=mu.q.g[i], sd=sqrt(sigma.q.g[i,i])), type='l', col="orange")
	}
	
	quartz()
	par(mfrow=c(1,4), mai=rep(.3,4))
	dens=density(tau_u)
	plot(dens)
		points(dens$x, dgamma(dens$x, shape=Au+I/2, rate=b.q.sigma.u), type='l', col="orange")
	
	dens=density(tau_Y)
	plot(dens)
		points(dens$x, dgamma(dens$x, shape=Ay+I*J/2, rate=b.q.sigma.y), type='l', col="orange")

	dens=density(tau_g)
	plot(dens)
		points(dens$x, dgamma(dens$x, shape=Ag+Kg/2, rate=b.q.sigma.g), type='l', col="orange")

	dens=density(tau_eps)
	plot(dens)
		points(dens$x, dgamma(dens$x, shape=Ae+I*J*N_obs/2, rate=b.q.sigma.e), type='l', col="orange")
}
