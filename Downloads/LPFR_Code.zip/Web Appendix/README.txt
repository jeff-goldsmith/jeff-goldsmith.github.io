README: Web Supplement for "Longitudinal Penalized Functional Regression for Cognitive Outcomes on Neuronal Tract Measurements"

This zip folder contains all code used in the simulations for this paper. Code is divided into three folders: Examples, Simulations, and WinBUGS Files.

The Examples folder contains code that will generate individual datasets and fit the longitudinal functional regression model using the methods developed in the paper. There are four files, two using a likelihood-based approach and two using a Bayesian approach; each approach has separate files for single functional predictors and multiple functional predictors. The Example files are the most useful for understanding the implementations of the method.

The Simulations folder contains code that generates many datasets, fits the models using the likelihood or Bayesian approach, and saves all output needed to populate the Tables appearing in the paper.

Finally, the WinBUGS Files folder contains the WinBUGS model files for single and multiple functional predictors. Note that in the R files using the Bayesian approach, the correct path to these files must be specified.