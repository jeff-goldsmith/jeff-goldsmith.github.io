
#############################################################
# April 21 2010
# Jeff Goldsmith with code from Chongzhi Di
#
# this file implements the longitudinal penalized functional
# regression method. random functions are generated in two ways:
# either as sharing a subject-specific mean with subject-visit
# specific deviations, or as exchangeable draws from a common
# distribution.
#
# we include a second fitting method based on MFPCA that fits
# random intercepts as a subject-specific functional effect
# on the subject specific mean
#############################################################

rm(list=ls())

library(nlme)
library(SemiPar)
library(splines)
library(R2WinBUGS)

setwd("~/Documents/Projects/WinBUGS")

###     Set the seed for simulation
set.seed(1320)

I=100  			# sample size
J = 3					# number of visits
VarX=.5					# measurement error variance
vareps=10				# variance on the outcome
VarRanEf = 5
tlength = 10

## set the standard parameters
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

Kw=10

Kg=min(Kw, 35)
smoothCov <- FALSE	# whether to smooth the covariance matrix


#############################################################
# there are two methods to generate the observed functions.
# the first assumes that there is a true subject mean function
# and adds visit-specific deviations around them. the second
# assumes that the subject's functions are independent draws
# from the distribution of functions.
#############################################################

#############################################################
# first method
#############################################################

funcs <- matrix(0, nrow=I*J, ncol=length(t))

## generate true subject-specific mean functions
mean.funcs <- matrix(0, nrow=I, ncol=length(t))
for(i2 in 1:I){
	mean.funcs[i2,]=mean.funcs[i2,]+runif(1, 0, 5)
	mean.funcs[i2,]=mean.funcs[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:2){
		e=rnorm(2, 0, 1/j2^(2))
		mean.funcs[i2,]=mean.funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
		mean.funcs[i2,]=mean.funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}


# Calculate the observedfunctions as the sum of subject's function
# the level 2 eigenfunctions (noise is also added)
deviations <- matrix(0,nrow=I*J,ncol=N_obs)
for(i2 in 1:(I*J)){
 	for(j2 in 3:6){
		e=rnorm(2, 0, .25)
		deviations[i2,]=deviations[i2,]+e[1]*sin((2*pi/10)*t*j2)
		deviations[i2,]=deviations[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}

for(m in 1:I) {
    temp <- mean.funcs[m,]
    for(l in 1:J) {
        funcs[ (m-1)*J + l ,] <- temp + deviations[ (m-1)*J + l ,]
    }
}


#############################################################
# second method
#############################################################


## generate observed functions
funcs <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs[i2,]=funcs[i2,]+runif(1, 0, 5)
	funcs[i2,]=funcs[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs[i2,]=funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs[i2,]=funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}




#############################################################
# from here, the procedure is the same for either function 
# generation method
#############################################################

W = funcs + rnorm(I*J*N_obs, sd=sqrt(VarX))

## select true beta functions
trueGamma = 2*sin(t*pi/5)
#trueGamma = sqrt(t)

## generate random effects: subject specific intercepts
ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)

## generate outcomes from true Beta function and functions measured without error
Y <- sapply(1:(I*J), function(u) sum(funcs[u,]*trueGamma)*by+ranef[u])+rnorm(I*J, 0, sqrt(vareps))


meanFunc=apply(W, 2, mean, na.rm=TRUE)
resd=sapply(1:length(t), function(u) W[,u]-meanFunc[u])
W=resd

# construct and smooth covariance matrices
G.sum <- matrix(0, N_obs, N_obs)
G.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd)[1]){
    row.ind=i
    temp=resd[row.ind, ] %*% t( resd[row.ind, ])
	G.sum <- G.sum + replace(temp, which(is.na(temp)), 0)
	G.count <- G.count + as.numeric(!is.na(temp))
}
G <- ifelse(G.count==0, NA,  G.sum/G.count)   

gw.temp <- G
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp = eigen(smoothCov)
eigenDecomp$vectors = eigenDecomp$vectors/sqrt(by)

# define the PC basis used for the predictors
psi=eigenDecomp$vectors[1:N_obs,1:Kw]

# set the basis to be used for gamma(t)
phi=bs(1:N_obs, df=Kg, intercept=TRUE)

# evaluate the M matrix using numeric integration; assumes t is observed over an even grid
M.mat <- t(psi[,1:Kw]) %*% phi * by

## calculate the A matrix: the projection of the functions
## onto the FPC basis. this is used to dramatically speed
## computation time.
A = matrix(0, I*J, Kw) 
for(i in 1:(I*J))   {
	for(j in 1:Kw) {
		A[ i ,j] <- sum( W[i,] * psi[,j] ) * by   
	}
}

## data passed to WinBUGS contains the outcomes, Y, the number of 
## subjects, I, the number of visits per subject, M, the matrix of 
## the inner products of phi and psi, M.mat, the dimension of phi 
## and psi, Kw and Kg, and the projection matrix A

data<-list("Y", "I", "J", "M.mat", "Kw", "Kg", "A")

#Define the program file
program.file.name="LPFR.txt"

#Define the initial values
inits.ll=rep(0.01,Kw)
inits<-function(){list(alpha=0, C=matrix(0, nrow= I*J, ncol=Kw),
	tau_g=.1, tau_b=.01, tau_Y=.01, ll=inits.ll)}

#Define the parameters to be monitored
parameters=list("alpha", "g", "tau_Y")

#Define the thinning, iteration and burn-in numbers for the MCMC simulation
n.thin=1
n.iter=700
n.burnin=300

# define some necessary paths
setwd("~/Documents/Projects/WinBUGS")
WINE <- "/Applications/Darwine/Wine.bundle/Contents/bin/wine"
WINEPATH <- "/Applications/Darwine/Wine.bundle/Contents/bin/winepath"
BUGS.DIR <- "/Applications/WinBUGS14"

Bayes.fit<- bugs(data, inits, parameters, model.file = program.file.name,
         n.chains = 1, n.iter = n.iter, n.burnin = n.burnin,
         n.thin = n.thin, debug = TRUE, bugs.directory=BUGS.DIR, 
         WINEPATH=WINEPATH, WINE=WINE, working.directory=".")

attach.bugs(Bayes.fit)


## Recovery of the estimated gamma function
mean_g=apply(g,2,mean)
gammaHat=phi%*%mean_g

## construction of credible interval
gammaHats=matrix(0, nrow=dim(g)[1], ncol=length(t))
for(i in 1:dim(g)[1]){
	gammaHats[i,]=phi%*%g[i,]
}

Bounds=sapply(1:length(t), function(u) quantile(gammaHats[,u], probs=c(.025, .975)))


quartz()
plot(t, gammaHat, type='l', col='red')
points(t, trueGamma, type='l')
points(t,Bounds[1,], type='l', lty=2, col="red")
points(t,Bounds[2,], type='l', lty=2, col="red")



