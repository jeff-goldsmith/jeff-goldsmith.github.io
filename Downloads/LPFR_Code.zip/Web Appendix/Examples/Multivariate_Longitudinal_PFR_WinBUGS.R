
#############################################################
# April 27 2010 - from australia
# Jeff Goldsmith
#
# this file implements the longitudinal penalized functional
# regression method with multiple functional covariates.
#
# note: there's an interesting issue with J, Kw and Kg. it 
# seems you can't have J=10 and Kw=Kg=10. so i've set Kw=Kg=11
#############################################################


rm(list=ls())
PlotFuncs=FALSE

library(nlme)
library(SemiPar)
library(splines)
library(R2WinBUGS)

setwd("~/Documents/Projects/WinBUGS")

###     Set the seed for simulation
set.seed(1500)

I = 100					# number of subjects
J = 10					# number of visits
VarEps = .5				# measurement error variance
VarY = 10				# variance on the outcome
VarRanEf = 5
tlength = 10

## set the standard parameters
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

Kw=Kg=11

## select true gamma functions
trueGamma1 = 2*sin(t*pi/5)
trueGamma2 = sqrt(t)

#############################################################
# generate functions
#############################################################

funcs1 <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs1[i2,]=funcs1[i2,]+runif(1, 0, 5)
	funcs1[i2,]=funcs1[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs1[i2,]=funcs1[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs1[i2,]=funcs1[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}

funcs2 <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs2[i2,]=funcs2[i2,]+runif(1, 0, 5)
	funcs2[i2,]=funcs2[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs2[i2,]=funcs2[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs2[i2,]=funcs2[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}


#############################################################
# generate observed functions, set true coefficient functions,
# generate random effects and calculate outcomes
#############################################################

W1 = funcs1 + rnorm(I*J*N_obs, sd=sqrt(VarEps))
W2 = funcs2 + rnorm(I*J*N_obs, sd=sqrt(VarEps))

## generate random effects: subject specific intercepts
ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)

## generate outcomes from true gamma function and functions measured without error
Y <- sapply(1:(I*J), function(u) sum(funcs1[u,]*trueGamma1)*by+sum(funcs2[u,]*trueGamma2)*by
		+ranef[u])+rnorm(I*J, 0, sqrt(VarY))


#############################################################
# generate observed functions, set true coefficient functions,
# generate random effects and calculate outcomes
#############################################################

# first functions
meanFunc1=apply(W1, 2, mean, na.rm=TRUE)
resd1=sapply(1:length(t), function(u) W1[,u]-meanFunc1[u])
W1=resd1

# construct and smooth covariance matrices
G1.sum <- matrix(0, N_obs, N_obs)
G1.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd1)[1]){
    row.ind=i
    temp=resd1[row.ind, ] %*% t( resd1[row.ind, ])
	G1.sum <- G1.sum + replace(temp, which(is.na(temp)), 0)
	G1.count <- G1.count + as.numeric(!is.na(temp))
}
G1 <- ifelse(G1.count==0, NA,  G1.sum/G1.count)   

gw.temp <- G1
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp1 = eigen(smoothCov)
eigenDecomp1$vectors = eigenDecomp1$vectors/sqrt(by)

# define the PC basis used for the predictors
psi1=eigenDecomp1$vectors[,1:Kw]

# estimate the PC loadings using numeric integration:
C1=matrix(0, nrow=dim(resd1)[1], ncol=Kw)

for(i in 1:dim(resd1)[1]){
	C1[i,] <- by * replace(resd1[i,], which(is.na(resd1[i,])), 0) %*% eigenDecomp1$vectors[ ,1:Kw ] 
}



# second functions
meanFunc2=apply(W2, 2, mean, na.rm=TRUE)
resd2=sapply(1:length(t), function(u) W2[,u]-meanFunc2[u])
W2=resd2

# construct and smooth covariance matrices
G2.sum <- matrix(0, N_obs, N_obs)
G2.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd2)[1]){
    row.ind=i
    temp=resd2[row.ind, ] %*% t( resd2[row.ind, ])
	G2.sum <- G2.sum + replace(temp, which(is.na(temp)), 0)
	G2.count <- G2.count + as.numeric(!is.na(temp))
}
G2 <- ifelse(G2.count==0, NA,  G2.sum/G2.count)   

gw.temp <- G2
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp2 = eigen(smoothCov)
eigenDecomp2$vectors = eigenDecomp2$vectors/sqrt(by)

# define the PC basis used for the predictors
psi2=eigenDecomp2$vectors[,1:Kw]

# estimate the PC loadings using numeric integration:
C2=matrix(0, nrow=dim(resd2)[1], ncol=Kw)

for(i in 1:dim(resd2)[1]){
	C2[i,] <- by * replace(resd2[i,], which(is.na(resd2[i,])), 0) %*% eigenDecomp2$vectors[ ,1:Kw ] 
}


#############################################################
# make a plot that shows a subjects observed, true, and estimated
# functions.
#############################################################

if(PlotFuncs){
	dev.new()
	par(mfrow=c(J,2), mai=rep(0, 4))
	for(i in 1:(2*J)){
		plot(t, meanFunc1+W1[i,], type='l', col='blue', xlab="", ylab="")
		points(t, funcs1[i,], type='l', col='red')
		points(t,meanFunc1+C1[i,]%*%t(eigenDecomp1$vectors[,1:Kw]), type='l')
	}
}


#############################################################
# set the basis for the coefficient functions
#############################################################

# set the basis to be used for gamma(t)
phi=bs(1:N_obs, df=Kg, intercept=TRUE)


#############################################################
# compute the M matrices
#############################################################

M1.mat <- t(psi1) %*% phi *(max(t) - min(t))/(length(t)-1)
M2.mat <- t(psi2) %*% phi *(max(t) - min(t))/(length(t)-1)



#############################################################
# define the projection matrices; these are used to dramatically
# speed up computation time
#############################################################

A1 = matrix(0, I*J, Kw) 
A2 = matrix(0, I*J, Kw) 
for(i in 1:(I*J))   {
	for(j in 1:Kw) {
		A1[ i ,j] <- sum( W1[i,] * psi1[,j] ) * by
		A2[ i ,j] <- sum( W2[i,] * psi2[,j] ) * by   
	}
}


#############################################################
# set up and fit the model
#############################################################

## data passed to WinBUGS contains the outcomes, Y, the number of 
## subjects, I, the number of visits per subject, J, the matrix of 
## the inner products of phi and psi, J.mat, the dimension of phi 
## and psi, Kw and Kg, and the projection matrix A

data<-list("Y", "I", "J", "M1.mat", "M2.mat", "Kw", "Kg", "A1", "A2")

#Define the program file
program.file.name="Multivariate_LPFR.txt"

#Define the initial values
inits.ll1=rep(0.01,Kw)
inits.ll2=rep(0.01,Kw)
inits<-function(){list(alpha=0, C1=matrix(0, nrow= I*J, ncol=Kw), C2=matrix(0, nrow= I*J, ncol=Kw),
	tau_g1=.1, tau_g2=.1, tau_b=.01, tau_Y=.01, ll1=inits.ll1, ll2=inits.ll2)}

#Define the parameters to be monitored
parameters=list("alpha", "g1", "g2", "tau_Y")

#Define the thinning, iteration and burn-in numbers for the MCMC simulation
n.thin=1
n.iter=1000
n.burnin=500

ptm=proc.time()
# define some necessary paths
setwd("~/Documents/Projects/WinBUGS")
WINE <- "/Applications/Darwine/Wine.bundle/Contents/bin/wine"
WINEPATH <- "/Applications/Darwine/Wine.bundle/Contents/bin/winepath"
BUGS.DIR <- "/Applications/WinBUGS14"

Bayes.fit<- bugs(data, inits, parameters, model.file = program.file.name,
         n.chains = 1, n.iter = n.iter, n.burnin = n.burnin,
         n.thin = n.thin, debug = TRUE, bugs.directory=BUGS.DIR, 
         WINEPATH=WINEPATH, WINE=WINE, working.directory=".")

attach.bugs(Bayes.fit)
time=proc.time()-ptm

## Recovery of the estimated gamma function
mean_g1=apply(g1,2,mean)
gamma1Hat=phi%*%mean_g1

mean_g2=apply(g2,2,mean)
gamma2Hat=phi%*%mean_g2

## construction of credible interval
gamma1Hats=matrix(0, nrow=dim(g1)[1], ncol=length(t))
for(i in 1:dim(g1)[1]){
	gamma1Hats[i,]=phi%*%g1[i,]
}

Bounds1=sapply(1:length(t), function(u) quantile(gamma1Hats[,u], probs=c(.025, .975)))

## construction of credible interval
gamma2Hats=matrix(0, nrow=dim(g2)[1], ncol=length(t))
for(i in 1:dim(g2)[1]){
	gamma2Hats[i,]=phi%*%g2[i,]
}

Bounds2=sapply(1:length(t), function(u) quantile(gamma2Hats[,u], probs=c(.025, .975)))



quartz()
par(mfrow=c(1,2))
plot(t, gamma1Hat, type='l', col='red')
points(t, trueGamma1, type='l')
points(t,Bounds1[1,], type='l', lty=2, col="red")
points(t,Bounds1[2,], type='l', lty=2, col="red")

plot(t, gamma2Hat, type='l', col='red')
points(t, trueGamma2, type='l')
points(t,Bounds2[1,], type='l', lty=2, col="red")
points(t,Bounds2[2,], type='l', lty=2, col="red")


