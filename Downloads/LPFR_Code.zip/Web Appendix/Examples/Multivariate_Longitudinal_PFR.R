
#############################################################
# April 27 2010 - from australia
# Jeff Goldsmith
#
# this file implements the longitudinal penalized functional
# regression method with multiple functional covariates.
#############################################################

rm(list=ls())
PlotFuncs=TRUE

library(nlme)
library(SemiPar)
library(splines)
library(R2WinBUGS)

###     Set the seed for simulation
set.seed(1000)

I=100  					# number of subjects
J = 3					# number of visits
VarX = .5				# measurement error variance
vareps = 10				# variance on the outcome
VarRanEf = 50
tlength = 10

## set the standard parameters
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

Kw=20

Kg=min(Kw, 35)


#############################################################
# generate functions
#############################################################

funcs1 <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs1[i2,]=funcs1[i2,]+runif(1, 0, 5)
	funcs1[i2,]=funcs1[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs1[i2,]=funcs1[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs1[i2,]=funcs1[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}

funcs2 <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs2[i2,]=funcs2[i2,]+runif(1, 0, 5)
	funcs2[i2,]=funcs2[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs2[i2,]=funcs2[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs2[i2,]=funcs2[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}


#############################################################
# generate observed functions, set true coefficient functions,
# generate random effects and calculate outcomes
#############################################################

W1 = funcs1 + rnorm(I*J*N_obs, sd=sqrt(VarX))
W2 = funcs2 + rnorm(I*J*N_obs, sd=sqrt(VarX))

## select true gamma functions
trueGamma1 = 2*sin(t*pi/5)
trueGamma2 = sqrt(t)

## generate random effects: subject specific intercepts
ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)

## generate outcomes from true gamma function and functions measured without error
Y <- sapply(1:(I*J), function(u) sum(funcs1[u,]*trueGamma1)*by+sum(funcs2[u,]*trueGamma2)*by
		+ranef[u])+rnorm(I*J, 0, sqrt(vareps))


#############################################################
# generate observed functions, set true coefficient functions,
# generate random effects and calculate outcomes
#############################################################

# first functions
meanFunc1=apply(W1, 2, mean, na.rm=TRUE)
resd1=sapply(1:length(t), function(u) W1[,u]-meanFunc1[u])
W1=resd1

# construct and smooth covariance matrices
G1.sum <- matrix(0, N_obs, N_obs)
G1.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd1)[1]){
    row.ind=i
    temp=resd1[row.ind, ] %*% t( resd1[row.ind, ])
	G1.sum <- G1.sum + replace(temp, which(is.na(temp)), 0)
	G1.count <- G1.count + as.numeric(!is.na(temp))
}
G1 <- ifelse(G1.count==0, NA,  G1.sum/G1.count)   

gw.temp <- G1
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp1 = eigen(smoothCov)
eigenDecomp1$vectors = eigenDecomp1$vectors/sqrt(by)

# define the PC basis used for the predictors
psi1=eigenDecomp1$vectors[,1:Kw]

# estimate the PC loadings using numeric integration:
C1=matrix(0, nrow=dim(resd1)[1], ncol=Kw)

for(i in 1:dim(resd1)[1]){
	C1[i,] <- by * replace(resd1[i,], which(is.na(resd1[i,])), 0) %*% eigenDecomp1$vectors[ ,1:Kw ] 
}



# second functions
meanFunc2=apply(W2, 2, mean, na.rm=TRUE)
resd2=sapply(1:length(t), function(u) W2[,u]-meanFunc2[u])
W2=resd2

# construct and smooth covariance matrices
G2.sum <- matrix(0, N_obs, N_obs)
G2.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd2)[1]){
    row.ind=i
    temp=resd2[row.ind, ] %*% t( resd2[row.ind, ])
	G2.sum <- G2.sum + replace(temp, which(is.na(temp)), 0)
	G2.count <- G2.count + as.numeric(!is.na(temp))
}
G2 <- ifelse(G2.count==0, NA,  G2.sum/G2.count)   

gw.temp <- G2
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp2 = eigen(smoothCov)
eigenDecomp2$vectors = eigenDecomp2$vectors/sqrt(by)

# define the PC basis used for the predictors
psi2=eigenDecomp2$vectors[,1:Kw]

# estimate the PC loadings using numeric integration:
C2=matrix(0, nrow=dim(resd2)[1], ncol=Kw)

for(i in 1:dim(resd2)[1]){
	C2[i,] <- by * replace(resd2[i,], which(is.na(resd2[i,])), 0) %*% eigenDecomp2$vectors[ ,1:Kw ] 
}


#############################################################
# make a plot that shows a subjects observed, true, and estimated
# functions.
#############################################################

if(PlotFuncs){
	dev.new()
	par(mfrow=c(J,2), mai=rep(0, 4))
	for(i in 1:(2*J)){
		plot(t, meanFunc1+W1[i,], type='l', col='blue', xlab="", ylab="")
		points(t, funcs1[i,], type='l', col='red')
		points(t,meanFunc1+C1[i,]%*%t(eigenDecomp1$vectors[,1:Kw]), type='l')
	}
}


#############################################################
# set the basis for the coefficient functions
#############################################################

# set the basis to be used for gamma(t)
num=Kg-2
qtiles <- seq(0, 1, length = num + 2)[-c(1, num + 2)]
knots <- quantile(t, qtiles)
phi = cbind(rep(1, length(t)), t, sapply(knots, function(k) ((t - k > 0) * (t - k)) ))


#############################################################
# compute the J and CJ matrices
#############################################################

J1.mat <- t(psi1) %*% phi *(max(t) - min(t))/(length(t)-1)
CJ1 <- C1[,1:Kw] %*% J1.mat


J2.mat <- t(psi2) %*% phi *(max(t) - min(t))/(length(t)-1)
CJ2 <- C2[,1:Kw] %*% J2.mat


#############################################################
# construct the design matrices for the lme function
#############################################################

X=cbind(1, CJ1[,1:2], CJ2[,1:2])

Z1=matrix(rep(c(rep(1, J), rep(0, I*J)), I), nrow=length(Y), ncol=I)
Z2=as.matrix(CJ1[,3:Kw])
Z3=as.matrix(CJ2[,3:Kw])
Z=cbind(Z1, Z2, Z3)

# give the columns of the design matrices meaningful names
colnames(X)=c("intercept", "1.1", "1.t", "2.1", "2.t")
colnames(Z)=c(paste("int.",1:dim(Z1)[2], sep=""), paste("gamma1.",3:Kg,sep="" ), 
	paste("gamma2.",3:Kg,sep="" ))

# the following code organizes the inputs for the lme() function
re.block.inds=list(1:dim(Z1)[2], (dim(Z1)[2]+1):(dim(Z1)[2]+dim(Z2)[2]), 
	(dim(Z1)[2]+dim(Z2)[2]+1):(dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2]))
Z.block=list(length=3)
for (i in 1:length(re.block.inds)) 
	Z.block[[i]] <- as.formula(paste("~Z[,c(",paste( re.block.inds[[i]],collapse=","),")]-1"))
group=rep(1, I*J)
grouped=data.frame(X,Y,Z)
model.data=groupedData(Y~X|group, data=grouped)


#############################################################
# fit the model; get the parameter estimates and confidence
# intervals
#############################################################

# fit the longitudinal functional regression model
fit.smooth=lme(Y~-1+X, random=list(group=pdBlocked(Z.block, 
	pdClass=rep("pdIdent",length(Z.block)))))

# get the coefficient and gammaHat estimates
coefs <- c(fit.smooth$coef$fixed,unlist(fit.smooth$coef$random))

# obtain fitted values
w <- cbind(1, CJ1[,1:2], CJ2[,1:2], Z1, CJ1[,3:dim(CJ1)[2]], CJ2[,3:dim(CJ2)[2]])
fitted <- as.matrix(w[,1:length(coefs)]) %*% coefs

# obtain estimates of the functional coefficients
gamma1Hat <- phi %*% c(coefs[c(2:3, (6+dim(Z1)[2]):(5+dim(Z1)[2]+dim(Z2)[2] ))])
gamma2Hat <- phi %*% c(coefs[c(4:5, (6+dim(Z1)[2]+dim(Z2)[2]):(5+dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2] ))])

# to find estimates of the confidence intervals, we need to have the
# penalty matrix used in the mixed model formulation
lambda1 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[1,1])
lambda2 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z1)[2]+1,1])
lambda3 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z1)[2]+dim(Z2)[2]+1,1])
D=diag(c(rep(0,ncol(X)), rep(lambda1, ncol(Z1)), rep(lambda2, ncol(Z2)), rep(lambda3, ncol(Z3))))
sigmaEpsHat=(fit.smooth$sigma)^2

# from there we construct the full covariance matrix of all parameters
# and random effects
VarMat=solve(t(w)%*% solve(diag((fit.smooth$sigma)^2, I*J)) %*% w + D)

# next, for each gamma function, we use only the parts of the covariance matrix 
# pertinent to that function. this is done by excluding non-pertinent rows and columns
VarGam1=VarMat[-c(1, 4, 5, 6:(5+dim(Z1)[2]), (6+dim(Z1)[2]+dim(Z2)[2]):(5+dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2])),
		-c(1, 4, 5, 6:(5+dim(Z1)[2]), (6+dim(Z1)[2]+dim(Z2)[2]):(5+dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2]))]
VarGam2=VarMat[-c(1, 2, 3, 6:(5+dim(Z1)[2]+dim(Z2)[2])),
		-c(1, 2, 3, 6:(5+dim(Z1)[2]+dim(Z2)[2]))]

# the we construct the confidence bands
VarGamHat1=phi%*%VarGam1%*%t(phi)
VarGamHat2=phi%*%VarGam2%*%t(phi)

lBound1=gamma1Hat - 1.96*sqrt(diag(VarGamHat1))
uBound1=gamma1Hat + 1.96*sqrt(diag(VarGamHat1))

lBound2=gamma2Hat - 1.96*sqrt(diag(VarGamHat2))
uBound2=gamma2Hat + 1.96*sqrt(diag(VarGamHat2))


#############################################################
# plot the results: the coefficients (and CIs), as well as the
# estimated random effects
#############################################################

dev.new()
par(mfrow=c(1,3))
plot(t, gamma1Hat, type='l', col='red')
points(t, uBound1, type='l', col='red', lty=2)
points(t, lBound1, type='l', col='red', lty=2)
points(t, trueGamma1, type='l')

plot(t, gamma2Hat, type='l', col='red')
points(t, uBound2, type='l', col='red', lty=2)
points(t, lBound2, type='l', col='red', lty=2)
points(t, trueGamma2, type='l')

plot(ranef[J*(1:100)], coefs[6:(5+I)])





