
#############################################################
# April 21 2010
# Jeff Goldsmith
#
# this file implements the longitudinal penalized functional
# regression method. random functions are generated in two ways:
# either as sharing a subject-specific mean with subject-visit
# specific deviations, or as exchangeable draws from a common
# distribution.
#############################################################


library(nlme)
library(SemiPar)
library(splines)
library(R2WinBUGS)

###     Set the seed for simulation
set.seed(1005)

I=100  					# number of subjects
J = 3					# number of visits
VarX = .5				# measurement error variance
vareps = 10				# variance on the outcome
VarRanEf = 50
tlength = 10

## set the standard parameters
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

Kw=20

Kg=min(Kw, 35)


#############################################################
# there are two methods to generate the observed functions.
# the first assumes that there is a true subject mean function
# and adds visit-specific deviations around them. the second
# assumes that the subject's functions are independent draws
# from the distribution of functions.
#############################################################

#############################################################
# first method
#############################################################

funcs <- matrix(0, nrow=I*J, ncol=length(t))

## generate true subject-specific mean functions
mean.funcs <- matrix(0, nrow=I, ncol=length(t))
for(i2 in 1:I){
	mean.funcs[i2,]=mean.funcs[i2,]+runif(1, 0, 5)
	mean.funcs[i2,]=mean.funcs[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:2){
		e=rnorm(2, 0, 1/j2^(2))
		mean.funcs[i2,]=mean.funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
		mean.funcs[i2,]=mean.funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}


# Calculate the observedfunctions as the sum of subject's function
# the level 2 eigenfunctions (noise is also added)
deviations <- matrix(0,nrow=I*J,ncol=N_obs)
for(i2 in 1:(I*J)){
 	for(j2 in 3:6){
		e=rnorm(2, 0, .25)
		deviations[i2,]=deviations[i2,]+e[1]*sin((2*pi/10)*t*j2)
		deviations[i2,]=deviations[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}

for(m in 1:I) {
    temp <- mean.funcs[m,]
    for(l in 1:J) {
        funcs[ (m-1)*J + l ,] <- temp + deviations[ (m-1)*J + l ,]
    }
}


#############################################################
# second method
#############################################################


## generate true subject-specific mean functions
funcs <- matrix(0, nrow=I*J, ncol=N_obs)
for(i2 in 1:(I*J)){
	funcs[i2,]=funcs[i2,]+runif(1, 0, 5)
	funcs[i2,]=funcs[i2,]+rnorm(1, 1, 0.2)*t
 	for(j2 in 1:10){
		e=rnorm(2, 0, 1/j2^(2))
		funcs[i2,]=funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
		funcs[i2,]=funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
	}
}




#############################################################
# from here, the procedure is the same for either function 
# generation method
#############################################################

W = funcs + rnorm(I*J*N_obs, sd=sqrt(VarX))

## select true gamma functions
trueGamma = 2*sin(t*pi/5)
#trueGamma = sqrt(t)
#trueGamma = (t/2.5)^2

## generate random effects: subject specific intercepts
ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)

## generate outcomes from true gamma function and functions measured without error
Y <- sapply(1:(I*J), function(u) sum(funcs[u,]*trueGamma)*by+ranef[u])+rnorm(I*J, 0, sqrt(vareps))
quartz()
plot(Y)

meanFunc=apply(W, 2, mean, na.rm=TRUE)
resd=sapply(1:length(t), function(u) W[,u]-meanFunc[u])
W=resd

# construct and smooth covariance matrices
G.sum <- matrix(0, N_obs, N_obs)
G.count <- matrix(0, N_obs, N_obs)

for(i in 1:dim(resd)[1]){
    row.ind=i
    temp=resd[row.ind, ] %*% t( resd[row.ind, ])
	G.sum <- G.sum + replace(temp, which(is.na(temp)), 0)
	G.count <- G.count + as.numeric(!is.na(temp))
}
G <- ifelse(G.count==0, NA,  G.sum/G.count)   

gw.temp <- G
diag(gw.temp) <- rep(NA, N_obs)
gw <- as.vector(gw.temp)
x1 <- rep(seq(0,1,length=N_obs), N_obs)
x2 <- rep(seq(0,1,length=N_obs), each=N_obs)   
# myknots <- data.frame(x1=rep(seq(0,1,length=7)[2:6],5), x2=rep(seq(0,1,length=7)[2:6],each=5) )
# NOTE it looks like when sigma_epsilon is small, sometimes the above knots give error code and
# the knots below work without any problem (other times is the other way around)  
myknots <- data.frame(x1=rep(seq(0,1,length=5),5), x2=rep(seq(0,1,length=5),each=5)   ) 
fit.w <- spm(gw ~ f(x1, x2, knots = myknots),omit.missing=TRUE)         
newdata <- data.frame(x1=x1,x2=x2) 
pred.w <- predict(fit.w,newdata)
s.gw <-matrix(pred.w,N_obs) 

smoothCov <- (s.gw + t(s.gw) )/2 
eigenDecomp = eigen(smoothCov)
eigenDecomp$vectors = eigenDecomp$vectors/sqrt(by)

# define the PC basis used for the predictors
psi=eigenDecomp$vectors[,1:Kw]

# estimate the PC loadings using numeric integration:
C=matrix(0, nrow=dim(resd)[1], ncol=Kw)

for(i in 1:dim(resd)[1]){
	C[i,] <- by * replace(resd[i,], which(is.na(resd[i,])), 0) %*% eigenDecomp$vectors[ ,1:Kw ] 
}


# make a plot to compare the estimated functions to the
# observed functions
PLOT1=TRUE
if(PLOT1){
	quartz()
	par(mfrow=c(2,4))
	for(i in 1:8){
		plot(t,meanFunc+C[i,]%*%t(eigenDecomp$vectors[,1:Kw]), type='l')
		points(t, funcs[i,], type='l', col='red')
	}
}


# set the basis to be used for gamma(t)
num=Kg-2
qtiles <- seq(0, 1, length = num + 2)[-c(1, num + 2)]
knots <- quantile(t, qtiles)
phi = cbind(rep(1, length(t)), t, sapply(knots, function(k) ((t - k > 0) * (t - k)) ))

# evaluate the J matrix using numeric integration; assumes t is observed over an even grid
J.mat <- t(psi) %*% phi *(max(t) - min(t))/(length(t)-1)

# compute the CJ matrix
CJ <- C[,1:Kw] %*% J.mat

# the following code creates the design matrices so that
# the lme function performs the correct estimation
X=cbind(1, CJ[,1:2])

Z1=matrix(rep(c(rep(1, J), rep(0, I*J)), I), nrow=length(Y), ncol=I)
Z2=as.matrix(CJ[,3:Kw])
Z=cbind(Z1, Z2)

# give the columns of the design matrices meaningful names
colnames(X)=c("intercept", "1", "t")
colnames(Z)=c(paste("int.",1:dim(Z1)[2], sep=""), paste("2.",3:Kg,sep="" ))

# the following code organizes the inputs for the lme() function
re.block.inds=list(1:dim(Z1)[2], (dim(Z1)[2]+1):(dim(Z)[2]))
Z.block=list(length=2)
for (i in 1:length(re.block.inds)) 
	Z.block[[i]] <- as.formula(paste("~Z[,c(",paste( re.block.inds[[i]],collapse=","),")]-1"))
group=rep(1, I*J)
grouped=data.frame(X,Y,Z)
model.data=groupedData(Y~X|group, data=grouped)

# fit the longitudinal functional regression model
fit.smooth=lme(Y~-1+X, random=list(group=pdBlocked(Z.block, 
	pdClass=rep("pdIdent",length(Z.block)))))


# get the coefficient and gammaHat estimates
coefs <- c(fit.smooth$coef$fixed,unlist(fit.smooth$coef$random))

w <- cbind(1, CJ[,1:2], Z1, CJ[,3:dim(CJ)[2]])
fitted <- as.matrix(w[,1:length(coefs)]) %*% coefs

gammaHat <- phi %*% c(coefs[c(2:3, (4+dim(Z1)[2]):(dim(w)[2]))])


	lambda1 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[1,1])
	lambda2 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z)[2],1])
	D=diag(c(rep(0,ncol(X)), rep(lambda1, ncol(Z1)), rep(lambda2, ncol(Z2))))
	sigmaEpsHat=(fit.smooth$sigma)^2

	vargamma=solve(t(w)%*% solve(diag((fit.smooth$sigma)^2, I*J)) %*% w + D)
	vargamma=vargamma[-c(1, 4:(3+dim(Z1)[2])), -c(1, 4:(3+dim(Z1)[2]))]
	vargammaHat=phi%*%vargamma%*%t(phi)

	lBound=gammaHat - 1.96*sqrt(diag(vargammaHat))
	uBound=gammaHat + 1.96*sqrt(diag(vargammaHat))

quartz()
par(mfrow=c(1,2))
plot(t, gammaHat, type='l', col='red')
points(t, uBound, type='l', col='red', lty=2)
points(t, lBound, type='l', col='red', lty=2)
points(t, trueGamma, type='l')

plot(ranef[J*(1:100)], coefs[4:(3+I)])

var(fitted-Y)




