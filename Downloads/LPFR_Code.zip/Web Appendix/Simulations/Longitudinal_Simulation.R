##########################################################################
# May 11 2010
# Jeff Goldsmith
#
# this file implements a simulation study to evaluate the longitudinal
# functional regression technique in Goldsmith, Crainiceanu, Caffo,
# and Reich (2010). this file only uses the R implementation.
##########################################################################


library(nlme)
#library(lme4)
library(SemiPar)

seed.start <- 1001 
## use a different starting seed each time running the simulation

NREPS=100

tlength = 10
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

I=100

## Parameters we want to vary
J = c(3,10)					# number of visits
VarX = c(0, .5)				# measurement error variance
VarEps = c(5, 10)			# variance on the outcome
VarRanEf = c(5, 50)			# random effect variance

## construct a data frame of all possible combinations of the
## parameters we vary in our simulation.
Params=data.frame(rep(J, each = length(VarX)*length(VarEps)*length(VarRanEf)), 
				rep(rep(VarX, each=length(VarEps)*length(VarRanEf)), length(J)), 
				rep(rep(VarEps, each=length(VarRanEf)), length(VarEps)*length(J)),
				rep(VarRanEf, length(VarEps)*length(VarRanEf)*length(J)))
colnames(Params)=c("J","VarX", "VarEps", "VarRanEf")

Kw=20
Kg=min(Kw, 35)

## seeds to be used at each generation of random functions (1) and measurment error terms (1) and outcome error (1)
seeds <- matrix(seed.start + 0:(3*NREPS-1), nrow=NREPS, ncol=3)


## define true gamma functions

trueGamma1=2*sin(t*pi/5)
trueGamma2=sqrt(t)
	
trueGamma=cbind(trueGamma1, trueGamma2)
	
## next we create lists of the random functions and eigen decompositions
## used in the simulation. there are four lists for the four combinations
## of VarX and J.

FUNCS0.2=vector("list", length=NREPS) 			## this uses VarX=0; J=2
DECOMP0.2=vector("list", length=NREPS)			## this uses VarX=0; J=2
for(i in 1:NREPS){
	set.seed(seeds[i,1])
	## generate true subject-specific mean functions
	funcs <- matrix(0, nrow=I*J[1], ncol=N_obs)
	for(i2 in 1:(I*J[1])){
		funcs[i2,]=funcs[i2,]+runif(1, 0, 5)
		funcs[i2,]=funcs[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs[i2,]=funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs[i2,]=funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.2[[i]]=funcs
	
	varFuncs <- var(funcs)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.2[[i]]=eigenDecomp
}


## these are lists for the functions with measurement error (var = 1)
## the PCA decomp takes place AFTER covariance smoothing

FUNCS1.2=vector("list", length=NREPS)			## this uses VarX=1; J=2
DECOMP1.2=vector("list", length=NREPS)			## this uses VarX=1; J=2
for(i in 1:NREPS){
	set.seed(seeds[i,2])
	funcs = FUNCS0.2[[i]] + matrix(rnorm(length(t)*(I*J[1]), 0, sqrt(VarX[2])), nrow=(I*J[1]), ncol=length(t))
	
	FUNCS1.2[[i]]=funcs
	
	varFuncs <- var(funcs)

	## Smooth the covariance matrix
		## G2 is a M*M matrix for the raw covariance function
		G2 <- varFuncs
		M <- length(t)
		diag(G2)= rep(NA, M)
		g2 <- as.vector(G2)
		## define a N*N knots for bivariate smoothing
		N <- 5
		x1 <- rep(seq(0,10,length=N), N)
		x2 <- rep(seq(0,10,length=N), each=N)
		myknots <- data.frame(x1=x1, x2=x2)
		## bivariate smoothing using the spm function
		t1 <- rep(t, M)
		t2 <- rep(t, each=M)
		fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
		if(class(fit) == "try-error") {
			DECOMP1.2smooth[[i]] <- "failed"
		} else {
			newdata <- data.frame(t1=t1,t2=t2)
			pred <- predict(fit,newdata)
			####  make the fitted covariance function symmetric
			temp.g2 <- matrix(pred, M)
			fit.g2 <- (temp.g2 + t(temp.g2) )/2
		
			eigenDecomp <- eigen(fit.g2)
			eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
			DECOMP1.2[[i]] <- eigenDecomp
		}
	print(i)
}

FUNCS0.10=vector("list", length=NREPS) 			## this uses VarX=0; J=10
DECOMP0.10=vector("list", length=NREPS)			## this uses VarX=0; J=10
for(i in 1:NREPS){
	set.seed(seeds[i,1])
	## generate true subject-specific mean functions
	funcs <- matrix(0, nrow=I*J[2], ncol=N_obs)
	for(i2 in 1:(I*J[2])){
		funcs[i2,]=funcs[i2,]+runif(1, 0, 5)
		funcs[i2,]=funcs[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs[i2,]=funcs[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs[i2,]=funcs[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.10[[i]]=funcs
	
	varFuncs <- var(funcs)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.10[[i]]=eigenDecomp
}


## these are lists for the functions with measurement error (var = 1)
## the PCA decomp takes place AFTER covariance smoothing

FUNCS1.10=vector("list", length=NREPS)			## this uses VarX=1; J=10
DECOMP1.10=vector("list", length=NREPS)			## this uses VarX=1; J=10
for(i in 1:NREPS){
	set.seed(seeds[i,2])
	funcs = FUNCS0.10[[i]] + matrix(rnorm(length(t)*(I*J[2]), 0, sqrt(VarX[2])), nrow=(I*J[2]), ncol=length(t))
	
	FUNCS1.10[[i]]=funcs
	
	varFuncs <- var(funcs)

	## Smooth the covariance matrix
		## G2 is a M*M matrix for the raw covariance function
		G2 <- varFuncs
		M <- length(t)
		diag(G2)= rep(NA, M)
		g2 <- as.vector(G2)
		## define a N*N knots for bivariate smoothing
		N <- 5
		x1 <- rep(seq(0,10,length=N), N)
		x2 <- rep(seq(0,10,length=N), each=N)
		myknots <- data.frame(x1=x1, x2=x2)
		## bivariate smoothing using the spm function
		t1 <- rep(t, M)
		t2 <- rep(t, each=M)
		fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
		if(class(fit) == "try-error") {
			DECOMP1.10smooth[[i]] <- "failed"
		} else {
			newdata <- data.frame(t1=t1,t2=t2)
			pred <- predict(fit,newdata)
			####  make the fitted covariance function symmetric
			temp.g2 <- matrix(pred, M)
			fit.g2 <- (temp.g2 + t(temp.g2) )/2
		
			eigenDecomp <- eigen(fit.g2)
			eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
			DECOMP1.10[[i]] <- eigenDecomp
		}
	print(i)
}


rm(eigenDecomp, fit.g2, temp.g2, pred, newdata, fit, t1, t2, x1, x2, myknots, g2, G2)


## keep track of the MSEs of each of the competing approaches
	
MSE=vector("list", length=dim(Params)[1])
for(i in 1:dim(Params)[1]){
	MSE[[i]]=matrix(0, nrow=NREPS, ncol=dim(trueGamma)[2])
	colnames(MSE[[i]])=paste("MSE_trueGamma", 1:dim(trueGamma)[2], sep="")
}


lBound=vector("list", length=dim(Params)[1])
for(k in 1:dim(Params)[1]){
	lBound[[k]]=vector("list", length=dim(trueGamma)[2])
	names(lBound[[k]]) <- paste("MSE_trueGamma", 1:dim(trueGamma)[2], sep="")
	for(j in 1:dim(trueGamma)[2]){
		lBound[[k]][[j]] <- matrix(NA, NREPS, length(t))
	}
}
uBound <- lBound

for(i in 1:NREPS){	
	for(k in 1:dim(Params)[1]){
		
#		quartz()
#		par(mfrow=c(1,2))
		
		J = Params[k,1]
		VarX = Params[k,2]
		VarEps = Params[k,3]
		VarRanEf = Params[k,4]
		
		if(VarX==0 & J==3){
			W1=FUNCS0.2[[i]]
			true.funcs=FUNCS0.2[[i]]
			Decomp=DECOMP0.2[[i]]
		} else if(VarX==.5 & J==3){
			W1=FUNCS1.2[[i]]
			true.funcs=FUNCS0.2[[i]]
			Decomp=DECOMP1.2[[i]]
		} else if(VarX==0 & J==10){
			W1=FUNCS0.10[[i]]
			true.funcs=FUNCS0.10[[i]]
			Decomp=DECOMP0.10[[i]]
		} else if(VarX==.5 & J==10){
			W1=FUNCS1.10[[i]]
			true.funcs=FUNCS0.10[[i]]
			Decomp=DECOMP1.10[[i]]
		} 
		
		if(!is.null(Decomp) & is.character(Decomp)){
			MSE[[k]][i,]=NA
		} else {		
		
			######################################################
			## Smoothing splines
			######################################################

			mseCur=vector('numeric', dim(trueGamma)[2])
						
			## use the same errors and random effects for each trueGamma
			set.seed(seeds[i,3])
			errors=rnorm(I*J, 0, sqrt(VarEps))
			ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)
			
			for(j in 1:dim(trueGamma)[2]){
				#################################################################
				## generate outcomes	
				Y <- sapply(1:(I*J), function(u) sum(true.funcs[u,]*trueGamma[,j])*by+ranef[u])+errors
				#################################################################

			
				meanFunc=apply(W1, 2, mean, na.rm=TRUE)
				resd=sapply(1:length(t), function(u) W1[,u]-meanFunc[u])
				W=resd

				eigenDecomp = Decomp

				# define the PC basis used for the predictors
				psi=eigenDecomp$vectors[,1:Kw]

				# estimate the PC loadings using numeric integration:
				C=matrix(0, nrow=dim(resd)[1], ncol=Kw)

				for(i2 in 1:dim(resd)[1]){
					C[i2,] <- by * replace(resd[i2,], which(is.na(resd[i2,])), 0) %*% 
						eigenDecomp$vectors[ ,1:Kw ] 
				}

				# set the basis to be used for gamma(t)
				num=Kg-2
				qtiles <- seq(0, 1, length = num + 2)[-c(1, num + 2)]
				knots <- quantile(t, qtiles)
				phi = cbind(rep(1, length(t)), t, sapply(knots, function(k) ((t - k > 0) * (t - k)) ))

				# evaluate the J matrix using numeric integration; assumes t is observed over an even grid
				J.mat <- t(psi) %*% phi * by

				# compute the CJ matrix
				CJ <- C[,1:Kw] %*% J.mat

				# the following code creates the design matrices so that
				# the lme function performs the correct estimation
				X=cbind(1, CJ[,1:2])

				Z1=matrix(rep(c(rep(1, J), rep(0, I*J)), I), nrow=length(Y), ncol=I)
				Z2=as.matrix(CJ[,3:Kw])
				Z=cbind(Z1, Z2)

				# give the columns of the design matrices meaningful names
				colnames(X)=c("intercept", "1", "t")
				colnames(Z)=c(paste("int.",1:dim(Z1)[2], sep=""), paste("2.",3:Kg,sep="" ))

				# the following code organizes the inputs for the lme() function
				re.block.inds=list(1:dim(Z1)[2], (dim(Z1)[2]+1):(dim(Z)[2]))
				Z.block=list(length=2)
				for (i2 in 1:length(re.block.inds)) 
					Z.block[[i2]] <- as.formula(paste("~Z[,c(",paste( re.block.inds[[i2]],collapse=","),")]-1"))
				group=rep(1, I*J)
				grouped=data.frame(X,Y,Z)
				model.data=groupedData(Y~X|group, data=grouped)

				# fit the longitudinal functional regression model

				fit.smooth=try(lme(Y~-1+X, random=list(group=pdBlocked(Z.block, 
					pdClass=rep("pdIdent",length(Z.block))))))

				if(class(fit.smooth) == "try-error") {
					mseCurOurs[j] <- NA
				} else {
					# get the coefficient and gammaHat estimates
					coefs <- c(fit.smooth$coef$fixed,unlist(fit.smooth$coef$random))

					w <- cbind(1, CJ[,1:2], Z1, CJ[,3:dim(CJ)[2]])

					gammaHat <- phi %*% c(coefs[c(2:3, (4+dim(Z1)[2]):(dim(w)[2]))])

					lambda1 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[1,1])
					lambda2 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z)[2],1])
					D=diag(c(rep(0,ncol(X)), rep(lambda1, ncol(Z1)), rep(lambda2, ncol(Z2))))
					sigmaEpsHat=(fit.smooth$sigma)^2

					vargamma=solve(t(w)%*% solve(diag((fit.smooth$sigma)^2, I*J)) %*% w + D)
					vargamma=vargamma[-c(1, 4:(3+dim(Z1)[2])), -c(1, 4:(3+dim(Z1)[2]))]
					vargammaHat=phi%*%vargamma%*%t(phi)

					mseCur[j]=mean((trueGamma[,j] - gammaHat)^2)
					
					## confidence bands
					lBound[[k]][[j]][i,] = gammaHat - 1.96*sqrt(diag(vargammaHat))
					uBound[[k]][[j]][i,] = gammaHat + 1.96*sqrt(diag(vargammaHat))

#					plot(gammaHat, type='l', col='red')
#					points(uBound[[k]][[j]][i,], type='l', col='red', lty=2)
#					points(lBound[[k]][[j]][i,], type='l', col='red', lty=2)
#					points(trueGamma[,j], type='l')

				}				
			}

			MSE[[k]][i,]=mseCur
		}
		rm(W1, Decomp, true.funcs)
	}
	print(i)
}


save(MSE, uBound, seed.start, lBound, 
		file="Longitudinal_FR_Results.RDA")
save(FUNCS0.2, DECOMP0.2, FUNCS0.10, DECOMP0.10,
	FUNCS1.2, DECOMP1.2, FUNCS1.10, DECOMP1.10,
		file="LONG_SIM_FUNCS.RDA")






