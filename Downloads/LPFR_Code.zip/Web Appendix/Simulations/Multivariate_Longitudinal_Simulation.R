##########################################################################
# May 11 2010
# Jeff Goldsmith
#
# this file implements a simulation study to evaluate the longitudinal
# functional regression technique in Goldsmith, Crainiceanu, Caffo,
# and Reich (2010). this file only uses the R implementation.
##########################################################################

rm(list=ls())

library(nlme)
#library(lme4)
library(SemiPar)

seed.start <- 1501 
## use a different starting seed each time running the simulation

NREPS=100

tlength = 10
by = 0.1
t=seq(0, tlength, by=by)
N_obs = length(t)

I=100

## Parameters we want to vary
J = c(3,10)					# number of visits
VarX = c(0, .5)				# measurement error variance
VarEps = c(5, 10)			# variance on the outcome
VarRanEf = c(5, 50)			# random effect variance

## construct a data frame of all possible combinations of the
## parameters we vary in our simulation.
Params=data.frame(rep(J, each = length(VarX)*length(VarEps)*length(VarRanEf)), 
				rep(rep(VarX, each=length(VarEps)*length(VarRanEf)), length(J)), 
				rep(rep(VarEps, each=length(VarRanEf)), length(VarEps)*length(J)),
				rep(VarRanEf, length(VarEps)*length(VarRanEf)*length(J)))
colnames(Params)=c("J","VarX", "VarEps", "VarRanEf")

Kw=20
Kg=min(Kw, 35)

## seeds to be used at each generation of random functions (1) and measurment error terms (1) and outcome error (1)
seeds <- matrix(seed.start + 0:(3*NREPS-1), nrow=NREPS, ncol=3)


## define true gamma functions

trueGamma1=2*sin(t*pi/5)
trueGamma2=sqrt(t)
	
trueGamma=cbind(trueGamma1, trueGamma2)
	
## next we create lists of the random functions and eigen decompositions
## used in the simulation. there are four lists for the four combinations
## of VarX and J.

FUNCS0.2=vector("list", length=2*NREPS) 		## this uses VarX=0; J=2
DECOMP0.2=vector("list", length=2*NREPS)		## this uses VarX=0; J=2
for(i in 1:NREPS){
	set.seed(seeds[i,1])
	## generate true subject-specific mean functions
	funcs1 <- matrix(0, nrow=I*J[1], ncol=N_obs)
	for(i2 in 1:(I*J[1])){
		funcs1[i2,]=funcs1[i2,]+runif(1, 0, 5)
		funcs1[i2,]=funcs1[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs1[i2,]=funcs1[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs1[i2,]=funcs1[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.2[[i]]=funcs1
	
	varFuncs <- var(funcs1)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.2[[i]]=eigenDecomp

	## generate true subject-specific mean functions
	funcs2 <- matrix(0, nrow=I*J[1], ncol=N_obs)
	for(i2 in 1:(I*J[1])){
		funcs2[i2,]=funcs2[i2,]+runif(1, 0, 5)
		funcs2[i2,]=funcs2[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs2[i2,]=funcs2[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs2[i2,]=funcs2[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.2[[i+NREPS]]=funcs2
	
	varFuncs <- var(funcs2)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.2[[i+NREPS]]=eigenDecomp

}


## these are lists for the functions with measurement error (var = 1)
## the PCA decomp takes place AFTER covariance smoothing

FUNCS1.2=vector("list", length=2 * NREPS)		## this uses VarX=1; J=2
DECOMP1.2=vector("list", length=2 * NREPS)		## this uses VarX=1; J=2
for(i in 1:NREPS){
	set.seed(seeds[i,2])

	funcs1 = FUNCS0.2[[i]] + matrix(rnorm(length(t)*(I*J[1]), 0, sqrt(VarX[2])), 
		nrow=(I*J[1]), ncol=length(t))
	
	FUNCS1.2[[i]]=funcs1
	
	varFuncs <- var(funcs1)

	## Smooth the covariance matrix
	## G2 is a M*M matrix for the raw covariance function
	G2 <- varFuncs
	M <- length(t)
	diag(G2)= rep(NA, M)
	g2 <- as.vector(G2)
	## define a N*N knots for bivariate smoothing
	N <- 5
	x1 <- rep(seq(0,10,length=N), N)
	x2 <- rep(seq(0,10,length=N), each=N)
	myknots <- data.frame(x1=x1, x2=x2)
	## bivariate smoothing using the spm function
	t1 <- rep(t, M)
	t2 <- rep(t, each=M)
	fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
	if(class(fit) == "try-error") {
		DECOMP1.2smooth[[i]] <- "failed"
	} else {
		newdata <- data.frame(t1=t1,t2=t2)
		pred <- predict(fit,newdata)
		####  make the fitted covariance function symmetric
		temp.g2 <- matrix(pred, M)
		fit.g2 <- (temp.g2 + t(temp.g2) )/2
	
		eigenDecomp <- eigen(fit.g2)
		eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
		DECOMP1.2[[i]] <- eigenDecomp
	}
	
	funcs2 = FUNCS0.2[[i+NREPS]] + matrix(rnorm(length(t)*(I*J[1]), 0, sqrt(VarX[2])), 
		nrow=(I*J[1]), ncol=length(t))
	
	
	FUNCS1.2[[i+NREPS]]=funcs2
	
	varFuncs <- var(funcs2)

	## Smooth the covariance matrix
	## G2 is a M*M matrix for the raw covariance function
	G2 <- varFuncs
	M <- length(t)
	diag(G2)= rep(NA, M)
	g2 <- as.vector(G2)
	## define a N*N knots for bivariate smoothing
	N <- 5
	x1 <- rep(seq(0,10,length=N), N)
	x2 <- rep(seq(0,10,length=N), each=N)
	myknots <- data.frame(x1=x1, x2=x2)
	## bivariate smoothing using the spm function
	t1 <- rep(t, M)
	t2 <- rep(t, each=M)
	fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
	if(class(fit) == "try-error") {
		DECOMP1.2smooth[[i+NREPS]] <- "failed"
	} else {
		newdata <- data.frame(t1=t1,t2=t2)
		pred <- predict(fit,newdata)
		####  make the fitted covariance function symmetric
		temp.g2 <- matrix(pred, M)
		fit.g2 <- (temp.g2 + t(temp.g2) )/2
	
		eigenDecomp <- eigen(fit.g2)
		eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
		DECOMP1.2[[i+NREPS]] <- eigenDecomp
	}
	print(i)
}

FUNCS0.10=vector("list", length=2 * NREPS) 		## this uses VarX=0; J=10
DECOMP0.10=vector("list", length=2 * NREPS)		## this uses VarX=0; J=10
for(i in 1:NREPS){
	set.seed(seeds[i,1])
	
	## generate true subject-specific mean functions
	funcs1 <- matrix(0, nrow=I*J[2], ncol=N_obs)
	for(i2 in 1:(I*J[2])){
		funcs1[i2,]=funcs1[i2,]+runif(1, 0, 5)
		funcs1[i2,]=funcs1[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs1[i2,]=funcs1[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs1[i2,]=funcs1[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.10[[i]]=funcs1
	
	varFuncs <- var(funcs1)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.10[[i]]=eigenDecomp
	
	## generate true subject-specific mean functions
	funcs2 <- matrix(0, nrow=I*J[2], ncol=N_obs)
	for(i2 in 1:(I*J[2])){
		funcs2[i2,]=funcs2[i2,]+runif(1, 0, 5)
		funcs2[i2,]=funcs2[i2,]+rnorm(1, 1, 0.2)*t
 		for(j2 in 1:10){
			e=rnorm(2, 0, 1/j2^(2))
			funcs2[i2,]=funcs2[i2,]+e[1]*sin((2*pi/10)*t*j2)
			funcs2[i2,]=funcs2[i2,]+e[2]*cos((2*pi/10)*t*j2) 
		}
	}
	
	FUNCS0.10[[i+NREPS]]=funcs2
	
	varFuncs <- var(funcs2)
	eigenDecomp <- eigen(varFuncs)

	# scale the vectors so they are eigen functions
	eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)

	DECOMP0.10[[i+NREPS]]=eigenDecomp
}


## these are lists for the functions with measurement error (var = 1)
## the PCA decomp takes place AFTER covariance smoothing

FUNCS1.10=vector("list", length=2 * NREPS)		## this uses VarX=1; J=10
DECOMP1.10=vector("list", length=2 * NREPS)		## this uses VarX=1; J=10
for(i in 1:NREPS){
	set.seed(seeds[i,2])
	funcs1 = FUNCS0.10[[i]] + matrix(rnorm(length(t)*(I*J[2]), 0, sqrt(VarX[2])), 
		nrow=(I*J[2]), ncol=length(t))
	
	FUNCS1.10[[i]]=funcs1
	
	varFuncs <- var(funcs1)

	## Smooth the covariance matrix
	## G2 is a M*M matrix for the raw covariance function
	G2 <- varFuncs
	M <- length(t)
	diag(G2)= rep(NA, M)
	g2 <- as.vector(G2)
	## define a N*N knots for bivariate smoothing
	N <- 5
	x1 <- rep(seq(0,10,length=N), N)
	x2 <- rep(seq(0,10,length=N), each=N)
	myknots <- data.frame(x1=x1, x2=x2)
	## bivariate smoothing using the spm function
	t1 <- rep(t, M)
	t2 <- rep(t, each=M)
	fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
	if(class(fit) == "try-error") {
		DECOMP1.10smooth[[i]] <- "failed"
	} else {
		newdata <- data.frame(t1=t1,t2=t2)
		pred <- predict(fit,newdata)
		####  make the fitted covariance function symmetric
		temp.g2 <- matrix(pred, M)
		fit.g2 <- (temp.g2 + t(temp.g2) )/2
	
		eigenDecomp <- eigen(fit.g2)
		eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
		DECOMP1.10[[i]] <- eigenDecomp
	}

	funcs2 = FUNCS0.10[[i+NREPS]] + matrix(rnorm(length(t)*(I*J[2]), 0, sqrt(VarX[2])), 
		nrow=(I*J[2]), ncol=length(t))
	
	FUNCS1.10[[i+NREPS]]=funcs2
	
	varFuncs <- var(funcs2)

	## Smooth the covariance matrix
	## G2 is a M*M matrix for the raw covariance function
	G2 <- varFuncs
	M <- length(t)
	diag(G2)= rep(NA, M)
	g2 <- as.vector(G2)
	## define a N*N knots for bivariate smoothing
	N <- 5
	x1 <- rep(seq(0,10,length=N), N)
	x2 <- rep(seq(0,10,length=N), each=N)
	myknots <- data.frame(x1=x1, x2=x2)
	## bivariate smoothing using the spm function
	t1 <- rep(t, M)
	t2 <- rep(t, each=M)
	fit <- try(spm(g2 ~ f(t1, t2, knots=myknots), omit.missing=T))
	if(class(fit) == "try-error") {
		DECOMP1.10smooth[[i+NREPS]] <- "failed"
	} else {
		newdata <- data.frame(t1=t1,t2=t2)
		pred <- predict(fit,newdata)
		####  make the fitted covariance function symmetric
		temp.g2 <- matrix(pred, M)
		fit.g2 <- (temp.g2 + t(temp.g2) )/2
	
		eigenDecomp <- eigen(fit.g2)
		eigenDecomp$vectors <- eigenDecomp$vectors/sqrt(by)
		DECOMP1.10[[i+NREPS]] <- eigenDecomp
	}
	print(i)
}


rm(eigenDecomp, fit.g2, temp.g2, pred, newdata, fit, t1, t2, x1, x2, myknots, g2, G2)


## keep track of the MSEs of each of the competing approaches
	
MSE=vector("list", length=dim(Params)[1])
for(i in 1:dim(Params)[1]){
	MSE[[i]]=matrix(0, nrow=NREPS, ncol=dim(trueGamma)[2])
	colnames(MSE[[i]])=paste("MSE_trueGamma", 1:dim(trueGamma)[2], sep="")
}


lBound=vector("list", length=dim(Params)[1])
for(k in 1:dim(Params)[1]){
	lBound[[k]]=vector("list", length=dim(trueGamma)[2])
	names(lBound[[k]]) <- paste("MSE_trueGamma", 1:dim(trueGamma)[2], sep="")
	for(j in 1:dim(trueGamma)[2]){
		lBound[[k]][[j]] <- matrix(NA, NREPS, length(t))
	}
}
uBound <- lBound

for(i in 1:NREPS){	
	for(k in 1:dim(Params)[1]){
		
		quartz()
		par(mfrow=c(1,2))
		
		J = Params[k,1]
		VarX = Params[k,2]
		VarEps = Params[k,3]
		VarRanEf = Params[k,4]
		
		if(VarX==0 & J==3){
			W1.1=FUNCS0.2[[i]]
			W1.2=FUNCS0.2[[i+NREPS]]
			true.funcs1=FUNCS0.2[[i]]
			true.funcs2=FUNCS0.2[[i+NREPS]]
			Decomp1=DECOMP0.2[[i]]
			Decomp2=DECOMP0.2[[i+NREPS]]
		} else if(VarX==.5 & J==3){
			W1.1=FUNCS1.2[[i]]
			W1.2=FUNCS1.2[[i+NREPS]]
			true.funcs1=FUNCS1.2[[i]]
			true.funcs2=FUNCS1.2[[i+NREPS]]
			Decomp1=DECOMP1.2[[i]]
			Decomp2=DECOMP1.2[[i+NREPS]]
		} else if(VarX==0 & J==10){
			W1.1=FUNCS0.10[[i]]
			W1.2=FUNCS0.10[[i+NREPS]]
			true.funcs1=FUNCS0.10[[i]]
			true.funcs2=FUNCS0.10[[i+NREPS]]
			Decomp1=DECOMP0.10[[i]]
			Decomp2=DECOMP0.10[[i+NREPS]]
		} else if(VarX==.5 & J==10){
			W1.1=FUNCS1.10[[i]]
			W1.2=FUNCS1.10[[i+NREPS]]
			true.funcs1=FUNCS1.10[[i]]
			true.funcs2=FUNCS1.10[[i+NREPS]]
			Decomp1=DECOMP1.10[[i]]
			Decomp2=DECOMP1.10[[i+NREPS]]
		} 
		
		if(!is.null(Decomp1) & is.character(Decomp1) || !is.null(Decomp2) & is.character(Decomp2)){
			MSE[[k]][i,]=NA
		} else {		
		
			######################################################
			## Smoothing splines
			######################################################

			mseCur=vector('numeric', dim(trueGamma)[2])
						
			## use the same errors and random effects for each trueGamma
			set.seed(seeds[i,3])
			errors=rnorm(I*J, 0, sqrt(VarEps))
			ranef=rep(rnorm(I, 0, sd=sqrt(VarRanEf)), each=J)
			
			#################################################################
			## generate outcomes	
			Y <- sapply(1:(I*J), function(u) sum(true.funcs1[u,]*trueGamma[,1])*by+ 
				sum(true.funcs2[u,]*trueGamma[,2])*by + ranef[u])+errors
			#################################################################

			
			meanFunc1=apply(W1.1, 2, mean, na.rm=TRUE)
			meanFunc2=apply(W1.2, 2, mean, na.rm=TRUE)
			resd1=sapply(1:length(t), function(u) W1.1[,u]-meanFunc1[u])
			resd2=sapply(1:length(t), function(u) W1.2[,u]-meanFunc2[u])
			W1=resd1
			W2=resd2
			
			eigenDecomp1 = Decomp1
			eigenDecomp2 = Decomp2
			
			# define the PC basis used for the predictors
			psi1=eigenDecomp1$vectors[,1:Kw]
			psi2=eigenDecomp2$vectors[,1:Kw]

			# estimate the PC loadings using numeric integration:
			C1=matrix(0, nrow=dim(resd1)[1], ncol=Kw)
			C2=matrix(0, nrow=dim(resd2)[1], ncol=Kw)

			for(i2 in 1:dim(resd1)[1]){
				C1[i2,] <- by * replace(resd1[i2,], which(is.na(resd1[i2,])), 0) %*% 
					eigenDecomp1$vectors[ ,1:Kw ] 
				C2[i2,] <- by * replace(resd2[i2,], which(is.na(resd2[i2,])), 0) %*% 
					eigenDecomp2$vectors[ ,1:Kw ] 
			}

			# set the basis to be used for gamma(t)
			num=Kg-2
			qtiles <- seq(0, 1, length = num + 2)[-c(1, num + 2)]
			knots <- quantile(t, qtiles)
			phi = cbind(rep(1, length(t)), t, sapply(knots, function(k) ((t - k > 0) * (t - k)) ))

			# evaluate the J matrix using numeric integration; assumes t is observed over an even grid
			J1.mat <- t(psi1) %*% phi * by
			J2.mat <- t(psi2) %*% phi * by
			
			# compute the CJ matrix
			CJ1 <- C1[,1:Kw] %*% J1.mat
			CJ2 <- C2[,1:Kw] %*% J2.mat

			# the following code creates the design matrices so that
			# the lme function performs the correct estimation
			X=cbind(1, CJ1[,1:2], CJ2[,1:2])

			Z1=matrix(rep(c(rep(1, J), rep(0, I*J)), I), nrow=length(Y), ncol=I)
			Z2=as.matrix(CJ1[,3:Kw])
			Z3=as.matrix(CJ2[,3:Kw])
			Z=cbind(Z1, Z2, Z3)

			# give the columns of the design matrices meaningful names
			colnames(X)=c("intercept", "1.1", "1.t", "2.1", "2.t")
			colnames(Z)=c(paste("int.",1:dim(Z1)[2], sep=""), paste("gamma1.",3:Kg,sep="" ), 
				paste("gamma2.",3:Kg,sep="" ))

			# the following code organizes the inputs for the lme() function
			re.block.inds=list(1:dim(Z1)[2], (dim(Z1)[2]+1):(dim(Z1)[2]+dim(Z2)[2]), 
				(dim(Z1)[2]+dim(Z2)[2]+1):(dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2]))
			Z.block=list(length=3)
			for (i2 in 1:length(re.block.inds)) 
				Z.block[[i2]] <- as.formula(paste("~Z[,c(",paste( re.block.inds
					[[i2]],collapse=","),")]-1"))
			group=rep(1, I*J)
			grouped=data.frame(X,Y,Z)
			model.data=groupedData(Y~X|group, data=grouped)

			# fit the longitudinal functional regression model

			fit.smooth=try(lme(Y~-1+X, random=list(group=pdBlocked(Z.block, 
				pdClass=rep("pdIdent",length(Z.block))))))

			if(class(fit.smooth) == "try-error") {
				mseCurOurs <- c(NA, NA)
			} else {
				# get the coefficient and gammaHat estimates
				coefs <- c(fit.smooth$coef$fixed,unlist(fit.smooth$coef$random))

				# obtain fitted values
				w <- cbind(1, CJ1[,1:2], CJ2[,1:2], Z1, CJ1[,3:dim(CJ1)[2]], CJ2[,3:dim(CJ2)[2]])
				fitted <- as.matrix(w[,1:length(coefs)]) %*% coefs

				# obtain estimates of the functional coefficients
				gamma1Hat <- phi %*% c(coefs[c(2:3, (6+dim(Z1)[2]):(5+dim(Z1)[2]+dim(Z2)[2] ))])
				gamma2Hat <- phi %*% c(coefs[c(4:5, (6+dim(Z1)[2]+dim(Z2)[2]):(5+dim(Z1)[2]+
					dim(Z2)[2]+dim(Z3)[2] ))])
				mseCur=c(mean((trueGamma[,1] - gamma1Hat)^2), mean((trueGamma[,2] - gamma2Hat)^2))

				# to find estimates of the confidence intervals, we need to have the
				# penalty matrix used in the mixed model formulation
				lambda1 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[1,1])
				lambda2 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z1)[2]+1,1])
				lambda3 <- (fit.smooth$sigma)^2/as.numeric(VarCorr(fit.smooth)[dim(Z1)[2]+dim(Z2)[2]+1,1])
				D=diag(c(rep(0,ncol(X)), rep(lambda1, ncol(Z1)), rep(lambda2, ncol(Z2)), 
					rep(lambda3, ncol(Z3))))
				sigmaEpsHat=(fit.smooth$sigma)^2

				# from there we construct the full covariance matrix of all parameters
				# and random effects
				VarMat=try(solve(t(w)%*% solve(diag((fit.smooth$sigma)^2, I*J)) %*% w + D))
					
				if(class(VarMat) == "try-error") {
					lBound[[k]][[1]][i,]=rep(NA, length(t))
					uBound[[k]][[1]][i,]=rep(NA, length(t))

					lBound[[k]][[2]][i,]=rep(NA, length(t))
					uBound[[k]][[2]][i,]=rep(NA, length(t))
				} else {
					# next, for each gamma function, we use only the parts of the covariance matrix 
					# pertinent to that function. this is done by excluding non-pertinent rows and columns
					VarGam1=VarMat[-c(1, 4, 5, 6:(5+dim(Z1)[2]), (6+dim(Z1)[2]+dim(Z2)[2]):(5+
						dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2])), -c(1, 4, 5, 6:(5+dim(Z1)[2]), (6+
						dim(Z1)[2]+dim(Z2)[2]):(5+dim(Z1)[2]+dim(Z2)[2]+dim(Z3)[2]))]
					VarGam2=VarMat[-c(1, 2, 3, 6:(5+dim(Z1)[2]+dim(Z2)[2])),
						-c(1, 2, 3, 6:(5+dim(Z1)[2]+dim(Z2)[2]))]
						
					# the we construct the confidence bands
					VarGamHat1=phi%*%VarGam1%*%t(phi)
					VarGamHat2=phi%*%VarGam2%*%t(phi)

					lBound[[k]][[1]][i,]=gamma1Hat - 1.96*sqrt(diag(VarGamHat1))
					uBound[[k]][[1]][i,]=gamma1Hat + 1.96*sqrt(diag(VarGamHat1))

					lBound[[k]][[2]][i,]=gamma2Hat - 1.96*sqrt(diag(VarGamHat2))
					uBound[[k]][[2]][i,]=gamma2Hat + 1.96*sqrt(diag(VarGamHat2))
				}
			}

			MSE[[k]][i,]=mseCur
#			plot(t, gamma1Hat, type='l', col='red')
#			points(t, uBound[[k]][[1]][i,], type='l', col='red', lty=2)
#			points(t, lBound[[k]][[1]][i,], type='l', col='red', lty=2)
#			points(t, trueGamma1, type='l')

#			plot(t, gamma2Hat, type='l', col='red')
#			points(t, uBound[[k]][[2]][i,], type='l', col='red', lty=2)
#			points(t, lBound[[k]][[2]][i,], type='l', col='red', lty=2)
#			points(t, trueGamma2, type='l')

		}
		rm(W1.1, W1.2, Decomp1, Decomp2, true.funcs1, true.funcs2)
	}
	print(i)
}


save(MSE, uBound, seed.start, lBound, 
		file="Multivariate_Longitudinal_FR_Results.RDA")
save(FUNCS0.2, DECOMP0.2, FUNCS0.10, DECOMP0.10,
	FUNCS1.2, DECOMP1.2, FUNCS1.10, DECOMP1.10,
		file="MULTLONG_SIM_FUNCS.RDA")






