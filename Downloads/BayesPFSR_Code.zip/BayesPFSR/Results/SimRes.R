##################################################################
# July 15 2013
# Jeff Goldsmith
#
# process and display simulation results
##################################################################

rm(list = ls())

library(ggplot2)
library(xtable)
library(reshape)

setwd("~/Dropbox/Work/Current Projects/Bayes PFSR/Simulations/Hierarchical/Results")

##################################################################
## load and organize results
##################################################################

mse = matrix(nrow = 0, ncol = 5)
time = matrix(nrow = 0, ncol = 4)
coverage = matrix(NA, nrow = 3, ncol = 9)

for(i in 1:3){

  load(paste0("20130728_BPFSR_Res_HMS", i, ".RDA"))
  mse = rbind(mse, cbind(MSE.BETA.BAYES, paste0("Scen ", i), "bayes"))
  mse = rbind(mse, cbind(MSE.BETA.VBAYES, paste0("Scen ", i), "vbayes"))
  mse = rbind(mse, cbind(MSE.BETA.PFFR, paste0("Scen ", i), "pffr"))

  time = rbind(time, cbind(TIME[,1:3], paste0("Scen ", i)))

  coverage[i,1:3] = apply(COVERAGE.BETA.BAYES, 2, mean)
  coverage[i,4:6] = apply(COVERAGE.BETA.VBAYES, 2, mean)
  coverage[i,7:9] = apply(COVERAGE.BETA.PFFR, 2, mean)
}

mse = replace(mse, which(is.na(mse)), 0)

mse = as.data.frame(mse)
colnames(mse) = c(paste0("beta ", 0:2), "scenario", "method")
mse = melt(mse, id.vars=c("method", "scenario"))
mse$method = factor(mse$method, levels = c("bayes", "vbayes", "pffr"))
mse$value = as.numeric(as.character(mse$value))

time = as.data.frame(time)
colnames(time) = c("Bayes", "Var. Bayes", "pffr()", "scenario")
time = melt(time, id.vars = "scenario")
time$value = as.numeric(as.character(time$value))
  

##################################################################
## plots for MSE and computation time
##################################################################

dev.new(width = 8, height = 4)  
ggplot(mse, 
       aes(x=variable, y=value, fill = factor(method))) + 
       geom_boxplot(outlier.shape = NA) + theme_bw(base_size=16) +  
       labs(x="", y="IMSE", title=paste("Integrated Mean Squared Error")) + 
       facet_grid(.~scenario, scales="free", space="free") + 
       ylim(0, 7.5) +
       theme(axis.text.x=element_text(angle=40, hjust=1), legend.position="none")
  
dev.new(width = 5, height = 4)  
ggplot(time, 
       aes(x=factor(scenario), y=value, fill = factor(variable))) + 
       geom_boxplot(outlier.shape = NA) + theme_bw(base_size=16) +  
       labs(x="", y="Time (seconds)", title=paste("Time")) +
       theme(axis.text.x=element_text(angle=40, hjust=1)) + 
       scale_fill_discrete(name = "Color Legend")


##################################################################
## table for coverage
##################################################################

xtable(round(coverage, 3))


##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################