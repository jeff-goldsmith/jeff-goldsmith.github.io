This folder contains the code used in the simulations for 

"Assessing the Effect of Stroke on Motor Control using Hierarchical Function-on-Scalar Regression"

by Jeff Goldsmith and Tomoko Kitago.

The file BayesPFSR_Sim.R is the primary file. This code 
-- generates simulated data sets;
-- estimates the function-on-scalar regression model using the proposed Bayesian and variational methods, as well as pffr() in the refund package
-- saves MSEs and coverage probabilities for each iteration.

The folder Wrappers contains implementations of the Bayesian and variational Bayesian models.

The file SimObjects.RDA contains objects used to simulate data: coefficient functions, random effect and residual covariance matrices. 

The folder Results contains the results of the simulations for three scenarios described in the paper: I = 60, I = 120, I = 180. Also included in this folder is the code for creating the simulation summaries found in the paper.