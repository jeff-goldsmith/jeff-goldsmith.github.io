##################################################################
# July 1 2013
# Jeff Goldsmith
#
# Simulations for penalized scalar-on-function regression with 
# subject level random effects. This is a Bayesian approach using
# a mixed-model representation for the penalized smoothing. Error
# variance matrix is estimated as part of the procedure.
##################################################################

rm(list = ls())

library(refund)
library(mvtnorm)

doBayes = TRUE      ## F-on-S regression using Bayes method
doVarBayes = TRUE   ## F-on-S regression using variational Bayes method
doPFFR = TRUE       ## F-on-S regression using pffr()
doFigure = FALSE    ## draw figure 

## set working directory and select parameter scenario
param.scen = 1
Date = gsub("-", "", Sys.Date())

###############################################################
## load objects derived from real data analysis to motivate simulations
###############################################################

load("./SimObjects.RDA")
source("./Wrappers/BayesFit.R")
source("./Wrappers/VarBayesFit.R")

###############################################################
## set simulation design elements
###############################################################

NREP = 100                        ## number of iterations
Kt = 10                           ## dimension of bspline basis
D = dim(beta.true)[2]             ## size of grid for observations
I = c(60, 120, 180)[param.scen]   ## number of subjects
J = 5                             ## visits per subject
IJ = I*J                          ## total observations

###############################################################
## matrices to keep track of results
###############################################################

BETA.BAYES = array(NA, dim = c(dim(beta.true), NREP))
BETA.VBAYES = array(NA, dim = c(dim(beta.true), NREP))
BETA.PFFR = array(NA, dim = c(dim(beta.true), NREP))

MSE.BETA.BAYES = matrix(NA, nrow = NREP, ncol = 3)
MSE.BETA.VBAYES = matrix(NA, nrow = NREP, ncol = 3)
MSE.BETA.PFFR = matrix(NA, nrow = NREP, ncol = 3)

COVERAGE.BETA.BAYES = matrix(NA, nrow = NREP, ncol = 3)
COVERAGE.BETA.VBAYES = matrix(NA, nrow = NREP, ncol = 3)
COVERAGE.BETA.PFFR = matrix(NA, nrow = NREP, ncol = 3)

MSE.Y = matrix(NA, nrow = NREP, ncol = 3)

TIME = matrix(NA, nrow = NREP, ncol = 4)


###############################################################
## start simulation code
###############################################################

for(i.iter in 1:NREP){

  set.seed(i.iter)

  ## fixed and random effect design matrix
  data = as.data.frame(cbind(rep(1:3, each = IJ/3), rep(1:I, each = J)))
  colnames(data) = c("cat", "subj")
  data$cat = factor(data$cat)
  data$subj = factor(data$subj)

  X.des = model.matrix( ~ -1 + cat, data = data)
  Z.des = model.matrix( ~ 0 + subj + (-1):subj, data = data)

  ###############################################################
  ## generate full data for this iteration
  ###############################################################
  
  ## fixed effects
  fixef = X.des %*% beta.true

  ## ranef
  subj.ranef = rmvnorm(I, mean = rep(0, D), sigma = cov.ranef)
  ranef = Z.des %*% subj.ranef

  ## correlated errors
  eps = rmvnorm(IJ, mean = rep(0, D), sigma = cov.resid)
  
  Yi.true = fixef + ranef
  Yij.obs = fixef + ranef + eps

  ###############################################################
  ## gibbs sampler for bayes function-on-scalar regression with correlated errors
  ###############################################################

  if(doBayes){ 

    time.start = proc.time()

    BayesFit = bayes.pfsr(Y = Yij.obs, fixef.form = ~ -1 + as.factor(cat), 
                                       id = data$subj, Kt = Kt, data = data,
                                       N.iter = 5000, N.burn = 1000)

    time.stop = proc.time()

    ## save Bayes output for this dataset
    BETA.BAYES[,,i.iter] = BayesFit$beta.pm
    MSE.BETA.BAYES[i.iter,] = sapply(1:3, function(u) crossprod(beta.true[u,] - BayesFit$beta.pm[u,]))
    COVERAGE.BETA.BAYES[i.iter,] = c(mean(beta.true[1,] < BayesFit$beta.UB[1,] & beta.true[1,] > BayesFit$beta.LB[1,]),
                                     mean(beta.true[2,] < BayesFit$beta.UB[2,] & beta.true[2,] > BayesFit$beta.LB[2,]),
                                     mean(beta.true[3,] < BayesFit$beta.UB[3,] & beta.true[3,] > BayesFit$beta.LB[3,]))
    
    MSE.Y[i.iter,1] = mean(sapply(1:I, function(u) crossprod((Yi.true - BayesFit$Yhat)[J*u,])))
 
    TIME[i.iter,1] = (time.stop - time.start)[3]

  }

  ###############################################################
  ## variational bayes function-on-scalar regression with correlated errors
  ###############################################################

  if(doVarBayes){ 

    time.start = proc.time()

    VarBayesFit = varbayes.pfsr(Y = Yij.obs, fixef.form = ~ -1 + as.factor(cat), 
                                id = data$subj, Kt = Kt, data = data)

    time.stop = proc.time()

    ## save variational bayes output for this dataset
    BETA.VBAYES[,,i.iter] = VarBayesFit$beta.pm
    MSE.BETA.VBAYES[i.iter,] = sapply(1:3, function(u) crossprod(beta.true[u,] - VarBayesFit$beta.pm[u,]))
    COVERAGE.BETA.VBAYES[i.iter,] = c(mean(beta.true[1,] < VarBayesFit$beta.UB[1,] & beta.true[1,] > VarBayesFit$beta.LB[1,]),
                                      mean(beta.true[2,] < VarBayesFit$beta.UB[2,] & beta.true[2,] > VarBayesFit$beta.LB[2,]),
                                      mean(beta.true[3,] < VarBayesFit$beta.UB[3,] & beta.true[3,] > VarBayesFit$beta.LB[3,]))
    
    MSE.Y[i.iter,2] = mean(sapply(1:I, function(u) crossprod((Yi.true - VarBayesFit$Yhat)[J*u,])))
                      
    TIME[i.iter,2] = (time.stop - time.start)[3]

  }

  ###############################################################
  ## pffr() for function-on-scalar regression 
  ###############################################################
  
  if(doPFFR){
   
    Y = Yij.obs
    x0 = X.des[,1]
    x1 = X.des[,2]
    x2 = X.des[,3]
    SUBJ = factor(Z.des %*% (1:I))

    time.start = proc.time()
    
    PffrFit = pffr(Y ~ -1 + x0 + x1 + x2 + s(SUBJ, bs = "re"), bs.yindex = list(bs = "ps", k = 5, m = c(2, 1)), bs.int = list(bs = "ps", k = 5, m = c(2, 1)))
        
    coefs = coef.pffr(PffrFit, n1 = 25)
    fitted.pffr = fitted(PffrFit)

    beta0.pffr = coefs$smterms$'x0(yindex)'$value; se.beta0.pffr = coefs$smterms$'x0(yindex)'$se
    beta1.pffr = coefs$smterms$'x1(yindex)'$value; se.beta1.pffr = coefs$smterms$'x1(yindex)'$se
    beta2.pffr = coefs$smterms$'x2(yindex)'$value; se.beta2.pffr = coefs$smterms$'x2(yindex)'$se

    ranef.pffr = predict(PffrFit, type = "terms")$'te(SUBJ,yindex.vec)'    

    time.stop = proc.time()

    ## save PFFR output for this dataset
    BETA.PFFR[,,i.iter] = t(cbind(beta0.pffr, beta1.pffr, beta2.pffr))
    MSE.BETA.PFFR[i.iter,] = c(crossprod(beta.true[1,] - beta0.pffr),
                               crossprod(beta.true[2,] - beta1.pffr),
                               crossprod(beta.true[3,] - beta2.pffr))
    COVERAGE.BETA.PFFR[i.iter,] = c(mean(beta.true[1,] < beta0.pffr + 2 * se.beta0.pffr  & beta.true[1,] > beta0.pffr - 2 * se.beta0.pffr),
                                    mean(beta.true[2,] < beta1.pffr + 2 * se.beta1.pffr  & beta.true[2,] > beta1.pffr - 2 * se.beta1.pffr),
                                    mean(beta.true[3,] < beta2.pffr + 2 * se.beta2.pffr  & beta.true[3,] > beta2.pffr - 2 * se.beta2.pffr))

    MSE.Y[i.iter,3] = mean(sapply(1:I, function(u) crossprod((Yi.true - fitted.pffr)[u,])))


    TIME[i.iter, 3] = (time.stop - time.start)[3]

  }

  ###############################################################
  ## save data during each iteration
  ###############################################################

  filename = paste0(Date, "_BPFSR_Res_HMS", param.scen, ".RDA")
  save(BETA.BAYES, BETA.VBAYES, BETA.PFFR,
       MSE.BETA.BAYES, MSE.BETA.VBAYES, MSE.BETA.PFFR, 
       COVERAGE.BETA.BAYES, COVERAGE.BETA.VBAYES, COVERAGE.BETA.PFFR,
       MSE.Y, TIME, 
       file = filename)

  cat("REP: ", i.iter, "\n")

} 


###############################################################
###############################################################
## end sim
###############################################################
###############################################################

if(doFigure){

  dev.new(width = 10, height = 3.4)
  par(mfrow = c(1, 3), mai = c(.85,.85,.2,.2), cex = 1)

  ## plot true coefficient functions
  matplot(matrix(1:D, D, 3), t(beta.true), type = 'l', lty = 1, lwd = 3, col = c("#00BC00", "#EB0000", "#2600A2"),
    xlab = "t", ylab = expression(beta(t)), ylim = range(Yij.obs))
  legend("bottomleft", c(expression(beta[0](t)), expression(beta[1](t)), expression(beta[2](t))), lty = 1, lwd = 3,
    col = c("#00BC00", "#EB0000", "#2600A2"))

  ## dataset with 1 subject from each group highlighted
  plot.cols = rep(c("#00BC003b", "#EB00003b", "#2600A23b"), each = I*J/3)
  matplot(matrix(1:D, nrow = D, ncol = IJ), t(Yij.obs), type = 'l', col = plot.cols, lty = 1,
    xlab = "t", ylab = expression(Y[ij](t)))
  subj.cols = rep(c("#00BC00", "#EB0000", "#2600A2"), each = J)
  matpoints(matrix(1:D, nrow = D, ncol = J*3), t(Yij.obs[c(6:10, 101:105, 211:215),]), type = 'l', col = subj.cols, lty = 1, lwd = 2)

  ## bayesian estimates and interval
  matplot(matrix(1:D, D, 3), t(beta.true), type = 'l', lty = 1, lwd = 3, col = c("#00BC009B", "#EB00009B", "#2600A29B"),
    xlab = "t", ylab = expression(beta(t)), ylim = range(-6, 1))
  matpoints(matrix(1:D, D, 3), t(BayesFit$beta.pm), type = 'l', lty = 2, lwd = 2, col = c("#00BC00", "#EB0000", "#2600A2"))
  matpoints(matrix(1:D, D, 3), t(BayesFit$beta.UB), type = 'l', lty = 3, lwd = 1, col = c("#00BC00", "#EB0000", "#2600A2"))
  matpoints(matrix(1:D, D, 3), t(BayesFit$beta.LB), type = 'l', lty = 3, lwd = 1, col = c("#00BC00", "#EB0000", "#2600A2"))
  
}

###############################################################
###############################################################
###############################################################
###############################################################
###############################################################
###############################################################